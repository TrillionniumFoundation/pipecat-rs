#!/usr/bin/env python3
"""Run the reviewed MoQ diagnostic fixture in at most 20 original full suites.

This script does not update the source checkout or retry a failed phase.
The launcher must enforce 600 seconds, CPU 800%, 32 GiB and nice 10, and
observe terminal managed-job statuses for every 0cc stage and C3 first.
"""
import contextlib
import fcntl
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import signal
import stat
import subprocess
import sys
import time
import traceback

ROOT = Path('/home/qian-qi/workspace/pipecat-workspace-f9f576cc6c66')
SOURCE, TARGET = ROOT / 'source-pin', ROOT / 'target-pin'
EVIDENCE = ROOT / 'evidence/moq-diagnostic-pin-r1'
CONTRACT = ROOT / 'requests/moq-diagnostic-pin-r1.source-contract.json'
NAMES = ROOT / 'requests/moq-diagnostic-pin-r1.case-names.json'
BASE = '0cc16e8123cb05aaad480d5ab7860a267d998bac'
BASE_TREE = 'aec037b9cf2be53fcf6f85fdc149382942277702'
BASE_MANIFEST = '1e07f773ca2827e8db5b06175f96137b5d85bb6dcb68229d29601efe29658535'
MOQU_TESTS = 'rust/crates/pipecat-moq/src/tests.rs'
DIAGNOSTIC_SHA = '8695fd709059794132f88133a5d17bb6f3e82e8cd8b84dcdf9bce62176633219'
NAMES_SHA = 'e87d053861a5d96597d28371305e85676864b27477334abcf218a843539f2a41'
RUST_PREFIX = ROOT / 'tools/rust-1.99.0-r1/bin'
RUST_READY = ROOT / 'evidence/rust-1.99.0-restore-r1/ready.json'
RUST_READY_SHA = '0d8da014686ec0eb66874e90527e668836830f873a3ac98f43de4451fe7bf3c9'
HELPER = ROOT / 'run_full_gate.py'
HELPER_SHA = 'c6b639d10e4e0d48910d007a161d7b35e81744bd5e31f878f960bdcd452b47e4'
C3 = ROOT / 'evidence/smart-turn-wheel-reference-pin-r3/reference.json'
ENVIRONMENT = ROOT / 'evidence/full-workspace-rust-1.99.0-r5/environment.json'
REPETITIONS = 20
INNER_SECONDS = 570
OUTER_SECONDS = 600
RESERVE_SECONDS = 10


class Failed(Exception):
    def __init__(self, message, code=127):
        super().__init__(message)
        self.code = code


def identity(path):
    path = Path(path)
    first = path.lstat()
    if not stat.S_ISREG(first.st_mode) or first.st_size > 512 * 1024 * 1024:
        raise ValueError('expected bounded regular non-symlink file: ' + str(path))
    digest, count = hashlib.sha256(), 0
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            count += len(chunk)
            if count > 512 * 1024 * 1024:
                raise ValueError('identity read exceeded its file limit')
            digest.update(chunk)
    last = path.lstat()
    fields = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns)
    if fields(first) != fields(last) or count != first.st_size:
        raise ValueError('file changed during identity observation: ' + str(path))
    return {'path': str(path), 'resolved': str(path.resolve()), 'bytes': count,
            'sha256': digest.hexdigest()}


def relative_path(value):
    return (isinstance(value, str) and bool(value) and
            not PurePosixPath(value).is_absolute() and
            '..' not in PurePosixPath(value).parts and
            '\x00' not in value)


def group_probe(pgid):
    try:
        os.killpg(pgid, 0)
        return {'present': True}
    except ProcessLookupError:
        return {'present': False}
    except OSError as error:
        return {'present': None, 'error': repr(error)}


def contain(child):
    result = {'pid': child.pid, 'pgid': child.pid, 'signals': [], 'errors': []}
    result['leader_exit_before'] = child.poll()
    result['group_before'] = group_probe(child.pid)
    result['group_survived_leader'] = (
        child.returncode is not None and result['group_before']['present'] is not False)
    if child.returncode is None or result['group_before']['present'] is not False:
        for sig, wait_seconds in ((signal.SIGTERM, 2), (signal.SIGKILL, 1)):
            if sig == signal.SIGKILL and child.poll() is not None and group_probe(child.pid)['present'] is False:
                break
            request = {'signal': int(sig), 'pgid': child.pid}
            try:
                os.killpg(child.pid, sig)
                request['result'] = 'requested'
            except ProcessLookupError:
                request['result'] = 'group absent at request'
            except OSError as error:
                request['error'] = repr(error)
                result['errors'].append(repr(error))
            result['signals'].append(request)
            try:
                child.wait(timeout=wait_seconds)
            except subprocess.TimeoutExpired:
                request['leader_wait_timed_out'] = True
            except OSError as error:
                result['errors'].append('leader wait: ' + repr(error))
    result['leader_reaped'] = child.poll() is not None
    result['leader_exit_after'] = child.returncode
    result['group_after'] = group_probe(child.pid)
    result['checks_succeeded'] = (
        result['leader_reaped'] and result['group_after']['present'] is False and
        not result['errors'])
    result['scope'] = ('Only the newly owned process group is signalled. Actual leader reap and '
                       'non-atomic final group absence do not assert individual descendant joins.')
    return result


def main():
    began = time.monotonic()
    deadline = began + INNER_SECONDS
    expected, expected_tree, contract_sha = sys.argv[1:]
    if (not all(re.fullmatch('[0-9a-f]{40}', value) for value in (expected, expected_tree)) or
            not re.fullmatch('[0-9a-f]{64}', contract_sha) or expected == BASE):
        raise ValueError('a newly published exact commit, tree and contract SHA are required')
    EVIDENCE.mkdir(mode=0o700, exist_ok=False)
    result_path = EVIDENCE / 'repetitions.json'
    record = {
        'schema': 'pipecat-moq-original-suite-diagnostic-v1',
        'head': expected, 'tree': expected_tree, 'base': BASE, 'base_tree': BASE_TREE,
        'source': str(SOURCE), 'target': str(TARGET), 'phase': 'preparing',
        'start_unix': time.time(), 'requested_repetitions': REPETITIONS,
        'unique_coverage_cases': 81, 'case_names_sha256': NAMES_SHA,
        'diagnostic_source_sha256': DIAGNOSTIC_SHA,
        'inner_whole_seconds': INNER_SECONDS, 'outer_job_seconds': OUTER_SECONDS,
        'cleanup_and_postflight_reserve_seconds': RESERVE_SECONDS,
        'resource_budget': {'cpu_percent': 800, 'memory_bytes': 34359738368,
                            'build_jobs': 8, 'nice': 10},
        'scope': 'Finite repeat window of the same original 81 cases with a diagnostic-only assertion message.',
        'parallelism': 'Original full harness, no selector or test-threads argument; RUST_TEST_THREADS is rejected.',
        'failure_policy': 'Stop on the first failed preparation, selection, process, containment, or suite result; no retry or replacement.',
        'original_deadlines': '150ms connect_timeout, 3s default end_timeout, and existing 10s bounded helper remain exact source bytes.',
        'historical_failure': 'Original 0cc default r5 absent-peer assertion remains a real failure with an unknown actual error variant.',
        'prior_failures_cleared': False, 'production_qualification': False,
        'processes': [], 'rounds': [], 'identity_before': {}, 'identity_after': {},
        'containment_exit_code': 0, 'integrity_exit_code': 0,
    }
    lock, source_before, binary = None, None, None
    tracked = {}
    status = 127
    environment = dict(os.environ)
    git = shutil.which('git')
    if git is None:
        raise ValueError('git is unavailable')

    def save():
        temporary = result_path.with_suffix('.json.tmp')
        temporary.write_text(json.dumps(record, indent=2) + '\n')
        temporary.replace(result_path)

    def budget(reserve=RESERVE_SECONDS):
        if time.monotonic() + reserve >= deadline:
            raise Failed('internal whole-job budget exhausted', 124)

    def observe(path, expected_sha=None, expected_bytes=None):
        item = identity(path)
        tracked[str(path)] = Path(path)
        record['identity_before'][str(path)] = item
        if expected_sha is not None and item['sha256'] != expected_sha:
            raise ValueError('immutable file hash mismatch: ' + str(path))
        if expected_bytes is not None and item['bytes'] != expected_bytes:
            raise ValueError('immutable file size mismatch: ' + str(path))
        return item

    def run_owned(name, argv, limit, *, round_number=None, separate_stderr=False):
        entry = {'name': name, 'argv': argv, 'cwd': str(SOURCE / 'rust'),
                 'phase': 'preparing', 'start_unix': time.time(),
                 'phase_limit_seconds': limit, 'launch_attempts': 0,
                 'processes_started': 0, 'original_exit_code': None,
                 'timed_out': False, 'containment_exit_code': 0,
                 'log_integrity_exit_code': 0}
        if round_number is None:
            record['processes'].append(entry)
        else:
            entry['round'] = round_number
            record['rounds'].append(entry)
        stdout_path = EVIDENCE / (name + '.stdout.log')
        stderr_path = EVIDENCE / (name + '.stderr.log') if separate_stderr else None
        phase_begin, execution_end, child = time.monotonic(), None, None
        phase_status = 127
        save()
        try:
            effective = min(limit, deadline - time.monotonic() - RESERVE_SECONDS)
            entry['effective_timeout_seconds'] = max(0, effective)
            if effective <= 0:
                raise Failed('no budget remains for phase admission: ' + name, 124)
            phase_deadline = time.monotonic() + effective
            with contextlib.ExitStack() as stack:
                stdout = stack.enter_context(stdout_path.open('xb'))
                stderr = stack.enter_context(stderr_path.open('xb')) if stderr_path else subprocess.STDOUT
                entry.update(phase='launching', launch_attempts=1)
                save()
                child = subprocess.Popen(argv, cwd=SOURCE / 'rust', env=environment,
                                         stdout=stdout, stderr=stderr, start_new_session=True)
                entry.update(phase='running', processes_started=1,
                             pid=child.pid, pgid=child.pid)
                save()
                wait_budget = max(0, min(phase_deadline, deadline - RESERVE_SECONDS) - time.monotonic())
                entry['effective_wait_seconds'] = wait_budget
                try:
                    original = child.wait(timeout=wait_budget)
                    entry['original_exit_code_observed_before_cleanup'] = original
                    phase_status = original if original >= 0 else 127
                except subprocess.TimeoutExpired:
                    entry['timed_out'] = True
                    phase_status = 124
                    entry['timeout_scope'] = 'Runner process budget; original Rust deadlines were not modified.'
                finally:
                    execution_end = time.monotonic()
        except Failed as error:
            phase_status = error.code
            entry['exception'] = str(error)
        except Exception as error:
            entry['exception'] = repr(error)
            phase_status = 127
        finally:
            if execution_end is None:
                execution_end = time.monotonic()
            entry['phase_exit_code_before_containment'] = phase_status
            if child is not None:
                try:
                    cleanup = contain(child)
                    entry['cleanup'] = cleanup
                    entry['original_exit_code'] = child.returncode
                    if not cleanup['checks_succeeded'] or cleanup['group_survived_leader']:
                        entry['containment_exit_code'] = 125
                        record['containment_exit_code'] = 125
                except Exception as error:
                    entry['cleanup_error'] = repr(error)
                    entry['original_exit_code'] = child.returncode
                    entry['containment_exit_code'] = 125
                    record['containment_exit_code'] = 125
            entry['execution_elapsed_seconds'] = execution_end - phase_begin
            entry['logs'] = {}
            for label, path in [('stdout', stdout_path), ('stderr', stderr_path)]:
                if path is None:
                    continue
                try:
                    entry['logs'][label] = identity(path)
                except Exception as error:
                    entry['logs'][label] = {'path': str(path), 'error': repr(error)}
                    entry['log_integrity_exit_code'] = 125
                    record['integrity_exit_code'] = 125
            entry['wrapper_exit_code'] = (
                125 if entry['containment_exit_code'] or entry['log_integrity_exit_code']
                else phase_status)
            entry.update(phase='completed' if child is not None and child.returncode is not None
                         else 'not_started_or_not_reaped',
                         elapsed_seconds=time.monotonic() - phase_begin, end_unix=time.time())
            save()
        return entry

    def require_process(entry):
        if entry['wrapper_exit_code'] != 0:
            raise Failed('phase failed without retry: ' + entry['name'],
                         entry['wrapper_exit_code'])

    def git_read(label, arguments):
        entry = run_owned(label, [git, '-C', str(SOURCE), *arguments], 15,
                          separate_stderr=True)
        require_process(entry)
        return Path(entry['logs']['stdout']['path']).read_bytes()

    def snapshot(label):
        raw = git_read(label + '-paths',
                       ['ls-files', '-z', '--cached', '--others', '--exclude-standard'])
        files = []
        for raw_path in sorted(set(raw.split(b'\0')) - {b''}):
            budget()
            relative = os.fsdecode(raw_path)
            path = SOURCE / relative
            if path.is_symlink():
                data = os.fsencode(os.readlink(path))
                files.append({'path': relative, 'kind': 'symlink', 'size': len(data),
                              'sha256': hashlib.sha256(data).hexdigest()})
            elif path.is_file():
                item = identity(path)
                files.append({'path': relative, 'kind': 'file', 'size': item['bytes'],
                              'sha256': item['sha256']})
            else:
                files.append({'path': relative, 'kind': 'absent'})
        canonical = json.dumps(files, sort_keys=True, separators=(',', ':')).encode()
        value = {'files': files, 'manifest_sha256': hashlib.sha256(canonical).hexdigest()}
        (EVIDENCE / (label + '.json')).write_text(json.dumps(value, indent=2) + '\n')
        return value

    save()
    try:
        lock = (ROOT / 'qualification-owner-pin.lock').open('a')
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        record['lock_acquired'] = True
        observe(Path(__file__).resolve())
        observe(Path(sys.executable).resolve())
        observe(Path(git).resolve())
        observe(HELPER, HELPER_SHA, 5176)
        observe(CONTRACT, contract_sha)
        observe(NAMES, NAMES_SHA, 6882)
        observe(RUST_READY, RUST_READY_SHA, 6059)
        observe(ENVIRONMENT)
        observe(C3)
        owner = TARGET / '.pipecat-source-owner.json'
        observe(owner)
        if json.loads(owner.read_bytes()) != {'source': str(SOURCE), 'task': 'workspace-f9f576cc6c66'}:
            raise ValueError('target is not exclusive to this source checkout')
        expected_names = json.loads(NAMES.read_bytes())
        if (not isinstance(expected_names, list) or len(expected_names) != 81 or
                sorted(set(expected_names)) != expected_names or
                not all(isinstance(name, str) for name in expected_names)):
            raise ValueError('original 81-name contract is invalid')
        record['case_names'] = expected_names
        contract = json.loads(CONTRACT.read_bytes())
        if (contract.get('schema') != 'pipecat-moq-diagnostic-source-contract-v1' or
                contract.get('base') != BASE or contract.get('base_tree') != BASE_TREE or
                contract.get('head') != expected or contract.get('tree') != expected_tree or
                not re.fullmatch('[0-9a-f]{64}', contract.get('source_manifest_sha256', '')) or
                contract.get('source_sha256', {}).get(MOQU_TESTS) != DIAGNOSTIC_SHA):
            raise ValueError('published source contract differs from the reviewed diagnostic')
        changes = contract.get('changed_paths')
        source_shas = contract.get('source_sha256')
        if (not isinstance(changes, list) or not all(relative_path(p) for p in changes) or
                len(changes) != len(set(changes)) or not isinstance(source_shas, dict) or
                not source_shas or not set(source_shas).issubset(set(changes))):
            raise ValueError('invalid complete changed-path/source identity contract')
        (EVIDENCE / 'source-contract.json').write_bytes(CONTRACT.read_bytes())
        (EVIDENCE / 'original-case-names.json').write_bytes(NAMES.read_bytes())
        prior = json.loads(C3.read_bytes())
        if (prior.get('head') != BASE or prior.get('tree') != BASE_TREE or
                prior.get('phase') != 'completed' or type(prior.get('exit_code')) is not int or
                prior['exit_code'] == 125 or prior.get('source_unchanged') is not True or
                prior.get('all_observed_files_unchanged') is not True or prior.get('status_after') or
                prior.get('source_before_sha256') != BASE_MANIFEST or
                prior.get('source_after_sha256') != BASE_MANIFEST or
                set(prior.get('preceding', {})) != {'grok', 'default', 'expanded', 'models', 'webrtc', 'aishell'}):
            raise ValueError('all original 0cc stages and C3 must be terminal with intact inputs')
        started = prior.get('probe_processes_started')
        if type(started) is not int or started not in (0, 1):
            raise ValueError('C3 native process count is unavailable')
        if started:
            cleanup = prior.get('process_cleanup', {})
            if (cleanup.get('checks_succeeded') is not True or
                    cleanup.get('surviving_group_after_normal_exit') or cleanup.get('errors')):
                raise ValueError('C3 owned process cleanup is unresolved')
        record['preceding_c3'] = {
            'path': str(C3), 'sha256': record['identity_before'][str(C3)]['sha256'],
            'exit_code': prior['exit_code'], 'native_exit_code': prior.get('native_exit_code'),
            'comparison_exit_code': prior.get('comparison_exit_code'),
            'earlier_failure_preserved': prior['exit_code'] != 0}
        (EVIDENCE / 'preceding-c3.json').write_bytes(C3.read_bytes())
        for name, receipt in prior['preceding'].items():
            path = Path(receipt['path'])
            if path.parent.parent != ROOT / 'evidence' or receipt.get('phase') not in (
                    'completed', 'completed_successfully', 'completed_with_failures'):
                raise ValueError('C3 preceding receipt path/phase escaped its owned evidence')
            observe(path, receipt['sha256'])
        rust_ready = json.loads(RUST_READY.read_bytes())
        if (rust_ready.get('prefix') != str(RUST_PREFIX.parent) or
                rust_ready.get('manifest_sha256') != 'ce6dddc886364f8d786514771212cebe9b731ba82d6b859951c6b0ccc516b6a2'):
            raise ValueError('official Rust 1.99.0 restore identity differs')
        for name, tool in rust_ready['executables'].items():
            path = Path(tool['path'])
            if path.parent != RUST_PREFIX or name != path.name or tool.get('exit_code') != 0:
                raise ValueError('unexpected pinned Rust executable')
            observe(path, tool['sha256'])
        overrides = json.loads(ENVIRONMENT.read_bytes())
        if not isinstance(overrides, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in overrides.items()):
            raise ValueError('native environment receipt is invalid')
        overrides.update(CARGO_BUILD_JOBS='8', CARGO_TARGET_DIR=str(TARGET))
        environment = dict(os.environ, **overrides)
        if 'RUST_TEST_THREADS' in environment:
            raise ValueError('original default harness parallelism rejects RUST_TEST_THREADS')
        if (environment.get('RUSTC') != str(RUST_PREFIX / 'rustc') or
                environment.get('RUSTDOC') != str(RUST_PREFIX / 'rustdoc') or
                environment.get('RUSTUP_TOOLCHAIN') != '1.99.0'):
            raise ValueError('native environment is not bound to the exact Rust pin')
        observe(RUST_PREFIX / 'rustdoc')
        for name in ('CC', 'CXX'):
            value = environment.get(name)
            if value and Path(value).is_absolute() and Path(value).is_file():
                observe(Path(value).resolve())
        record['environment_overrides'] = overrides
        record['inherited_test_environment'] = {
            name: value for name, value in environment.items() if name.startswith('RUST_TEST_')}
        (EVIDENCE / 'environment.json').write_text(json.dumps(overrides, indent=2) + '\n')
        if git_read('source-head', ['rev-parse', 'HEAD']).decode().strip() != expected:
            raise ValueError('source checkout must already be updated to the published diagnostic freeze')
        if git_read('source-tree', ['rev-parse', 'HEAD^{tree}']).decode().strip() != expected_tree:
            raise ValueError('source tree differs')
        if git_read('source-status', ['status', '--porcelain=v1']):
            raise ValueError('source checkout has unreviewed changes')
        if git_read('base-tree', ['rev-parse', BASE + '^{tree}']).decode().strip() != BASE_TREE:
            raise ValueError('original 0cc tree differs')
        actual_changes = [os.fsdecode(p) for p in git_read(
            'source-diff', ['diff', '--no-renames', '--name-only', '-z', BASE, expected]).split(b'\0') if p]
        if sorted(actual_changes) != sorted(changes):
            raise ValueError('published source diff differs from the exact root-reviewed list')
        if [p for p in actual_changes if p.startswith('rust/crates/pipecat-moq/')] != [MOQU_TESTS]:
            raise ValueError('MoQ source changes exceed the reviewed diagnostic-only fixture')
        for relative, digest in source_shas.items():
            if not relative_path(relative) or not re.fullmatch('[0-9a-f]{64}', digest):
                raise ValueError('invalid source-file hash contract')
            observe(SOURCE / relative, digest)
        source_before = snapshot('source-before')
        record['source_before_sha256'] = source_before['manifest_sha256']
        if source_before['manifest_sha256'] != contract['source_manifest_sha256']:
            raise ValueError('complete source manifest differs from the published freeze')
        cargo = str(RUST_PREFIX / 'cargo')
        metadata = run_owned('metadata', [cargo, 'metadata', '--no-deps', '--locked',
                                         '--offline', '--format-version', '1'], 60,
                             separate_stderr=True)
        require_process(metadata)
        data = json.loads(Path(metadata['logs']['stdout']['path']).read_bytes())
        if (Path(data['workspace_root']).resolve() != SOURCE / 'rust' or
                Path(data['target_directory']).resolve() != TARGET):
            raise ValueError('Cargo metadata selected another workspace or target')
        packages = [p for p in data['packages'] if p['name'] == 'pipecat-moq']
        if len(packages) != 1:
            raise ValueError('expected exactly one MoQ package identity')
        package = packages[0]
        if (Path(package['manifest_path']).resolve() != SOURCE / 'rust/crates/pipecat-moq/Cargo.toml' or
                package['id'] not in data['workspace_members']):
            raise ValueError('MoQ package identity is outside the owned workspace')
        binding_argv = [cargo, 'test', '--workspace', '--locked', '--offline', '--no-run',
                        '--message-format=json-render-diagnostics']
        binding = run_owned('binding', binding_argv, 300)
        require_process(binding)
        artifacts, finished = [], []
        with Path(binding['logs']['stdout']['path']).open('rb') as stream:
            for line in stream:
                try:
                    message = json.loads(line)
                except (ValueError, UnicodeDecodeError):
                    continue
                if message.get('reason') == 'build-finished':
                    finished.append(message.get('success'))
                if (message.get('reason') == 'compiler-artifact' and
                        message.get('package_id') == package['id'] and
                        message.get('target', {}).get('name') == 'pipecat_moq' and
                        message.get('target', {}).get('kind') == ['lib'] and
                        message.get('profile', {}).get('test') is True):
                    artifacts.append(message)
        if finished != [True] or len(artifacts) != 1:
            raise ValueError('workspace build did not report one unique successful MoQ libtest artifact')
        artifact = artifacts[0]
        if Path(artifact['target']['src_path']).resolve() != SOURCE / 'rust/crates/pipecat-moq/src/lib.rs':
            raise ValueError('reported MoQ libtest source path differs')
        binary = Path(artifact['executable']).resolve()
        if binary.parent != TARGET / 'debug/deps' or not binary.name.startswith('pipecat_moq-'):
            raise ValueError('compiler-reported harness escaped the exclusive target')
        record['binary'] = observe(binary)
        record['compiler_artifact'] = artifact
        (EVIDENCE / 'compiler-artifact.json').write_text(json.dumps(artifact, indent=2) + '\n')
        selection = run_owned('selection', [str(binary), '--list'], 10)
        require_process(selection)
        listed = Path(selection['logs']['stdout']['path']).read_text().splitlines()
        actual_names = [line[:-6] for line in listed if line.endswith(': test')]
        nonempty = [line for line in listed if line]
        if (sorted(actual_names) != expected_names or len(actual_names) != 81 or
                len(nonempty) != 82 or nonempty[-1] != '81 tests, 0 benchmarks'):
            raise ValueError('the actual harness does not list exactly the original 81 cases')
        record['selection_verified'] = True
        record['phase'] = 'running'
        save()
        status = 0
        for number in range(1, REPETITIONS + 1):
            budget()
            entry = run_owned(f'round-{number:02d}', [str(binary)], INNER_SECONDS,
                              round_number=number)
            log = Path(entry['logs']['stdout']['path'])
            if log.exists():
                text = log.read_text(errors='replace')
                outcomes = re.findall(r'^test ([^\n]+) \.\.\. (ok|FAILED|ignored[^\n]*)$', text, re.MULTILINE)
                summaries = re.findall(
                    r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',
                    text, re.MULTILINE)
                entry['observed_case_results'] = [{'name': name, 'outcome': outcome} for name, outcome in outcomes]
                entry['observed_summaries'] = summaries
                entry['complete_original_suite_passed'] = (
                    summaries == [('ok', '81', '0', '0', '0', '0')] and
                    len(outcomes) == 81 and
                    sorted(name for name, outcome in outcomes) == expected_names and
                    all(outcome == 'ok' for name, outcome in outcomes))
            else:
                entry['complete_original_suite_passed'] = False
            save()
            if entry['wrapper_exit_code'] != 0:
                status = entry['wrapper_exit_code']
                record['stop_reason'] = 'first failed original harness process or containment; no replacement'
                break
            if not entry['complete_original_suite_passed']:
                status = 126
                entry['selection_exit_code'] = 126
                record['stop_reason'] = 'first incomplete or mismatched original-suite result; no replacement'
                break
        if len(record['rounds']) == REPETITIONS and status == 0:
            record['stop_reason'] = 'all 20 same-suite repeats completed; original r5 failure remains open'
    except Failed as error:
        status = error.code
        record['failure'] = str(error)
        (EVIDENCE / 'error.log').write_text(traceback.format_exc())
    except Exception as error:
        record['failure'] = repr(error)
        (EVIDENCE / 'error.log').write_text(traceback.format_exc())
        if status == 0:
            status = 127
    finally:
        record['execution_exit_code_before_integrity_checks'] = status
        if source_before is not None:
            try:
                source_after = snapshot('source-after')
                record['source_after_sha256'] = source_after['manifest_sha256']
                record['source_unchanged'] = source_before == source_after
                if not record['source_unchanged']:
                    record['integrity_exit_code'] = 125
            except Exception as error:
                record['source_unchanged'] = False
                record['source_after_error'] = repr(error)
                record['integrity_exit_code'] = 125
            for key, args, wanted in [
                    ('head_after', ['rev-parse', 'HEAD'], expected),
                    ('tree_after', ['rev-parse', 'HEAD^{tree}'], expected_tree),
                    ('status_after', ['status', '--porcelain=v1'], '')]:
                try:
                    actual = git_read(key, args).decode().strip()
                    record[key] = actual
                    if actual != wanted:
                        record['integrity_exit_code'] = 125
                except Exception as error:
                    record[key + '_error'] = repr(error)
                    record['integrity_exit_code'] = 125
        for path, tracked_path in tracked.items():
            try:
                after = identity(tracked_path)
                before = record['identity_before'][path]
                after['unchanged'] = all(after[k] == before[k] for k in ('resolved', 'bytes', 'sha256'))
                record['identity_after'][path] = after
                if not after['unchanged']:
                    record['integrity_exit_code'] = 125
            except Exception as error:
                record['identity_after'][path] = {'unchanged': False, 'error': repr(error)}
                record['integrity_exit_code'] = 125
        record['all_observed_files_unchanged'] = bool(tracked) and all(
            item.get('unchanged') for item in record['identity_after'].values())
        record['attempted_repetitions'] = len(record['rounds'])
        record['started_repetitions'] = sum(r.get('processes_started', 0) for r in record['rounds'])
        record['completed_repetitions'] = sum(
            r.get('phase') == 'completed' for r in record['rounds'])
        record['successful_repetitions'] = sum(
            r.get('wrapper_exit_code') == 0 and r.get('complete_original_suite_passed', False)
            for r in record['rounds'])
        record['elapsed_seconds'] = time.monotonic() - began
        if record['elapsed_seconds'] > INNER_SECONDS:
            record['whole_budget_exceeded'] = True
            status = 124
        if record['containment_exit_code'] or record['integrity_exit_code']:
            status = 125
        record.update(phase='completed', exit_code=status, end_unix=time.time())
        save()
        after_save = time.monotonic() - began
        if after_save > INNER_SECONDS:
            record.update(elapsed_seconds=after_save, whole_budget_exceeded=True)
            if status != 125:
                status = record['exit_code'] = 124
            save()
        if lock is not None:
            lock.close()
        print(json.dumps({key: record.get(key) for key in [
            'phase', 'exit_code', 'execution_exit_code_before_integrity_checks',
            'containment_exit_code', 'integrity_exit_code', 'attempted_repetitions',
            'started_repetitions', 'completed_repetitions', 'successful_repetitions',
            'source_unchanged', 'all_observed_files_unchanged', 'stop_reason', 'failure']}),
              flush=True)
    return status


if __name__ == '__main__':
    raise SystemExit(main())
