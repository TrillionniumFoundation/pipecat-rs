import base64
import hashlib
import io
import json
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile
import time

ROOT = Path('/home/qian-qi/workspace/pipecat-workspace-f9f576cc6c66')
OUT = ROOT / 'exports/final-matrix-pin-r1'
HEAD = '0cc16e8123cb05aaad480d5ab7860a267d998bac'
TREE = 'aec037b9cf2be53fcf6f85fdc149382942277702'
STAGES = ['default-no-fail-fast', 'build-normal-examples', 'all-features-all-targets',
          'all-features-all-targets-no-fail-fast', 'strict-clippy', 'format', 'owned-format']

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def stable_bytes(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_size > 32 * 1024 * 1024:
        raise ValueError('not a bounded ordinary evidence file: ' + str(path))
    raw = path.read_bytes()
    after = path.lstat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns) or len(raw) != before.st_size:
        raise ValueError('evidence changed while being exported: ' + str(path))
    return raw

OUT.mkdir(mode=0o700, exist_ok=False)
payload = json.load(sys.stdin)
parser = payload['count_parser'].encode('utf-8')
if sha(parser) != '25615eba3b0b945ce116bc6cfe12e388afa05c6bc5f80fb8f2f6294384fc4b65':
    raise ValueError('count parser differs from its reviewed original')
(OUT / 'summarize_libtest.py').write_bytes(parser)
(OUT / 'export.py').write_text(sys.orig_argv[2])
batch = json.loads(stable_bytes(ROOT / 'evidence/expanded-batch-pin-r2/batch.json'))
if batch.get('head') != HEAD or batch.get('tree') != TREE or batch.get('phase') not in ('completed_successfully', 'completed_with_failures') or batch.get('failure') or not batch.get('driver', {}).get('unchanged'):
    raise ValueError('final expanded batch is not terminal and intact')
if [item['stage'] for item in batch['stages']] != STAGES or any(item.get('phase') != 'completed' or not item.get('source_unchanged') for item in batch['stages']):
    raise ValueError('final matrix is incomplete or source changed')
outer = json.loads(stable_bytes(ROOT / 'requests/expanded-batch-launch-pin-r2/launcher.json'))
if outer.get('phase') != 'completed' or not outer.get('files_unchanged') or outer.get('exit_code') != batch['exit_code']:
    raise ValueError('expanded outer launcher has not finished intact')
directories = [
    'evidence/grok-lifetime-qualification-pin-r1', 'requests/final-native-pin-r5',
    'evidence/full-workspace-rust-1.99.0-r5', 'requests/full-default-launch-pin-r5',
    'evidence/expanded-batch-pin-r2', 'requests/expanded-batch-launch-pin-r2',
    'evidence/smart-turn-ort-levels-pin-r2', 'requests/smart-turn-ort-levels-pin-r2',
] + ['evidence/' + stage + '-pin-r2' for stage in STAGES]
files = {}
skipped = []
for relative in directories:
    directory = ROOT / relative
    if not stat.S_ISDIR(directory.lstat().st_mode):
        raise ValueError('evidence directory is not ordinary: ' + relative)
    for path in sorted(directory.rglob('*')):
        if '__pycache__' in path.relative_to(directory).parts:
            skipped.append({'path': str(path), 'reason': 'reproducible Python import cache, not an original gate receipt'})
            continue
        if path.is_symlink():
            raise ValueError('unexpected symlink in evidence: ' + str(path))
        if path.is_dir():
            continue
        if len(path.relative_to(directory).parts) > 5:
            raise ValueError('evidence nesting exceeds export bound')
        name = str(path.relative_to(ROOT))
        files[name] = (path, stable_bytes(path))
        if len(files) > 800 or sum(len(item[1]) for item in files.values()) > 128 * 1024 * 1024:
            raise ValueError('fixed evidence set exceeds export budget')

moq = {'scope': 'Only the exact registry source selected by the recorded compiler artifact is read; no Cargo command or registry scan is executed.'}
binding = files['evidence/grok-lifetime-qualification-pin-r1/binding.log'][1]
candidates = set()
for line in binding.splitlines():
    if not line.startswith(b'{'):
        continue
    try:
        item = json.loads(line)
    except (ValueError, UnicodeDecodeError):
        continue
    if item.get('reason') == 'compiler-artifact' and item.get('package_id', '').endswith('#moq-net@0.3.7') and item.get('target', {}).get('name') == 'moq_net':
        candidates.add(item['target']['src_path'])
moq['artifact_source_candidates'] = sorted(candidates)
if len(candidates) == 1:
    source = Path(next(iter(candidates)))
    crate = source.parent.parent
    if source.name != 'lib.rs' or source.parent.name != 'src' or crate.name != 'moq-net-0.3.7' or not str(crate).startswith('/home/qian-qi/.cargo/registry/src/'):
        raise ValueError('compiler-selected MoQ crate path is outside the known registry')
    moq['files'] = []
    for relative in ['.cargo_vcs_info.json', 'src/client.rs']:
        path = crate / relative
        raw = stable_bytes(path)
        git_blob = hashlib.sha1(('blob ' + str(len(raw)) + '\0').encode('ascii') + raw).hexdigest()
        name = 'registry/moq-net-0.3.7/' + relative
        files[name] = (path, raw)
        moq['files'].append({'path': str(path), 'archive_name': name, 'bytes': len(raw), 'sha256': sha(raw), 'git_blob': git_blob})
        if relative == '.cargo_vcs_info.json':
            moq['cargo_vcs_info'] = json.loads(raw)
        else:
            moq['matches_official_client_blob_75abdb5e'] = git_blob == '75abdb5e3b229086ca08316f7fbeb8d9b60600ab'
else:
    moq['observation_unavailable'] = 'compiler receipt did not select exactly one matching artifact'
(OUT / 'moq-registry-provenance.json').write_text(json.dumps(moq, indent=2) + '\n')

manifest = {'schema': 'pipecat-final-matrix-originals-v1', 'source_head': HEAD, 'source_tree': TREE,
            'observed_unix': time.time(), 'files': [], 'skipped': skipped,
            'scope': 'Each named source/run remains independent; source manifest canonical digests and original raw file digests are separate fields. C2 remains bound to its earlier 272671 source.'}
for name, (path, raw) in sorted(files.items()):
    item = {'name': name, 'remote_path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}
    if path.name in ('source-before.json', 'source-after.json'):
        original = json.loads(raw)
        canonical = sha(json.dumps(original['files'], sort_keys=True, separators=(',', ':')).encode())
        if canonical != original['manifest_sha256']:
            raise ValueError('source file-map canonical digest mismatch')
        item['source_files_canonical_sha256'] = canonical
    manifest['files'].append(item)
manifest.update(original_count=len(files), original_bytes=sum(len(raw) for path, raw in files.values()))
manifest_raw = (json.dumps(manifest, indent=2) + '\n').encode()
(OUT / 'original-files-manifest.json').write_bytes(manifest_raw)

counts = []
for stage, log_name in [('full-workspace-rust-1.99.0-r5', 'cargo-test-workspace.log'),
                        ('default-no-fail-fast-pin-r2', 'command.log'),
                        ('all-features-all-targets-pin-r2', 'command.log'),
                        ('all-features-all-targets-no-fail-fast-pin-r2', 'command.log')]:
    destination = OUT / ('counts-' + stage + '.json')
    argv = [sys.executable, str(OUT / 'summarize_libtest.py'), str(ROOT / 'evidence' / stage / log_name),
            '--gate', str(ROOT / 'evidence' / stage / 'gate.json'), '--output', str(destination)]
    result = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    (OUT / ('counts-' + stage + '.stdout.log')).write_bytes(result.stdout)
    (OUT / ('counts-' + stage + '.stderr.log')).write_bytes(result.stderr)
    if result.returncode:
        raise ValueError('derived count parser failed: ' + stage)
    count = json.loads(destination.read_bytes())
    if count['multi_summary_harnesses'] or count['incomplete_harnesses']:
        raise ValueError('raw libtest count requires manual disambiguation: ' + stage)
    counts.append({key: count[key] for key in ['source_gate', 'raw_log', 'raw_log_bytes', 'raw_log_sha256', 'totals', 'harness_count', 'failed_harnesses', 'command_exit_code']})
    for index, suite in enumerate(count['suites']):
        if suite.get('failed', 0) or 'pipecat_moq-' in suite['header']:
            raw = (ROOT / 'evidence' / stage / log_name).read_bytes()
            sliced = raw[suite['raw_start_byte']:suite['raw_end_byte']]
            if sha(sliced) != suite['raw_slice_sha256']:
                raise ValueError('derived slice hash mismatch')
            name = 'slice-' + stage + '-' + str(index).zfill(3) + '.log'
            (OUT / name).write_bytes(sliced)
            (OUT / (name + '.json')).write_text(json.dumps(suite, indent=2) + '\n')

archive = OUT / 'final-matrix-pin-r1.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6, format=tarfile.PAX_FORMAT) as package:
    for name, (path, raw) in sorted(files.items()):
        info = tarfile.TarInfo('originals/' + name)
        info.size = len(raw)
        info.mode = 0o600
        info.mtime = 0
        package.addfile(info, io.BytesIO(raw))
    info = tarfile.TarInfo('original-files-manifest.json')
    info.size = len(manifest_raw)
    info.mode = 0o600
    info.mtime = 0
    package.addfile(info, io.BytesIO(manifest_raw))
    for path in sorted(OUT.iterdir()):
        if not path.is_file() or path in (archive, OUT / 'original-files-manifest.json'):
            continue
        raw = path.read_bytes()
        info = tarfile.TarInfo('derived/' + path.name)
        info.size = len(raw)
        info.mode = 0o600
        info.mtime = 0
        package.addfile(info, io.BytesIO(raw))
raw = archive.read_bytes()
encoded = base64.b64encode(raw).decode('ascii')
parts = []
for offset in range(0, len(encoded), 60000):
    value = encoded[offset:offset + 60000]
    path = OUT / ('part-' + str(len(parts)).zfill(3) + '.b64')
    path.write_text(value)
    parts.append({'path': str(path), 'bytes': len(value), 'sha256': sha(value.encode('ascii'))})
delivery = {'schema': 'pipecat-final-matrix-delivery-v1', 'archive_path': str(archive),
            'archive_bytes': len(raw), 'archive_sha256': sha(raw), 'original_count': len(files),
            'original_bytes': manifest['original_bytes'], 'original_manifest_bytes': len(manifest_raw),
            'original_manifest_sha256': sha(manifest_raw), 'parts': parts,
            'source_head': HEAD, 'source_tree': TREE, 'counts': counts, 'moq_registry': moq,
            'completed_unix': time.time()}
(OUT / 'delivery.json').write_text(json.dumps(delivery, indent=2) + '\n')
print(json.dumps(delivery), flush=True)
