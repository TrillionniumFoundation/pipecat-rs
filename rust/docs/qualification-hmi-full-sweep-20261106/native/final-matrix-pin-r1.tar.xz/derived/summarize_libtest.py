#!/usr/bin/env python3
"""Derive per-Cargo-harness counts from unchanged raw byte logs."""
import argparse,hashlib,json,pathlib,re
parser=argparse.ArgumentParser()
parser.add_argument('log',type=pathlib.Path)
parser.add_argument('--gate',type=pathlib.Path)
parser.add_argument('--output',type=pathlib.Path,required=True)
args=parser.parse_args()
raw=args.log.read_bytes()
headers=list(re.finditer(rb'(?m)^[ \t]*(Running|Doc-tests) ([^\n]*)\n',raw))
summary_re=re.compile(rb'(?m)^test result: (ok|FAILED)\. ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored; ([0-9]+) measured; ([0-9]+) filtered out;(?: finished in ([^\n]+))?')
ignore_re=re.compile(rb'(?m)^test ([^\n]+?) \.\.\. ignored(?:, ([^\n]*))?$')
suites=[]
for i,header in enumerate(headers):
 start,end=header.start(),headers[i+1].start() if i+1<len(headers) else len(raw)
 body=raw[start:end]
 found=list(summary_re.finditer(body))
 entry={'header':header.group(0).decode('utf-8','strict').strip(),'kind':header.group(1).decode(),
        'raw_start_byte':start,'raw_end_byte':end,'raw_slice_sha256':hashlib.sha256(body).hexdigest(),
        'summary_matches_in_block':len(found)}
 if found:
  match=found[-1]
  entry.update(status=match.group(1).decode(),passed=int(match.group(2)),failed=int(match.group(3)),
               ignored=int(match.group(4)),measured=int(match.group(5)),filtered_out=int(match.group(6)),
               summary_offset=start+match.start(),summary_raw=match.group(0).decode('ascii'))
 else:
  entry['status']='no_terminal_libtest_summary'
 entry['ignored_cases']=[{'name':m.group(1).decode('utf-8','strict'),'reason':(m.group(2) or b'').decode('utf-8','strict')} for m in ignore_re.finditer(body)]
 suites.append(entry)
gate=json.loads(args.gate.read_bytes()) if args.gate else None
totals={key:sum(item.get(key,0) for item in suites) for key in ('passed','failed','ignored','measured','filtered_out')}
result={'schema':'pipecat-derived-libtest-harness-counts-v1','raw_log':str(args.log),'raw_log_bytes':len(raw),
        'raw_log_sha256':hashlib.sha256(raw).hexdigest(),'source_gate':str(args.gate) if args.gate else None,
        'source_gate_sha256':hashlib.sha256(args.gate.read_bytes()).hexdigest() if args.gate else None,
        'head':gate.get('head') if gate else None,'tree':gate.get('base_git_tree') if gate else None,
        'argv':gate.get('argv') if gate else None,'command_exit_code':gate.get('exit_code') if gate else None,
        'source_unchanged':gate.get('source_unchanged') if gate else None,
        'method':'Original raw bytes preserved. Cargo Running/Doc-tests boundaries; only the last terminal libtest summary in each harness is counted. Multi-summary blocks are flagged. Counts from independent commands must not be added as unique coverage.',
        'totals':totals,'harness_count':len(suites),'completed_harness_count':sum(item['status'] in ('ok','FAILED') for item in suites),
        'failed_harnesses':[item['header'] for item in suites if item.get('failed',0)>0],
        'multi_summary_harnesses':[item['header'] for item in suites if item['summary_matches_in_block']>1],
        'incomplete_harnesses':[item['header'] for item in suites if item['status']=='no_terminal_libtest_summary'],
        'suites':suites}
args.output.parent.mkdir(parents=True,exist_ok=True)
args.output.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({key:result[key] for key in ('raw_log_bytes','raw_log_sha256','head','command_exit_code','totals','harness_count','completed_harness_count','failed_harnesses','multi_summary_harnesses','incomplete_harnesses')},ensure_ascii=False))
