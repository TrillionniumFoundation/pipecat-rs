import base64
import hashlib
import io
import json
from pathlib import Path
import stat
import sys
import tarfile
import time

ROOT = Path('/home/qian-qi/workspace/pipecat-workspace-f9f576cc6c66')
EVIDENCE = ROOT / 'evidence/strict-clippy-after-moq-pin-r1'
OUT = ROOT / 'exports/strict-clippy-final-q-r1'
Q = 'c1c3addb07dde0a143462c10961ff2494eeba90a'
TREE = '4df0d197540551ed9b74d4e11c0936e5bedee5f5'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_size > 32 * 1024 * 1024:
        raise ValueError('not a bounded ordinary file: ' + str(path))
    raw = path.read_bytes()
    after = path.lstat()
    signature = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns)
    if signature(before) != signature(after) or len(raw) != before.st_size:
        raise ValueError('original changed while read')
    return raw


OUT.mkdir(mode=0o700, exist_ok=False)
verification = json.loads(read(EVIDENCE / 'verification.json'))
if (verification.get('phase') != 'completed' or verification.get('head') != Q or
        verification.get('tree') != TREE or verification.get('exit_code') != 0 or
        verification.get('strict_clippy_original_exit_code') != 0 or
        verification.get('source_unchanged') is not True or
        verification.get('all_observed_files_unchanged') is not True):
    raise ValueError('expected terminal successful strict Q result is unavailable')
files = {}
for path in sorted(EVIDENCE.rglob('*')):
    if path.is_symlink():
        raise ValueError('evidence symlink refused')
    if path.is_dir():
        continue
    if len(path.relative_to(EVIDENCE).parts) > 4:
        raise ValueError('evidence depth exceeded')
    files[str(path.relative_to(ROOT))] = (path, read(path))
for relative, checksum in {
    'desktop_strict_clippy_after_moq_pin_r1.py': '2d2a93bf3e82524e5c7822a0bd3fe42de1d8a361362cd3ee59dce1e90cb3352c',
    'source-pin/rust/crates/pipecat-moq/src/tests.rs': '8695fd709059794132f88133a5d17bb6f3e82e8cd8b84dcdf9bce62176633219',
    'source-pin/rust/crates/pipecat-evals/src/simulation/quality.rs': '4f5b66f3ba68317ab834ef8883ee0ed149477a2d032cae9ab243da513da02780',
}.items():
    path = ROOT / relative
    raw = read(path)
    if sha(raw) != checksum:
        raise ValueError('reviewed script or source differs: ' + relative)
    files[relative] = (path, raw)
if len(files) > 200 or sum(len(v[1]) for v in files.values()) > 64 * 1024 * 1024:
    raise ValueError('export budget exceeded')
manifest = {'schema': 'pipecat-strict-q-originals-v1', 'head': Q, 'tree': TREE,
            'observed_unix': time.time(), 'files': [],
            'scope': 'Read-only export after the sole Q strict command and two leaf format checks terminated. No native command is executed by this export. Original earlier failures and full-matrix scope remain unchanged.'}
for name, (path, raw) in sorted(files.items()):
    if read(path) != raw:
        raise ValueError('original changed during export')
    item = {'name': name, 'remote_path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}
    if path.name in ['source-before.json', 'source-after.json']:
        obj = json.loads(raw)
        canonical = sha(json.dumps(obj['files'], sort_keys=True, separators=(',', ':')).encode())
        if canonical != obj['manifest_sha256']:
            raise ValueError('source canonical mismatch')
        item['source_files_canonical_sha256'] = canonical
    manifest['files'].append(item)
manifest.update(original_count=len(files), original_bytes=sum(len(v[1]) for v in files.values()))
manifest_raw = (json.dumps(manifest, indent=2) + '\n').encode()
(OUT / 'original-files-manifest.json').write_bytes(manifest_raw)
archive = OUT / 'strict-clippy-final-q-r1.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6, format=tarfile.PAX_FORMAT) as stream:
    members = [('originals/' + n, raw) for n, (p, raw) in sorted(files.items())]
    members += [('original-files-manifest.json', manifest_raw), ('derived/export.py', sys.orig_argv[2].encode())]
    for name, raw in members:
        item = tarfile.TarInfo(name)
        item.size, item.mode, item.mtime = len(raw), 0o600, 0
        stream.addfile(item, io.BytesIO(raw))
raw = archive.read_bytes()
encoded = base64.b64encode(raw).decode('ascii')
parts = []
for start in range(0, len(encoded), 60000):
    text = encoded[start:start + 60000]
    path = OUT / ('part-' + str(len(parts)).zfill(3) + '.b64')
    path.write_text(text)
    parts.append({'path': str(path), 'bytes': len(text), 'sha256': sha(text.encode())})
delivery = {'schema': 'pipecat-strict-q-delivery-v1', 'archive_path': str(archive),
            'archive_bytes': len(raw), 'archive_sha256': sha(raw), 'original_count': len(files),
            'original_bytes': manifest['original_bytes'], 'original_manifest_bytes': len(manifest_raw),
            'original_manifest_sha256': sha(manifest_raw), 'parts': parts,
            'completed_unix': time.time()}
(OUT / 'delivery.json').write_text(json.dumps(delivery, indent=2) + '\n')
print(json.dumps(delivery), flush=True)
