#!/usr/bin/env python3
"""Run the unfiltered workspace gate with before/after source evidence."""
import argparse
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import time


def source_manifest(source):
    command = ['git', '-C', str(source), 'ls-files', '-z', '--cached', '--others', '--exclude-standard']
    paths = sorted(set(subprocess.check_output(command).split(b'\0')) - {b''})
    files = []
    for raw in paths:
        relative = os.fsdecode(raw)
        path = source / relative
        if path.is_symlink():
            data = os.fsencode(os.readlink(path))
            kind = 'symlink'
        elif path.is_file():
            data = path.read_bytes()
            kind = 'file'
        else:
            files.append({'path': relative, 'kind': 'absent'})
            continue
        files.append({'path': relative, 'kind': kind, 'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    canonical = json.dumps(files, sort_keys=True, separators=(',', ':')).encode()
    return {'files': files, 'manifest_sha256': hashlib.sha256(canonical).hexdigest()}


def git_value(source, args):
    return subprocess.check_output(['git', '-C', str(source), *args], text=True).strip()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=pathlib.Path, required=True)
    parser.add_argument('--target', type=pathlib.Path, required=True)
    parser.add_argument('--evidence', type=pathlib.Path, required=True)
    parser.add_argument('--cargo', required=True)
    parser.add_argument('--env-json', type=pathlib.Path)
    parser.add_argument('--no-run', action='store_true')
    options = parser.parse_args()
    source, target, evidence = (p.resolve() for p in (options.source, options.target, options.evidence))
    if target == source or target in source.parents or source in target.parents:
        raise ValueError('target must be separate from source')
    marker = target / '.pipecat-source-owner.json'
    ownership = {'source': str(source), 'task': 'workspace-f9f576cc6c66'}
    if target.exists():
        if not marker.exists() or json.loads(marker.read_text()) != ownership:
            raise ValueError('target is not marked as exclusive to this checkout')
    else:
        target.mkdir(parents=True)
        marker.write_text(json.dumps(ownership, indent=2) + '\n')
    evidence.mkdir(parents=True, exist_ok=True)
    before = source_manifest(source)
    (evidence / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
    env_changes = json.loads(options.env_json.read_text()) if options.env_json else {}
    env_changes['CARGO_TARGET_DIR'] = str(target)
    env = dict(os.environ, **env_changes)
    argv = [options.cargo, 'test', '--workspace', '--locked']
    if options.no_run:
        argv.append('--no-run')
    safe_environment_keys = ['CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','RUSTC','RUSTDOC','RUSTUP_TOOLCHAIN','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CC','CXX','CXXFLAGS','CFLAGS','LDFLAGS','LIBCLANG_PATH','LD_LIBRARY_PATH','PKG_CONFIG_PATH','PKG_CONFIG_SYSROOT_DIR','LK_CUSTOM_WEBRTC','PIPECAT_ONNX_RUNTIME','ORT_DYLIB_PATH','PIPECAT_SILERO_MODEL','PIPECAT_SMART_TURN_MODEL','RUST_TEST_THREADS']
    record = {'schema': 'pipecat-full-workspace-gate-v1', 'purpose': 'prebuild_only_not_test_qualification' if options.no_run else 'full_workspace_test_gate', 'source': str(source), 'head': git_value(source, ['rev-parse','HEAD']), 'base_git_tree': git_value(source, ['rev-parse','HEAD^{tree}']), 'status_before': git_value(source, ['status','--porcelain=v1']), 'target': str(target), 'cwd': str(source/'rust'), 'argv': argv, 'environment_overrides': env_changes, 'effective_build_environment': {k:env[k] for k in safe_environment_keys if k in env}, 'start_unix': time.time(), 'source_before_sha256': before['manifest_sha256'], 'phase': 'running'}
    record_path = evidence / 'gate.json'
    record_path.write_text(json.dumps(record, indent=2) + '\n')
    try:
        with (evidence/'cargo-test-workspace.log').open('wb') as log:
            process = subprocess.Popen(argv, cwd=source/'rust', env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            for line in process.stdout:
                log.write(line)
                log.flush()
                sys.stdout.buffer.write(line)
                sys.stdout.buffer.flush()
            record['exit_code'] = process.wait()
    except Exception as exc:
        record['launch_exception'] = f'{type(exc).__name__}: {exc}'
    after = source_manifest(source)
    (evidence/'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
    record.update(end_unix=time.time(), phase='completed', source_after_sha256=after['manifest_sha256'], source_unchanged=before == after, status_after=git_value(source, ['status','--porcelain=v1']))
    record_path.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record, sort_keys=True), flush=True)
    return record.get('exit_code', 127) if record['source_unchanged'] else 125


if __name__ == '__main__':
    raise SystemExit(main())
