# Short spawn-only lease candidate was not selected

This original candidate was retained without applying it to repository or desktop source.

The read lease ends at `Command::spawn` return. Primary review found that this boundary cannot generally establish completion of closing every inherited CLOEXEC descriptor: the referenced Linux exec paths wake the CLONE_VFORK parent through exec_mm_release before do_close_on_exec. The Rust posix_spawn return path adds no independent all-descriptor closure fence.

The full primary paths, tags, Git blob identities, call ordering, and the replacement lifetime-lease design are recorded in `../grok-spawn-gate-candidate-r2/primary-boundaries.json` and `DESIGN.md`.

The standalone controlled experiment in this directory directly observed an inherited socket inode and the difference between the pre-exec and post-exec stages. Its success is mechanism evidence only. It does not runtime-qualify either Rust candidate or retrospectively prove the cause of an earlier Grok failure.
