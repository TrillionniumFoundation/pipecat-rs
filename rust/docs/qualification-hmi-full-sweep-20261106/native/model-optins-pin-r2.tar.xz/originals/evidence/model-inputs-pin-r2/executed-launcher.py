#!/usr/bin/env python3
"""Run the reviewed 19 native opt-in commands with immutable-input receipts."""
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import sys
import time
import traceback

ROOT = Path('/home/qian-qi/workspace/pipecat-workspace-f9f576cc6c66')
SOURCE, TARGET = ROOT / 'source-pin', ROOT / 'target-pin'
HEAD = '0cc16e8123cb05aaad480d5ab7860a267d998bac'
TREE = 'aec037b9cf2be53fcf6f85fdc149382942277702'
EVIDENCE = ROOT / 'evidence/model-inputs-pin-r2'
DRIVER = ROOT / 'desktop_gate_batch_pin_r1.py'
CONFIG = ROOT / 'fixtures/chinese-synthetic-pin-r1/config.json'
PIPER = ROOT / 'fixtures/chinese-synthetic-pin-r1/piper-config.json'
SELECTION = ROOT / 'recovered-model-test-selection.json'
STAGES = ['local-sfu', 'chinese-synthetic', 'piper-genuine-owner', 'piper-invalid-bounds',
          'piper-cancel-reload', 'piper-long-pipeline'] + [f'whisper-owner-{i:02d}' for i in range(1, 14)]
FIXED = {
    DRIVER: ('4492fe741b76258630c1e472c3f326887d71e02ff705035a14240938d4aa5ef0', 12378),
    ROOT / 'desktop_additional_gate_pin_v4.py': ('ec7df29d960309ec486ed403636d1151c8ac35a86842bbb692a08ddbd5b2eba6', 12714),
    ROOT / 'run_qualification_command_pin_v3.py': ('8654269c9b24b6ee828d71a4827f54e3366de6177f760471644b72fea4749f35', 4657),
    ROOT / 'run_full_gate.py': ('c6b639d10e4e0d48910d007a161d7b35e81744bd5e31f878f960bdcd452b47e4', 5176),
    CONFIG: ('edb172c2edd82083fe821d4c99364e1a80fe011ed33ed3f52eb01f28e2d132aa', 2815),
    PIPER: ('28aca7161d2f60022cb0cc48ae5ef57d309a261c3fb9fa69a6f1d7f2c4cae4da', 1317),
    SELECTION: ('c9e5e422c077da628594fe12a634ae42e7e004aa278fb25468ba8eac0c9c2921', 16369),
    ROOT / 'servers/livekit-1.13.9/livekit-server': ('0fbb1246f555fc3d27ae92530273f53d9463bbccd93c7edb398e0c6ccfe1536b', 57295010),
    ROOT / 'evidence/rust-1.99.0-restore-r1/ready.json': ('0d8da014686ec0eb66874e90527e668836830f873a3ac98f43de4451fe7bf3c9', 6059),
    ROOT / 'requests/final-native-pin-r5/source-contract.json': ('538da3b8b642c7e7afe771cda5045e02e742635cb6e30c08301c17b8eaa73fe8', 11841),
}
ESPEAK_EXPECTED = 'bba750d12c77a7714b579dc8a34e205417174963cfd05a54da8edd4031f09926'


def identity(path):
    path = Path(path)
    first = path.lstat()
    if not stat.S_ISREG(first.st_mode):
        raise ValueError('immutable input must be a regular non-symlink file: ' + str(path))
    if first.st_size > 512 * 1024 * 1024:
        raise ValueError('immutable-input snapshot exceeds its file-size budget')
    digest = hashlib.sha256()
    count = 0
    with path.open('rb') as handle:
        while True:
            block = handle.read(1024 * 1024)
            if not block:
                break
            count += len(block)
            if count > 512 * 1024 * 1024:
                raise ValueError('immutable file grew beyond snapshot budget')
            digest.update(block)
    last = path.lstat()
    if (first.st_dev, first.st_ino, first.st_size, first.st_mtime_ns) != (last.st_dev, last.st_ino, last.st_size, last.st_mtime_ns) or count != first.st_size:
        raise ValueError('immutable input changed during observation: ' + str(path))
    return {'path': str(path), 'resolved': str(path.resolve()), 'bytes': count,
            'sha256': digest.hexdigest()}


def directory_fingerprint(root):
    """Port of pipecat-piper::sha256_directory, retaining its original limits."""
    root = Path(root)
    if not stat.S_ISDIR(root.lstat().st_mode):
        raise ValueError('eSpeak data root must be an ordinary directory')
    pending, files, count, size = [(root, 0)], {}, 0, 0
    while pending:
        folder, depth = pending.pop()
        if depth > 32:
            raise ValueError('eSpeak data depth exceeds the product bound')
        with os.scandir(folder) as entries:
            for entry in entries:
                count += 1
                if count > 10000:
                    raise ValueError('eSpeak entry count exceeds the product bound')
                info = entry.stat(follow_symlinks=False)
                path = Path(entry.path)
                if stat.S_ISDIR(info.st_mode):
                    pending.append((path, depth + 1))
                elif stat.S_ISREG(info.st_mode):
                    size += info.st_size
                    if size > 128 * 1024 * 1024:
                        raise ValueError('eSpeak total bytes exceed the product bound')
                    name = str(path.relative_to(root))
                    name.encode('utf-8', 'strict')
                    if '\\' in name or name in files:
                        raise ValueError('invalid or duplicate eSpeak relative filename')
                    files[name] = identity(path)
                else:
                    raise ValueError('eSpeak symlinks and special entries are refused')
    fingerprint = hashlib.sha256()
    for name in sorted(files, key=lambda item: item.encode('utf-8')):
        fingerprint.update(name.encode('utf-8'))
        fingerprint.update(b'\0')
        fingerprint.update(files[name]['sha256'].encode('ascii'))
        fingerprint.update(b'\n')
    return {'path': str(root), 'resolved': str(root.resolve()), 'entry_count_including_directories': count,
            'file_count': len(files), 'total_file_bytes': size, 'sha256': fingerprint.hexdigest(),
            'algorithm': 'sorted relative UTF-8 filename + NUL + lowercase file SHA256 hex ASCII + LF',
            'files': files}


def media_snapshot(path):
    path = Path(path)
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or stat.S_IMODE(info.st_mode) & 0o077:
        raise ValueError('synthetic media directory must be private and ordinary')
    return {'path': str(path), 'mode': stat.S_IMODE(info.st_mode),
            'entries': sorted(item.name for item in path.iterdir()),
            'scope': 'Mutable test-owned capture state, deliberately excluded from immutable model equality.'}


def main():
    EVIDENCE.mkdir(mode=0o700, exist_ok=False)
    record = {
        'schema': 'pipecat-native-optin-input-closure-v1', 'phase': 'preparing', 'start_unix': time.time(),
        'head': HEAD, 'tree': TREE, 'source': str(SOURCE), 'target': str(TARGET),
        'declared_commands': 19, 'declared_cases': 21, 'declared_stages': STAGES,
        'scope': 'Real native model and isolated SFU opt-ins only; no microphone, physical playback, provider account or production-owner qualification.',
        'requested_outer_resources': {'cpu_quota_percent': 800, 'memory_max_bytes': 34359738368, 'nice': 10, 'timeout_seconds': 3600},
        'preflight_complete': False, 'driver_invoked': False, 'inputs_before': {}, 'inputs_after': {},
        'internal_whole_seconds': 3580, 'driver_cleanup_reserve_seconds': 10,
        'production_qualification': False, 'earlier_failures_cleared': False,
    }
    path = EVIDENCE / 'inputs.json'
    observed, helper, before, directory_before, lock = {}, None, None, None, None
    directory_path = media_path = None
    status = 127
    child = None
    started = time.monotonic()
    deadline = started + 3580

    def save():
        temporary = EVIDENCE / 'inputs.json.tmp'
        temporary.write_text(json.dumps(record, indent=2) + '\n')
        temporary.replace(path)

    def observe(name, value, digest=None, size=None):
        item = identity(value)
        if (digest is not None and item['sha256'] != digest) or (size is not None and item['bytes'] != size):
            raise ValueError('immutable input does not match its original expected identity: ' + name)
        if name in observed and observed[name] != item:
            raise ValueError('inconsistent repeated identity: ' + name)
        observed[name] = item
        record['inputs_before'][name] = item
        return item

    def group_probe(pgid):
        try:
            os.killpg(pgid, 0)
            return {'present': True}
        except ProcessLookupError:
            return {'present': False}
        except OSError as error:
            return {'present': None, 'error': repr(error)}

    def cleanup_driver(process):
        cleanup = {'pgid': process.pid, 'signal_requests': [],
                   'scope': 'Signals target only the owned process group. Actual leader reap and non-atomic group observations are recorded; this is not a claim that all descendants were individually joined.'}
        cleanup['group_before'] = group_probe(process.pid)
        cleanup['leader_exit_before'] = process.poll()
        cleanup['unexpected_surviving_group_after_driver_exit'] = process.returncode is not None and cleanup['group_before']['present'] is not False
        if process.returncode is None or cleanup['group_before']['present'] is not False:
            for sig, seconds in ((signal.SIGTERM, 2), (signal.SIGKILL, 2)):
                if sig == signal.SIGKILL and process.poll() is not None and group_probe(process.pid)['present'] is False:
                    break
                request = {'signal': int(sig), 'pgid': process.pid, 'unix': time.time()}
                try:
                    os.killpg(process.pid, sig)
                    request['result'] = 'requested'
                except ProcessLookupError:
                    request['result'] = 'group absent at request'
                except OSError as error:
                    request['error'] = repr(error)
                cleanup['signal_requests'].append(request)
                try:
                    process.wait(timeout=seconds)
                except subprocess.TimeoutExpired:
                    pass
        try:
            process.wait(timeout=1)
        except subprocess.TimeoutExpired:
            pass
        cleanup['leader_reaped'] = process.poll() is not None
        cleanup['leader_exit_after'] = process.returncode
        cleanup['group_after'] = group_probe(process.pid)
        cleanup['cleanup_checks_succeeded'] = cleanup['leader_reaped'] and cleanup['group_after']['present'] is False
        return cleanup

    save()
    try:
        lock = (ROOT / 'qualification-owner-pin.lock').open('a')
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        record['preflight_lock_acquired'] = True
        if json.loads((TARGET / '.pipecat-source-owner.json').read_text()) != {'source': str(SOURCE), 'task': 'workspace-f9f576cc6c66'}:
            raise ValueError('exclusive target ownership changed')
        for name, receipt in [
            ('expanded', ROOT / 'evidence/expanded-batch-pin-r2/batch.json'),
            ('default', ROOT / 'evidence/full-workspace-rust-1.99.0-r5/gate.json'),
        ]:
            raw = receipt.read_bytes()
            previous = json.loads(raw)
            if previous.get('head') != HEAD or previous.get('tree', previous.get('base_git_tree')) != TREE or type(previous.get('exit_code')) is not int:
                raise ValueError('preceding receipt has another source or no terminal exit')
            if name == 'expanded':
                if previous.get('phase') not in ('completed_successfully', 'completed_with_failures') or previous.get('integrity_failure') or previous.get('failure') or previous['exit_code'] == 125 or not previous.get('driver', {}).get('unchanged'):
                    raise ValueError('expanded batch is not completely terminal with intact inputs')
                if any(not stage.get('source_unchanged') for stage in previous.get('stages', [])):
                    raise ValueError('expanded stage source did not remain intact')
            elif previous.get('phase') != 'completed' or not previous.get('source_unchanged') or previous.get('status_after'):
                raise ValueError('default gate source/terminal state invalid')
            (EVIDENCE / ('preceding-' + name + '.json')).write_bytes(raw)
            record['preceding_' + name] = {'path': str(receipt), 'sha256': hashlib.sha256(raw).hexdigest(), 'exit_code': previous['exit_code']}
        for value, (digest, size) in FIXED.items():
            observe(str(value), value, digest, size)
        observe('executed_launcher', Path(__file__).resolve())
        (EVIDENCE / 'executed-launcher.py').write_bytes(Path(__file__).read_bytes())
        for value in (DRIVER, ROOT / 'desktop_additional_gate_pin_v4.py', ROOT / 'run_qualification_command_pin_v3.py', ROOT / 'run_full_gate.py', CONFIG, PIPER, SELECTION):
            (EVIDENCE / value.name).write_bytes(value.read_bytes())
        pin = json.loads((ROOT / 'evidence/rust-1.99.0-restore-r1/ready.json').read_text())
        for name, item in pin['executables'].items():
            observe('rust-tool-' + name, Path(item['path']), item['sha256'])
        config = json.loads(CONFIG.read_bytes())
        piper = json.loads(PIPER.read_bytes())
        selection = json.loads(SELECTION.read_bytes())
        if piper != config['piper'] or piper.get('download') is not False or piper.get('use_cuda') is not False:
            raise ValueError('flat Piper input is not the immutable reviewed CPU-only configuration')
        if config.get('input_device') != 'qualification:never-open' or config.get('output_device') != 'qualification:never-open':
            raise ValueError('synthetic fixture must retain both never-open device selectors')
        if config['media_store']['max_segment_bytes'] != 2097152 or config['media_store']['capture_generation'] != 1:
            raise ValueError('synthetic fixture quota or private-scope generation changed')
        if len(selection['recommended_whisper_cases']) != 13 or len({(c['package'], c['target'], c['test_name']) for c in selection['recommended_whisper_cases']}) != 13:
            raise ValueError('reviewed owner selection is not exactly 13 distinct cases')
        artifacts = [config['whisper_model'], config['silero_model'], piper['model'], piper['config'],
                     piper['runtime'], piper['espeak']['library'], selection['whisper_model']]
        for artifact in artifacts:
            if not re.fullmatch(r'[0-9a-f]{64}', artifact['sha256']):
                raise ValueError('original expected artifact SHA is malformed')
            observe('model:' + artifact['path'], Path(artifact['path']), artifact['sha256'])
        for relative, digest in selection['source_sha256'].items():
            if Path(relative).is_absolute() or '..' in Path(relative).parts or not relative.startswith('rust/crates/'):
                raise ValueError('invalid reviewed model source path')
            observe('selected-source:' + relative, SOURCE / relative, digest)
        directory_path = Path(piper['espeak']['data_directory'])
        if piper['espeak']['data_sha256'] != ESPEAK_EXPECTED:
            raise ValueError('original eSpeak expected fingerprint changed')
        directory_before = directory_fingerprint(directory_path)
        if directory_before['sha256'] != ESPEAK_EXPECTED:
            raise ValueError('eSpeak data differs from the original manifest')
        (EVIDENCE / 'espeak-before.json').write_text(json.dumps(directory_before, indent=2) + '\n')
        record['espeak_before'] = {key: value for key, value in directory_before.items() if key != 'files'}
        media_path = Path(config['media_store']['directory'])
        if media_path != ROOT / 'fixtures/chinese-synthetic-pin-r1/media':
            raise ValueError('synthetic capture scope escaped its original private fixture')
        record['media_before'] = media_snapshot(media_path)
        if record['media_before']['entries']:
            raise ValueError('this never-executed synthetic pin fixture must start with an empty media directory')
        spec = importlib.util.spec_from_file_location('source_manifest_helper', ROOT / 'run_full_gate.py')
        helper = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helper)
        if helper.git_value(SOURCE, ['rev-parse', 'HEAD']) != HEAD or helper.git_value(SOURCE, ['rev-parse', 'HEAD^{tree}']) != TREE or helper.git_value(SOURCE, ['status', '--porcelain=v1']):
            raise ValueError('model opt-ins require the exact clean final native source')
        before = helper.source_manifest(SOURCE)
        if before['manifest_sha256'] != '1e07f773ca2827e8db5b06175f96137b5d85bb6dcb68229d29601efe29658535':
            raise ValueError('final source file map differs from the qualified Grok/default snapshot')
        (EVIDENCE / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
        record['source_before_sha256'] = before['manifest_sha256']
        available = next(int(line.split()[1]) * 1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
        free = shutil.disk_usage(ROOT).free
        record['resources_before'] = {'mem_available_bytes': available, 'free_disk_bytes': free}
        if available < 64424509440 or free < 8589934592:
            raise ValueError('native batch requires 60GiB available memory and 8GiB free disk')
        record['preflight_complete'] = True
        record['lock_scope'] = 'Outer lock covers input/source snapshots only; each unchanged inner command runner independently holds the same exclusive lock for its entire Cargo command.'
        lock.close()
        lock = None
        record['actual_argv'] = [sys.executable, str(DRIVER), HEAD, TREE, 'full-workspace-rust-1.99.0-r5', 'optins', 'pin-r2']
        record.update(phase='launching')
        save()
        with (EVIDENCE / 'driver.stdout.log').open('wb') as log:
            child = subprocess.Popen(record['actual_argv'], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            record.update(phase='running', driver_invoked=True, driver_pid=child.pid)
            save()
            budget = deadline - time.monotonic() - 10
            if budget <= 0:
                raise subprocess.TimeoutExpired(record['actual_argv'], 0)
            record['driver_wait_budget_seconds'] = budget
            status = child.wait(timeout=budget)
        record['driver_exit_code'] = status
        record['driver_leader_reaped'] = True
        record['driver_stdout'] = identity(EVIDENCE / 'driver.stdout.log')
        batch_path = ROOT / 'evidence/optins-batch-pin-r2/batch.json'
        batch_raw = batch_path.read_bytes()
        batch = json.loads(batch_raw)
        (EVIDENCE / 'optins-batch.json').write_bytes(batch_raw)
        record['optins_batch_sha256'] = hashlib.sha256(batch_raw).hexdigest()
        record['completed_stage_count'] = batch.get('completed_stage_count')
        record['failed_stages'] = batch.get('failed_stages')
        if batch.get('head') != HEAD or batch.get('tree') != TREE or not batch.get('driver', {}).get('unchanged') or batch.get('declared_stages') != STAGES or batch.get('exit_code') != status:
            status = 125
            raise ValueError('actual native batch differs from its declared source/selection/control logic')
        if status == 0 and (batch.get('phase') != 'completed_successfully' or batch.get('completed_stage_count') != 19 or len(batch.get('stages', [])) != 19):
            status = 126
            raise ValueError('successful batch did not execute exactly the declared 19 commands')
    except Exception as error:
        record['exception'] = repr(error)
        (EVIDENCE / 'launcher-error.log').write_text(traceback.format_exc())
        if isinstance(error, subprocess.TimeoutExpired):
            status = 124
            record['driver_timed_out'] = True
        elif status == 0:
            status = 127
    finally:
        record['execution_exit_code_before_cleanup'] = status
        if child is not None:
            try:
                record['driver_cleanup'] = cleanup_driver(child)
                record['driver_native_exit_code_after_cleanup'] = child.returncode
                if not record['driver_cleanup']['cleanup_checks_succeeded'] or record['driver_cleanup']['unexpected_surviving_group_after_driver_exit']:
                    status = 125
            except Exception as error:
                record['driver_cleanup_error'] = repr(error)
                status = 125
        record['execution_exit_code_before_integrity_checks'] = status
        if lock is None:
            try:
                lock = (ROOT / 'qualification-owner-pin.lock').open('a')
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                record['postflight_lock_acquired'] = True
            except Exception as error:
                record['postflight_lock_error'] = repr(error)
                status = 125
        for name, initial in observed.items():
            try:
                actual = identity(Path(initial['path']))
                actual['unchanged'] = all(actual[key] == initial[key] for key in ('resolved', 'bytes', 'sha256'))
                record['inputs_after'][name] = actual
                if not actual['unchanged']:
                    status = 125
            except Exception as error:
                record['inputs_after'][name] = {'error': repr(error), 'unchanged': False}
                status = 125
        record['all_observed_inputs_unchanged'] = bool(observed) and len(record['inputs_after']) == len(observed) and all(item.get('unchanged') for item in record['inputs_after'].values())
        if directory_before is not None:
            try:
                directory_after = directory_fingerprint(directory_path)
                (EVIDENCE / 'espeak-after.json').write_text(json.dumps(directory_after, indent=2) + '\n')
                record['espeak_after'] = {key: value for key, value in directory_after.items() if key != 'files'}
                record['espeak_unchanged'] = directory_after == directory_before and directory_after['sha256'] == ESPEAK_EXPECTED
                if not record['espeak_unchanged']:
                    status = 125
            except Exception as error:
                record['espeak_after_error'] = repr(error)
                record['espeak_unchanged'] = False
                status = 125
        if media_path is not None:
            try:
                record['media_after'] = media_snapshot(media_path)
            except Exception as error:
                record['media_after_error'] = repr(error)
                status = 125
        if before is not None:
            try:
                after = helper.source_manifest(SOURCE)
                (EVIDENCE / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
                record['source_after_sha256'] = after['manifest_sha256']
                record['source_unchanged'] = before == after
                record['status_after'] = helper.git_value(SOURCE, ['status', '--porcelain=v1'])
                record['head_after'] = helper.git_value(SOURCE, ['rev-parse', 'HEAD'])
                record['tree_after'] = helper.git_value(SOURCE, ['rev-parse', 'HEAD^{tree}'])
                if not record['source_unchanged'] or record['status_after'] or record['head_after'] != HEAD or record['tree_after'] != TREE:
                    status = 125
            except Exception as error:
                record['source_after_error'] = repr(error)
                record['source_unchanged'] = False
                status = 125
        record['internal_elapsed_seconds_through_integrity_checks'] = time.monotonic() - started
        if record['internal_elapsed_seconds_through_integrity_checks'] > 3580:
            record['internal_budget_exceeded'] = True
            if status != 125:
                status = 124
        record.update(phase='completed', exit_code=status, end_unix=time.time())
        save()
        if lock is not None:
            lock.close()
        print(json.dumps({key: record.get(key) for key in (
            'phase', 'exit_code', 'driver_exit_code', 'completed_stage_count', 'failed_stages',
            'preflight_complete', 'all_observed_inputs_unchanged', 'espeak_unchanged',
            'source_unchanged', 'exception')}), flush=True)
    return status


if __name__ == '__main__':
    raise SystemExit(main())
