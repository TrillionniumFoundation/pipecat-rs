import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback

ROOT = Path('/home/qian-qi/workspace/pipecat-workspace-f9f576cc6c66')
BUNDLE = ROOT / 'requests/model-optins-launch-pin-r2'
SCRIPT_SHA = '97b2ba851c49ce395c66cb4eb8fcdb39cb90c696f27d0fd6a430ee00e1335c49'
HELPER_SHA = 'c6b639d10e4e0d48910d007a161d7b35e81744bd5e31f878f960bdcd452b47e4'
BUNDLE.mkdir(mode=0o700, exist_ok=False)
record = {'schema': 'pipecat-reviewed-execv-bootstrap-v1', 'phase': 'preparing',
          'start_unix': time.time(), 'requested_resource_budget': {
              'cpu_quota_percent': 800, 'memory_max_bytes': 34359738368,
              'nice': 10, 'timeout_seconds': 3600},
          'postflight_receipt': str(ROOT / 'evidence/model-inputs-pin-r2/inputs.json'),
          'scope': 'Exec replaces this process with the reviewed launcher; that launcher snapshots its own original bytes and the imported helper before and after the native batch. No extra unmanaged child is created by this bootstrap.'}

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def save():
    (BUNDLE / 'bootstrap.json').write_text(json.dumps(record, indent=2) + '\n')

try:
    payload = json.load(sys.stdin)
    original_bootstrap = sys.orig_argv[2].encode('utf-8')
    if sys.orig_argv[1] != '-c' or digest(original_bootstrap) != payload['bootstrap_sha256']:
        raise ValueError('actual bootstrap argv differs from the reviewed original')
    (BUNDLE / 'bootstrap.py').write_bytes(original_bootstrap)
    record['bootstrap_sha256'] = digest(original_bootstrap)
    raw = payload['script'].encode('utf-8')
    if len(raw) != 23993 or digest(raw) != SCRIPT_SHA:
        raise ValueError('reviewed model launcher identity mismatch')
    path = BUNDLE / 'desktop_model_optins_launcher_pin_r2.py'
    path.write_bytes(raw)
    path.chmod(0o700)
    record['script'] = {'path': str(path), 'bytes': len(raw), 'sha256': digest(raw)}
    helper = (ROOT / 'run_full_gate.py').read_bytes()
    if len(helper) != 5176 or digest(helper) != HELPER_SHA:
        raise ValueError('source-manifest helper changed')
    (BUNDLE / 'run_full_gate.py.before').write_bytes(helper)
    record['helper_sha256_before'] = digest(helper)
    prior = payload['preceding_runtime_status_observation']
    if prior.get('job_id') != '1a1b1ce641f-fc05-7ae4' or prior.get('state') not in ('succeeded', 'failed') or prior.get('exit_code') not in (0, 1) or prior.get('output_complete') is not True or prior.get('output_durable') is not True or prior.get('timed_out') is not False:
        raise ValueError('preceding expanded runtime observation is not terminal and complete')
    record['preceding_runtime_status_observation'] = prior
    prior_batch = (ROOT / 'evidence/expanded-batch-pin-r2/batch.json').read_bytes()
    if digest(prior_batch) != payload['preceding_batch_sha256']:
        raise ValueError('terminal expanded batch changed after observation')
    (BUNDLE / 'preceding-expanded-batch.json').write_bytes(prior_batch)
    record['preceding_expanded_batch_sha256'] = digest(prior_batch)
    prior_outer = (ROOT / 'requests/expanded-batch-launch-pin-r2/launcher.json').read_bytes()
    outer = json.loads(prior_outer)
    if outer.get('phase') != 'completed' or outer.get('files_unchanged') is not True or outer.get('exit_code') != prior['exit_code']:
        raise ValueError('preceding expanded launcher is not terminal and intact')
    (BUNDLE / 'preceding-expanded-launcher.json').write_bytes(prior_outer)
    record['preceding_expanded_launcher_sha256'] = digest(prior_outer)
    argv = [sys.executable, str(path)]
    record.update(phase='exec_requested', actual_argv=argv, cwd=str(ROOT),
                  same_process_pid=os.getpid(), exec_request_unix=time.time())
    save()
    os.chdir(ROOT)
    os.execv(sys.executable, argv)
except Exception as error:
    record.update(phase='preparation_failed', exit_code=127, exception=repr(error), end_unix=time.time())
    (BUNDLE / 'bootstrap-error.log').write_text(traceback.format_exc())
    save()
    print(json.dumps(record), flush=True)
    raise SystemExit(127)
