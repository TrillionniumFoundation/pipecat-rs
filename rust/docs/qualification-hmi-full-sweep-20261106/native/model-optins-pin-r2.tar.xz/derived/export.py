import base64
import hashlib
import io
import json
from pathlib import Path
import re
import stat
import sys
import tarfile
import time

ROOT = Path('/home/qian-qi/workspace/pipecat-workspace-f9f576cc6c66')
OUT = ROOT / 'exports/model-optins-pin-r2'
HEAD = '0cc16e8123cb05aaad480d5ab7860a267d998bac'
TREE = 'aec037b9cf2be53fcf6f85fdc149382942277702'
STAGES = ['local-sfu', 'chinese-synthetic', 'piper-genuine-owner', 'piper-invalid-bounds',
          'piper-cancel-reload', 'piper-long-pipeline'] + [f'whisper-owner-{i:02d}' for i in range(1, 14)]

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_size > 32 * 1024 * 1024:
        raise ValueError('evidence is not a bounded regular file: ' + str(path))
    raw = path.read_bytes()
    after = path.lstat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns) or len(raw) != before.st_size:
        raise ValueError('evidence changed during observation')
    return raw

OUT.mkdir(mode=0o700, exist_ok=False)
inputs = json.loads(read(ROOT / 'evidence/model-inputs-pin-r2/inputs.json'))
batch = json.loads(read(ROOT / 'evidence/optins-batch-pin-r2/batch.json'))
if inputs.get('phase') != 'completed' or inputs.get('exit_code') != 0 or not all(inputs.get(k) is True for k in ['source_unchanged', 'all_observed_inputs_unchanged', 'espeak_unchanged']) or not inputs.get('driver_cleanup', {}).get('cleanup_checks_succeeded'):
    raise ValueError('model input-closure receipt is not terminal and intact')
if batch.get('head') != HEAD or batch.get('tree') != TREE or batch.get('phase') != 'completed_successfully' or batch.get('completed_stage_count') != 19 or batch.get('declared_stages') != STAGES or batch.get('exit_code') != 0:
    raise ValueError('this export requires the already observed final 19-command result')
files = {}
skipped = []

def add_directory(directory, prefix):
    if not stat.S_ISDIR(directory.lstat().st_mode):
        raise ValueError('not an ordinary evidence directory')
    for path in sorted(directory.rglob('*')):
        rel = path.relative_to(directory)
        if '__pycache__' in rel.parts:
            skipped.append({'path': str(path), 'reason': 'reproducible import cache'})
            continue
        if path.is_symlink():
            raise ValueError('evidence symlink refused')
        if path.is_dir():
            continue
        if len(rel.parts) > 5:
            raise ValueError('unexpected evidence depth')
        files[prefix + '/' + str(rel)] = (path, read(path))
        if len(files) > 600 or sum(len(v[1]) for v in files.values()) > 128 * 1024 * 1024:
            raise ValueError('evidence exceeds fixed export budget')

for relative in ['evidence/model-inputs-pin-r2', 'evidence/optins-batch-pin-r2',
                 'requests/model-optins-launch-pin-r2'] + ['evidence/' + s + '-pin-r2' for s in STAGES]:
    add_directory(ROOT / relative, relative)
sfu_raw = files['evidence/local-sfu-pin-r2/command.log'][1]
sfu_paths = re.findall(rb'evidence retained at (/tmp/pipecat-livekit-sfu-[0-9-]+)', sfu_raw)
if len(sfu_paths) != 3 or len(set(sfu_paths)) != 3:
    raise ValueError('expected three distinct retained owned SFU evidence directories')
for value in sfu_paths:
    path = Path(value.decode('ascii'))
    if path.parent != Path('/tmp'):
        raise ValueError('SFU evidence path escaped known temporary root')
    add_directory(path, 'sfu-evidence/' + path.name)
summary_re = re.compile(rb'(?m)^test result: ok\. ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored; ([0-9]+) measured; ([0-9]+) filtered out; finished in ([0-9.]+)s$')
counts = []
for stage in STAGES:
    prefix = 'evidence/' + stage + '-pin-r2/'
    gate_raw = files[prefix + 'gate.json'][1]
    gate = json.loads(gate_raw)
    raw = files[prefix + 'command.log'][1]
    summaries = list(summary_re.finditer(raw))
    expected = 3 if stage == 'local-sfu' else 1
    if gate.get('head') != HEAD or gate.get('base_git_tree') != TREE or gate.get('exit_code') != 0 or not gate.get('source_unchanged') or len(summaries) != 1:
        raise ValueError('stage gate or raw summary changed: ' + stage)
    m = summaries[0]
    if tuple(map(int, m.groups()[:4])) != (expected, 0, 0, 0):
        raise ValueError('actual selected case count differs: ' + stage)
    counts.append({'stage': stage, 'argv': gate['argv'], 'head': gate['head'], 'tree': gate['base_git_tree'],
                   'gate_sha256': sha(gate_raw), 'raw_log_bytes': len(raw), 'raw_log_sha256': sha(raw),
                   'passed': expected, 'failed': 0, 'ignored': 0, 'filtered_out': int(m.group(5)),
                   'harness_reported_seconds': float(m.group(6)),
                   'gate_recorded_interval_seconds_including_post_source_checks': gate['end_unix'] - gate['start_unix'],
                   'summary_raw': m.group(0).decode('ascii')})
chinese = files['evidence/chinese-synthetic-pin-r2/command.log'][1]
json_lines = []
for line in chinese.splitlines():
    if not line.startswith(b'{'):
        continue
    try:
        json_lines.append(json.loads(line.decode('utf-8', 'strict')))
    except (ValueError, UnicodeDecodeError):
        continue
if sum(item.get('scope') == 'offline_synthetic_chinese_tts_to_stt' for item in json_lines) != 8:
    raise ValueError('original Chinese log lacks exactly eight complete output records')
derived = {'schema': 'pipecat-final-native-optin-counts-v1', 'head': HEAD, 'tree': TREE,
           'commands': len(counts), 'passed_cases': sum(i['passed'] for i in counts), 'stages': counts,
           'chinese_json_lines': json_lines, 'chinese_raw_sha256': sha(chinese),
           'scope': '19 commands / 21 selected Rust cases; eight Chinese samples belong to one case. SFU tracks and model inputs are synthetic; no physical audio, account or production-owner qualification.',
           'duration_scope': 'Libtest-reported execution and gate-recorded intervals are separate; gate intervals include final source hashing, not remote control-plane wait.',
           'retained_sfu_directories': [p.decode('ascii') for p in sfu_paths]}
manifest = {'schema': 'pipecat-final-model-optin-originals-v1', 'head': HEAD, 'tree': TREE,
            'observed_unix': time.time(), 'files': [], 'skipped': skipped}
for name, (path, raw) in sorted(files.items()):
    item = {'name': name, 'remote_path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}
    if path.name in ['source-before.json', 'source-after.json']:
        o = json.loads(raw)
        canonical = sha(json.dumps(o['files'], sort_keys=True, separators=(',', ':')).encode())
        if canonical != o['manifest_sha256']:
            raise ValueError('source canonical map mismatch')
        item['source_files_canonical_sha256'] = canonical
    manifest['files'].append(item)
manifest.update(original_count=len(files), original_bytes=sum(len(v[1]) for v in files.values()))
manifest_raw = (json.dumps(manifest, indent=2) + '\n').encode()
derived_raw = (json.dumps(derived, indent=2, ensure_ascii=False) + '\n').encode()
(OUT / 'original-files-manifest.json').write_bytes(manifest_raw)
(OUT / 'selected-cases.json').write_bytes(derived_raw)
(OUT / 'export.py').write_text(sys.orig_argv[2])
archive = OUT / 'model-optins-pin-r2.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6, format=tarfile.PAX_FORMAT) as tf:
    members = [('originals/' + name, raw) for name, (path, raw) in sorted(files.items())]
    members += [('original-files-manifest.json', manifest_raw), ('derived/selected-cases.json', derived_raw),
                ('derived/export.py', sys.orig_argv[2].encode())]
    for name, raw in members:
        item = tarfile.TarInfo(name)
        item.size = len(raw)
        item.mode = 0o600
        item.mtime = 0
        tf.addfile(item, io.BytesIO(raw))
raw = archive.read_bytes()
encoded = base64.b64encode(raw).decode('ascii')
parts = []
for start in range(0, len(encoded), 60000):
    part = encoded[start:start + 60000]
    path = OUT / ('part-' + str(len(parts)).zfill(3) + '.b64')
    path.write_text(part)
    parts.append({'path': str(path), 'bytes': len(part), 'sha256': sha(part.encode())})
delivery = {'schema': 'pipecat-final-model-optin-delivery-v1', 'archive_path': str(archive),
            'archive_bytes': len(raw), 'archive_sha256': sha(raw), 'original_count': len(files),
            'original_bytes': manifest['original_bytes'], 'original_manifest_bytes': len(manifest_raw),
            'original_manifest_sha256': sha(manifest_raw), 'parts': parts,
            'commands': derived['commands'], 'passed_cases': derived['passed_cases'], 'completed_unix': time.time()}
(OUT / 'delivery.json').write_text(json.dumps(delivery, indent=2) + '\n')
print(json.dumps(delivery), flush=True)
