import base64
import hashlib
import io
import json
from pathlib import Path
import re
import stat
import sys
import tarfile
import time

ROOT = Path('/home/qian-qi/workspace/pipecat-workspace-f9f576cc6c66')
OUT = ROOT / 'exports/final-runtime-pin-r1'
BASE = '0cc16e8123cb05aaad480d5ab7860a267d998bac'
Q = 'c1c3addb07dde0a143462c10961ff2494eeba90a'
STAGES = ['local-sfu', 'chinese-synthetic', 'piper-genuine-owner', 'piper-invalid-bounds',
          'piper-cancel-reload', 'piper-long-pipeline'] + [f'whisper-owner-{i:02d}' for i in range(1, 14)]
EXCLUDED = {
    'requests/smart-turn-wheel-reference-pin-r3/onnxruntime-1.21.0-cp312-cp312-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl':
        (16019285, '9a04aafb802c1e5573ba4552f8babcb5021b041eb4cfa802c9b7644ca3510eca'),
    'requests/smart-turn-wheel-reference-pin-r3/runtime/libonnxruntime.so.1.21.0':
        (20571088, 'a0df84fae0f09d9eca3d6919f685ba435f1ae6cb628e128b69bcf2a2b965504c'),
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_size > 32 * 1024 * 1024:
        raise ValueError('expected bounded ordinary evidence file: ' + str(path))
    raw = path.read_bytes()
    after = path.lstat()
    signature = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns)
    if signature(before) != signature(after) or len(raw) != before.st_size:
        raise ValueError('evidence changed while read: ' + str(path))
    return raw


OUT.mkdir(mode=0o700, exist_ok=False)
files, excluded, skipped = {}, [], []


def add(path):
    relative = str(path.relative_to(ROOT))
    raw = read(path)
    if relative in EXCLUDED:
        if (len(raw), sha(raw)) != EXCLUDED[relative]:
            raise ValueError('large retained official artifact changed: ' + relative)
        excluded.append({'name': relative, 'remote_path': str(path), 'bytes': len(raw),
                         'sha256': sha(raw), 'reason': 'Large official distribution artifact retained unchanged on desktop; original download/extraction identities and all raw execution evidence are included.'})
        return
    if relative in files:
        raise ValueError('duplicate archive original: ' + relative)
    files[relative] = (path, raw)
    if len(files) > 1200 or sum(len(v[1]) for v in files.values()) > 128 * 1024 * 1024:
        raise ValueError('export exceeded its fixed file/byte budget')


def add_directory(relative):
    directory = ROOT / relative
    if not stat.S_ISDIR(directory.lstat().st_mode):
        raise ValueError('expected ordinary evidence directory: ' + relative)
    for path in sorted(directory.rglob('*')):
        rel = path.relative_to(directory)
        if '__pycache__' in rel.parts:
            skipped.append({'remote_path': str(path), 'reason': 'Reproducible Python import cache'})
            continue
        if path.is_symlink():
            raise ValueError('evidence symlink refused: ' + str(path))
        if path.is_dir():
            continue
        if len(rel.parts) > 6:
            raise ValueError('unexpected evidence depth')
        add(path)


directories = [
    'evidence/webrtc-stress-pin-r1', 'requests/webrtc-stress-launch-pin-r1',
    'evidence/aishell-human-pin-r1', 'requests/aishell-human-launch-pin-r1',
    'evidence/smart-turn-wheel-reference-pin-r3', 'requests/smart-turn-wheel-reference-pin-r3',
    'requests/smart-turn-wheel-launch-pin-r3', 'evidence/final-diagnostic-source-preparation-r1',
    'requests/moq-diagnostic-launch-pin-r1', 'evidence/moq-diagnostic-pin-r1',
] + ['requests/' + stage + '-pin-r2' for stage in STAGES]

# All records here are already terminal. This exporter takes no Cargo/target lock,
# executes no native program, and never reads or modifies the current source tree.
receipts = {
    'webrtc': ('evidence/webrtc-stress-pin-r1/repetitions.json', BASE, 'exit_code'),
    'aishell': ('evidence/aishell-human-pin-r1/result.json', BASE, 'wrapper_exit_code'),
    'c3': ('evidence/smart-turn-wheel-reference-pin-r3/reference.json', BASE, 'exit_code'),
    'source_preparation': ('evidence/final-diagnostic-source-preparation-r1/preparation.json', Q, 'exit_code'),
    'moq': ('evidence/moq-diagnostic-pin-r1/repetitions.json', Q, 'exit_code'),
}
reports = {}
for key, (relative, head, exit_key) in receipts.items():
    raw = read(ROOT / relative)
    value = json.loads(raw)
    if value.get('phase') != 'completed' or value.get('head') != head or type(value.get(exit_key)) is not int:
        raise ValueError('evidence is not the expected terminal original: ' + relative)
    reports[key] = value
for directory in directories:
    add_directory(directory)
for relative in ['desktop_moq_diagnostic_pin_r1.py',
                 'run_full_gate.py', 'requests/moq-diagnostic-pin-r1.case-names.json',
                 'requests/moq-diagnostic-pin-r1.source-contract.json']:
    add(ROOT / relative)
if set(item['name'] for item in excluded) != set(EXCLUDED):
    raise ValueError('both explicitly retained large C3 artifacts must be accounted for')

summary = re.compile(rb'(?m)^test result: ok\. ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored; ([0-9]+) measured; ([0-9]+) filtered out; finished in ([0-9.]+)s$')
webrtc = reports['webrtc']
if (webrtc.get('exit_code') != 0 or webrtc.get('successful_repetitions') != 100 or
        webrtc.get('completed_repetitions') != 100 or len(webrtc.get('rounds', [])) != 100):
    raise ValueError('the observed WebRTC 100-round terminal record changed')
webrtc_rounds = []
for number, entry in enumerate(webrtc['rounds'], 1):
    relative = f'evidence/webrtc-stress-pin-r1/round-{number:03d}.log'
    raw = files[relative][1]
    matches = list(summary.finditer(raw))
    if (entry.get('round') != number or entry.get('exit_code') != 0 or
            entry.get('log_sha256') != sha(raw) or len(matches) != 1 or
            tuple(map(int, matches[0].groups()[:4])) != (1, 0, 0, 0)):
        raise ValueError('WebRTC original round receipt/raw mismatch')
    webrtc_rounds.append({'round': number, 'raw_bytes': len(raw), 'raw_sha256': sha(raw),
                          'harness_reported_seconds': float(matches[0].group(6))})

moq = reports['moq']
expected_names = json.loads(files['requests/moq-diagnostic-pin-r1.case-names.json'][1])
moq_rounds = []
for entry in moq.get('rounds', []):
    number = entry['round']
    relative = f'evidence/moq-diagnostic-pin-r1/round-{number:02d}.stdout.log'
    raw = files[relative][1]
    matches = list(summary.finditer(raw))
    case_names = sorted(match.group(1).decode('utf-8') for match in
                        re.finditer(rb'(?m)^test (.+) \.\.\. ok$', raw))
    item = {'round': number, 'raw_bytes': len(raw), 'raw_sha256': sha(raw),
            'original_exit_code': entry.get('original_exit_code'),
            'wrapper_exit_code': entry.get('wrapper_exit_code'),
            'all_original_names_passed_once': case_names == expected_names,
            'summary_count': len(matches)}
    if len(matches) == 1:
        item.update(passed=int(matches[0].group(1)), failed=int(matches[0].group(2)),
                    ignored=int(matches[0].group(3)), harness_reported_seconds=float(matches[0].group(6)))
    moq_rounds.append(item)

model_supplement = []
for stage in STAGES:
    relative = 'requests/' + stage + '-pin-r2/runner-execution.json'
    raw = files[relative][1]
    value = json.loads(raw)
    if (value.get('phase') != 'completed' or value.get('runner_exit_code') != 0 or
            value.get('wrapper_exit_code') != 0 or value.get('scripts_unchanged') is not True):
        raise ValueError('model wrapper terminal record differs: ' + stage)
    model_supplement.append({'stage': stage, 'path': relative, 'bytes': len(raw),
                             'sha256': sha(raw), 'runner_exit_code': 0, 'wrapper_exit_code': 0})

derived = {
    'schema': 'pipecat-final-runtime-delivery-analysis-v1',
    'source_groups': {'original_qualification': BASE, 'final_diagnostic_and_lint': Q},
    'webrtc': {'unique_coverage_cases': 1, 'completed_repetitions': 100,
               'binary': webrtc.get('binary'), 'whole_job_elapsed_seconds': webrtc.get('whole_job_elapsed_seconds'),
               'rounds': webrtc_rounds, 'original_failure_history_cleared': False},
    'moq': {'original_case_count': len(expected_names), 'attempted_rounds': len(moq_rounds),
            'exit_code': moq['exit_code'], 'binary': moq.get('binary'), 'rounds': moq_rounds,
            'original_failure_history_cleared': False},
    'aishell': {'inference_attempts': reports['aishell'].get('inference_attempts'),
                'wrapper_exit_code': reports['aishell']['wrapper_exit_code'], 'quality_passed': False},
    'c3': {'native_exit_code': reports['c3'].get('native_exit_code'),
           'comparison_exit_code': reports['c3'].get('comparison_exit_code'),
           'exit_code': reports['c3']['exit_code']},
    'strict': {'included': False, 'reason': 'The active strict job is excluded from this sealed original-byte archive; its terminal receipt and all raw logs will be delivered separately.'},
    'model_wrapper_supplement': model_supplement,
    'scope': 'Original bytes. Model request directories supplement the previously delivered 131-original archive; no native case is rerun or newly counted. C3 native execution and probability comparison are distinct. Q evidence in this archive is only source preparation and the completed MoQ window; the active strict job is excluded. Earlier full matrices remain bound to 0cc.',
}
manifest = {'schema': 'pipecat-final-runtime-originals-v1', 'observed_unix': time.time(),
            'directories': directories, 'files': [], 'excluded_retained_artifacts': excluded,
            'skipped': skipped, 'source_groups': derived['source_groups'],
            'canonical_scope': 'source_files_canonical_sha256 hashes canonical files content; sha256 always hashes the complete original file bytes.'}
for name, (path, raw) in sorted(files.items()):
    if read(path) != raw:
        raise ValueError('an original changed between collection and publication: ' + name)
    item = {'name': name, 'remote_path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}
    if path.suffix == '.json':
        try:
            value = json.loads(raw)
        except ValueError:
            value = None
        if isinstance(value, dict) and isinstance(value.get('files'), list) and isinstance(value.get('manifest_sha256'), str):
            canonical = sha(json.dumps(value['files'], sort_keys=True, separators=(',', ':')).encode())
            if canonical != value['manifest_sha256']:
                raise ValueError('source map canonical digest mismatch: ' + name)
            item['source_files_canonical_sha256'] = canonical
    manifest['files'].append(item)
manifest.update(original_count=len(files), original_bytes=sum(len(v[1]) for v in files.values()))
manifest_raw = (json.dumps(manifest, indent=2) + '\n').encode()
derived_raw = (json.dumps(derived, indent=2, ensure_ascii=False) + '\n').encode()
(OUT / 'original-files-manifest.json').write_bytes(manifest_raw)
(OUT / 'runtime-summary.json').write_bytes(derived_raw)
(OUT / 'export.py').write_text(sys.orig_argv[2])
archive = OUT / 'final-runtime-pin-r1.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6, format=tarfile.PAX_FORMAT) as stream:
    members = [('originals/' + name, raw) for name, (path, raw) in sorted(files.items())]
    members += [('original-files-manifest.json', manifest_raw), ('derived/runtime-summary.json', derived_raw),
                ('derived/export.py', sys.orig_argv[2].encode())]
    for name, raw in members:
        item = tarfile.TarInfo(name)
        item.size, item.mode, item.mtime = len(raw), 0o600, 0
        stream.addfile(item, io.BytesIO(raw))
raw = archive.read_bytes()
encoded = base64.b64encode(raw).decode('ascii')
parts = []
for start in range(0, len(encoded), 60000):
    part = encoded[start:start + 60000]
    path = OUT / ('part-' + str(len(parts)).zfill(3) + '.b64')
    path.write_text(part)
    parts.append({'path': str(path), 'bytes': len(part), 'sha256': sha(part.encode())})
delivery = {'schema': 'pipecat-final-runtime-delivery-v1', 'archive_path': str(archive),
            'archive_bytes': len(raw), 'archive_sha256': sha(raw), 'original_count': len(files),
            'original_bytes': manifest['original_bytes'], 'original_manifest_bytes': len(manifest_raw),
            'original_manifest_sha256': sha(manifest_raw), 'parts': parts,
            'excluded_retained_artifacts': excluded, 'completed_unix': time.time()}
(OUT / 'delivery.json').write_text(json.dumps(delivery, indent=2) + '\n')
print(json.dumps(delivery), flush=True)
