import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import time
import traceback

ROOT = Path('/home/qian-qi/workspace/pipecat-workspace-f9f576cc6c66')
SOURCE, TARGET = ROOT / 'source-pin', ROOT / 'target-pin'
EVIDENCE = ROOT / 'evidence/final-diagnostic-source-preparation-r1'
BASE = '0cc16e8123cb05aaad480d5ab7860a267d998bac'
HEAD = 'c1c3addb07dde0a143462c10961ff2494eeba90a'
TREE = '4df0d197540551ed9b74d4e11c0936e5bedee5f5'
CONTRACT_SHA = 'c255d772305af493508754d78797cad6a8abb827aa40669b2b392b5c0b3256a3'
HELPER_SHA = 'c6b639d10e4e0d48910d007a161d7b35e81744bd5e31f878f960bdcd452b47e4'
EVIDENCE.mkdir(mode=0o700, exist_ok=False)
started = time.monotonic()
record = {'schema': 'pipecat-published-source-preparation-v1', 'phase': 'preparing',
          'base': BASE, 'head': HEAD, 'tree': TREE, 'start_unix': time.time(),
          'commands': [], 'inputs': [], 'native_test_invocations': 0,
          'requested_resource_budget': {'timeout_seconds': 180, 'cpu_quota_percent': 100,
                                        'memory_max_bytes': 1073741824, 'nice': 10}}
status = 127
lock = None

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def save():
    (EVIDENCE / 'preparation.json').write_text(json.dumps(record, indent=2) + '\n')

def group_present(pid):
    try:
        os.killpg(pid, 0)
        return True
    except ProcessLookupError:
        return False

def run(label, argv, timeout=15):
    item = {'label': label, 'argv': argv, 'start_unix': time.time(), 'timeout_seconds': timeout,
            'phase': 'launching', 'signal_requests': []}
    record['commands'].append(item)
    child = None
    out = EVIDENCE / (label + '.stdout.log')
    err = EVIDENCE / (label + '.stderr.log')
    save()
    try:
        with out.open('wb') as stdout, err.open('wb') as stderr:
            child = subprocess.Popen(argv, cwd=ROOT, stdout=stdout, stderr=stderr, start_new_session=True)
            item.update(phase='running', pid=child.pid, pgid=child.pid)
            save()
            item['original_exit_code'] = child.wait(timeout=min(timeout, max(0, 150 - (time.monotonic() - started))))
    except subprocess.TimeoutExpired:
        item['timed_out'] = True
        raise
    finally:
        if child is not None:
            present = group_present(child.pid)
            item['group_after_initial_wait'] = present
            if child.poll() is None or present:
                for sig, seconds in [(signal.SIGTERM, 2), (signal.SIGKILL, 1)]:
                    if child.poll() is not None and not group_present(child.pid):
                        break
                    try:
                        os.killpg(child.pid, sig)
                        item['signal_requests'].append({'signal': int(sig), 'result': 'requested'})
                    except ProcessLookupError:
                        item['signal_requests'].append({'signal': int(sig), 'result': 'already absent'})
                    try:
                        child.wait(timeout=seconds)
                    except subprocess.TimeoutExpired:
                        pass
            item.update(leader_reaped=child.poll() is not None, leader_exit_code=child.returncode,
                        final_group_present=group_present(child.pid))
        for name, path in [('stdout', out), ('stderr', err)]:
            if path.exists():
                raw = path.read_bytes()
                item[name] = {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}
        item.update(phase='completed', end_unix=time.time())
        save()
    if item.get('original_exit_code') != 0 or not item.get('leader_reaped') or item.get('final_group_present'):
        raise ValueError('preparation command failed or containment incomplete: ' + label)
    return out.read_bytes()

def git(label, args, timeout=15):
    return run(label, ['/usr/bin/git', '-C', str(SOURCE), *args], timeout)

try:
    payload = json.load(sys.stdin)
    original_script = sys.orig_argv[2].encode('utf-8')
    if sha(original_script) != payload['bootstrap_sha256']:
        raise ValueError('preparation script identity mismatch')
    (EVIDENCE / 'executed-preparation.py').write_bytes(original_script)
    record['script_sha256'] = sha(original_script)
    lock = (ROOT / 'qualification-owner-pin.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    record['lock_acquired'] = True
    if json.loads((TARGET / '.pipecat-source-owner.json').read_bytes()) != {'source': str(SOURCE), 'task': 'workspace-f9f576cc6c66'}:
        raise ValueError('exclusive target ownership mismatch')
    api = payload['preceding_runtime_status_observation']
    if api.get('job_id') != '1a1b1fe3c1b-fc05-7bea' or api.get('state') != 'failed' or api.get('exit_code') != 1 or api.get('output_complete') is not True or api.get('output_durable') is not True or api.get('timed_out') is not False:
        raise ValueError('C3 authoritative terminal observation missing')
    record['preceding_runtime_status_observation'] = api
    c3_raw = (ROOT / 'evidence/smart-turn-wheel-reference-pin-r3/reference.json').read_bytes()
    c3 = json.loads(c3_raw)
    if sha(c3_raw) != 'db6ce0db08d63c04adaaf15c63af31ccb9a3f2ada54ec2ba54a7600d22eeea59' or c3.get('phase') != 'completed' or not c3.get('source_unchanged') or not c3.get('all_observed_files_unchanged') or not c3.get('process_cleanup', {}).get('checks_succeeded'):
        raise ValueError('C3 receipt not terminal and intact')
    (EVIDENCE / 'preceding-c3.json').write_bytes(c3_raw)
    helper_raw = (ROOT / 'run_full_gate.py').read_bytes()
    if len(helper_raw) != 5176 or sha(helper_raw) != HELPER_SHA:
        raise ValueError('canonical source helper changed')
    (EVIDENCE / 'run_full_gate.py.before').write_bytes(helper_raw)
    spec = importlib.util.spec_from_file_location('source_manifest_helper', ROOT / 'run_full_gate.py')
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    if git('base-head', ['rev-parse', 'HEAD']).decode().strip() != BASE or git('base-status', ['status', '--porcelain=v1']).strip():
        raise ValueError('source is not the expected clean original checkout')
    before = helper.source_manifest(SOURCE)
    (EVIDENCE / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
    record['source_before_sha256'] = before['manifest_sha256']
    if before['manifest_sha256'] != '1e07f773ca2827e8db5b06175f96137b5d85bb6dcb68229d29601efe29658535':
        raise ValueError('original source map changed')
    definitions = [
        ('runner', ROOT / 'desktop_moq_diagnostic_pin_r1.py', 33499, 'bfbba41f328657e6db1bc3498a0636d2209e84ae163ff51c0912bc277d94e8af'),
        ('contract', ROOT / 'requests/moq-diagnostic-pin-r1.source-contract.json', 11511, CONTRACT_SHA),
        ('names', ROOT / 'requests/moq-diagnostic-pin-r1.case-names.json', 6882, 'e87d053861a5d96597d28371305e85676864b27477334abcf218a843539f2a41')]
    for key, path, size, checksum in definitions:
        raw = payload[key].encode('utf-8')
        if len(raw) != size or sha(raw) != checksum:
            raise ValueError('published input identity mismatch: ' + key)
        if path.exists():
            if not stat.S_ISREG(path.lstat().st_mode) or path.read_bytes() != raw:
                raise ValueError('an existing preparation input differs: ' + str(path))
        else:
            with path.open('xb') as handle:
                handle.write(raw)
        (EVIDENCE / (key + '.original')).write_bytes(raw)
        record['inputs'].append({'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)})
    contract = json.loads(payload['contract'])
    if contract.get('base') != BASE or contract.get('head') != HEAD or contract.get('tree') != TREE or len(contract.get('changed_paths', [])) != 102:
        raise ValueError('root source contract identifies another revision')
    git('fetch-published', ['fetch', '--no-tags', 'https://github.com/TrillionniumFoundation/pipecat-rs.git', HEAD], 90)
    tree = git('published-tree', ['rev-parse', HEAD + '^{tree}']).decode().strip()
    changes = sorted(p.decode('utf-8') for p in git('published-diff', ['diff', '--no-renames', '--name-only', '-z', BASE, HEAD]).split(b'\0') if p)
    if tree != TREE or changes != sorted(contract['changed_paths']):
        raise ValueError('public fetched tree or complete diff does not match the contract')
    record['changed_paths'] = changes
    git('checkout-published', ['checkout', '--detach', HEAD], 20)
    if git('final-head', ['rev-parse', 'HEAD']).decode().strip() != HEAD or git('final-status', ['status', '--porcelain=v1']).strip():
        raise ValueError('new source checkout is not clean at Q')
    after = helper.source_manifest(SOURCE)
    (EVIDENCE / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
    record['source_after_sha256'] = after['manifest_sha256']
    if after['manifest_sha256'] != contract['source_manifest_sha256']:
        raise ValueError('complete Q source canonical map mismatch')
    for relative, expected_sha in contract['source_sha256'].items():
        if sha((SOURCE / relative).read_bytes()) != expected_sha:
            raise ValueError('reviewed source bytes changed: ' + relative)
    record['new_source_contract_verified'] = True
    status = 0
except Exception as error:
    record['exception'] = repr(error)
    (EVIDENCE / 'error.log').write_text(traceback.format_exc())
    status = 124 if isinstance(error, subprocess.TimeoutExpired) else 127
finally:
    try:
        raw = (ROOT / 'run_full_gate.py').read_bytes()
        (EVIDENCE / 'run_full_gate.py.after').write_bytes(raw)
        record['helper_unchanged'] = len(raw) == 5176 and sha(raw) == HELPER_SHA
        record['staged_inputs_unchanged'] = all(len(Path(i['path']).read_bytes()) == i['bytes'] and sha(Path(i['path']).read_bytes()) == i['sha256'] for i in record['inputs'])
        if not record['helper_unchanged'] or not record['staged_inputs_unchanged']:
            status = 125
    except Exception as error:
        record['integrity_error'] = repr(error)
        status = 125
    record.update(phase='completed', exit_code=status, elapsed_seconds=time.monotonic() - started, end_unix=time.time())
    save()
    if lock is not None:
        lock.close()
    print(json.dumps({k: record.get(k) for k in ['phase', 'exit_code', 'head', 'tree', 'source_before_sha256', 'source_after_sha256', 'new_source_contract_verified', 'helper_unchanged', 'staged_inputs_unchanged', 'exception']}), flush=True)
raise SystemExit(status)
