#!/usr/bin/env python3
"""One fixed public AISHELL WAV through current-source stt_fixture, offline only.

The caller must enforce an owned-job 600 s deadline, CPUQuota=200%, MemoryMax=8 GiB,
and nice 10. This script never starts a device, Hepta owner/conversation, download
command, or retry. A zero exit means execution/identity checks, not a quality gate.
"""
import fcntl
import hashlib
import importlib.util
import io
import json
import os
import pathlib
import re
import signal
import stat
import struct
import subprocess
import sys
import time
import traceback
import wave

ROOT = pathlib.Path('/home/qian-qi/workspace/pipecat-workspace-f9f576cc6c66')
HISTORICAL = pathlib.Path('/home/qian-qi/workspace/hepta-hmi-20261029')
REFERENCE = '广州市房地产中介协会分析'
REFERENCE_SHA = '401af2278283e9f79fb83d46d7b2ab8639f8c9947f924229194f8306e2fd73ee'
SETTINGS = {'language': 'zh', 'no_speech_probability': 0.4,
            'initial_prompt': '以下是简体中文语音。', 'temperature': 0.0,
            'translate_to_english': False, 'strategy': {'beam_search': {'beam_size': 5}}}
INPUTS = {
    'config': (HISTORICAL / 'qualification-speech-release.json', 2702,
               'd6fcd5f1a04d0deae47fea2672b1c78707a1b2f136136faa33e05477cf77c1c6'),
    'model': (HISTORICAL / 'assets/whisper-base.bin', 147951465,
              '60ed5bc3dd14eea856493d334349b405782ddcaf0028d4b5df4088345fba2efe'),
    'wav': (HISTORICAL / 'assets/aishell-human.wav', 137036,
            '2f9fc9c912bb71c85fb286cb88b599c81efb8f727c727a5ea8f6d1c89c55ac13'),
    'provenance': (HISTORICAL / 'human-chinese-source-actual.json', 700,
                   '1f67bee54368ee8319a2c4bdd0087b5141dfce32fcaf9430423de37d4c1c17e2'),
}
STT_SOURCE = 'rust/crates/pipecat-hepta/examples/stt_fixture.rs'
STT_SOURCE_SHA = '80e684c447625fdb35401bf1622db9b6b47279bc46ed5b1283b901dc619ef25a'


class StageFailure(RuntimeError):
    def __init__(self, label, code):
        super().__init__(label + ' did not complete successfully')
        self.code = code


def sha(path):
    digest = hashlib.sha256()
    with pathlib.Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            digest.update(chunk)
    return digest.hexdigest()


def file_identity(path):
    path = pathlib.Path(path)
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError('input must be an ordinary file: ' + str(path))
    digest = sha(path)
    after = path.lstat()
    fields = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns)
    if fields(before) != fields(after):
        raise ValueError('file metadata changed while hashing: ' + str(path))
    return {'path': str(path), 'bytes': before.st_size, 'sha256': digest}


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def same_settings(actual):
    if not isinstance(actual, dict) or set(actual) != set(SETTINGS):
        return False
    for key, expected in SETTINGS.items():
        if key in ('temperature', 'no_speech_probability'):
            value = actual[key]
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                return False
            # WhisperSettings declares these fields f32. Compare exactly at that
            # representation, not with a relaxed numeric or recognition tolerance.
            if struct.pack('!f', value) != struct.pack('!f', expected):
                return False
        elif actual[key] != expected:
            return False
    return actual['translate_to_english'] is False


def reap_after_failure(process):
    cleanup_deadline = time.monotonic() + 10
    receipt = {'pid': process.pid, 'pgid': process.pid, 'term_requested': False,
               'kill_requested': False, 'leader_reaped': process.poll() is not None,
               'group_probes': [], 'errors': []}

    def probe_group(stage):
        try:
            os.killpg(process.pid, 0)
            value = {'stage': stage, 'present': True}
        except ProcessLookupError:
            value = {'stage': stage, 'present': False}
        except OSError as error:
            value = {'stage': stage, 'present': None, 'error': repr(error)}
        receipt['group_probes'].append(value)
        return value['present']

    def request_group_signal(sig, field):
        try:
            os.killpg(process.pid, sig)
            receipt[field] = True
        except ProcessLookupError:
            pass
        except OSError as error:
            receipt['errors'].append(repr(error))

    def wait_leader():
        if process.poll() is None:
            remaining = max(0, min(5, cleanup_deadline - time.monotonic()))
            try:
                process.wait(timeout=remaining)
            except subprocess.TimeoutExpired:
                pass

    # start_new_session=True made this exact child's PID its owned PGID. Even
    # an exited/reaped leader is not proof that compiler descendants are gone.
    if probe_group('before_term') is not False:
        request_group_signal(signal.SIGTERM, 'term_requested')
    wait_leader()
    if probe_group('after_term') is not False:
        request_group_signal(signal.SIGKILL, 'kill_requested')
    wait_leader()
    final_group = probe_group('after_kill_and_leader_wait')
    if process.poll() is None:
        receipt['errors'].append('leader not reaped within bounded cleanup')
    receipt.update(leader_reaped=process.poll() is not None, returncode=process.returncode,
                   group_absence_observed=final_group is False,
                   limit='PGID probes are non-atomic existence observations, not joins. Only leader wait is observed; the outer owned job is the final containment boundary. A kill request is neither all-group reap nor graceful native shutdown.')
    return receipt


def main():
    expected, tree, default_round = sys.argv[1:]
    if not all(re.fullmatch('[0-9a-f]{40}', value) for value in (expected, tree)):
        raise ValueError('exact published commit and tree required')
    if not re.fullmatch('[a-z0-9.-]+', default_round) or '..' in default_round:
        raise ValueError('invalid prior evidence identifier')
    evidence = ROOT / 'evidence/aishell-human-pin-r1'
    evidence.mkdir(parents=True, exist_ok=False)
    source, target = ROOT / 'source-pin', ROOT / 'target-pin'
    started = time.monotonic()
    record = {'schema': 'pipecat-public-aishell-offline-diagnostic-v1',
              'scope': 'one public prerecorded human utterance, Whisper subconfiguration only; no devices or Hepta admission',
              'head': expected, 'tree': tree, 'source': str(source), 'target': str(target),
              'start_unix': time.time(), 'stages': [], 'failure': None,
              'execution_and_identity_checks_succeeded': False, 'quality_passed': None,
              'inference_attempts': 0, 'automatic_retry': False,
              'required_outer_policy': {'deadline_seconds': 600, 'cpu_percent': 200,
                                        'memory_bytes': 8589934592, 'nice': 10,
                                        'enforcement': 'caller-owned runtime job, not asserted by this Python file'},
              'effects': {'physical_audio': False, 'new_hepta_owner_or_conversation': False,
                          'input_configuration_changes': False,
                          'download_commands_requested': False, 'cargo_offline': True}}
    owner_lock = None
    helper = None
    before = None
    executable = None
    original_status = 127
    monitored = {}
    before_files = {}
    result_path = evidence / 'result.json'

    def snapshot_record():
        save(result_path, record)

    def run(label, argv, timeout):
        remaining = 560 - (time.monotonic() - started)
        if remaining <= 0:
            raise StageFailure('total preparation/execution budget', 124)
        limit = min(timeout, remaining)
        item = {'label': label, 'argv': argv, 'cwd': str(source / 'rust'),
                'timeout_seconds': limit, 'started_unix': time.time(),
                'exit_code': None, 'timed_out': False, 'exception': None, 'cleanup': None}
        record['stages'].append(item)
        snapshot_record()
        phase_start = time.monotonic()
        process = None
        stdout_path, stderr_path = evidence / (label + '.stdout.log'), evidence / (label + '.stderr.log')
        try:
            with stdout_path.open('xb') as out, stderr_path.open('xb') as err:
                process = subprocess.Popen(argv, cwd=source / 'rust', env=environment,
                                           stdout=out, stderr=err, start_new_session=True)
                item['pid'] = process.pid
                if label == 'inference':
                    record['inference_attempts'] += 1
                snapshot_record()
                try:
                    item['exit_code'] = process.wait(timeout=limit)
                except subprocess.TimeoutExpired:
                    item['timed_out'] = True
                    item['cleanup'] = reap_after_failure(process)
                    item['exit_code'] = process.returncode
        except BaseException as error:
            item['exception'] = repr(error)
            if process is not None:
                item['cleanup'] = reap_after_failure(process)
                item['exit_code'] = process.returncode
            raise
        finally:
            item['elapsed_seconds'] = time.monotonic() - phase_start
            for kind, path in [('stdout', stdout_path), ('stderr', stderr_path)]:
                if path.exists():
                    item[kind] = file_identity(path)
            snapshot_record()
        if item['timed_out']:
            raise StageFailure(label, 124)
        if item['exit_code'] != 0:
            raise StageFailure(label, item['exit_code'] if isinstance(item['exit_code'], int) and item['exit_code'] > 0 else 127)
        return item

    try:
        owner_lock = (ROOT / 'qualification-owner-pin.lock').open('a')
        fcntl.flock(owner_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        record['exclusive_lock'] = str(ROOT / 'qualification-owner-pin.lock')
        monitored['script'] = pathlib.Path(__file__).resolve()
        monitored['manifest_helper'] = ROOT / 'run_full_gate.py'
        for role, path in monitored.items():
            before_files[role] = file_identity(path)
            (evidence / ('executed-' + role + '.py')).write_bytes(path.read_bytes())
        spec = importlib.util.spec_from_file_location('source_manifest_helper', monitored['manifest_helper'])
        helper = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helper)
        ownership = {'source': str(source), 'task': 'workspace-f9f576cc6c66'}
        if json.loads((target / '.pipecat-source-owner.json').read_text()) != ownership:
            raise ValueError('target is not owned by this exact checkout')
        head = helper.git_value(source, ['rev-parse', 'HEAD'])
        actual_tree = helper.git_value(source, ['rev-parse', 'HEAD^{tree}'])
        dirty = helper.git_value(source, ['status', '--porcelain=v1'])
        if head != expected or actual_tree != tree or dirty:
            raise ValueError('the exact frozen source must be clean')
        before = helper.source_manifest(source)
        save(evidence / 'source-before.json', before)
        record['source_before_sha256'] = before['manifest_sha256']
        default = ROOT / 'evidence' / default_round
        monitored['preceding_default_gate'] = default / 'gate.json'
        before_files['preceding_default_gate'] = file_identity(monitored['preceding_default_gate'])
        prior_raw = monitored['preceding_default_gate'].read_bytes()
        previous = json.loads(prior_raw)
        if previous.get('phase') != 'completed' or type(previous.get('exit_code')) is not int or not previous.get('source_unchanged'):
            raise ValueError('default gate must be terminal on unchanged source')
        if previous.get('head') != expected or previous.get('base_git_tree') != tree:
            raise ValueError('default gate belongs to a different source')
        (evidence / 'preceding-default.gate.json').write_bytes(prior_raw)
        record['preceding_default'] = {'evidence': str(default), 'exit_code': previous['exit_code'],
                                      'source_unchanged': previous['source_unchanged'],
                                      'scope': 'A nonzero default remains failed; this diagnostic does not replace that result.'}
        monitored['preceding_default_environment'] = default / 'environment.json'
        before_files['preceding_default_environment'] = file_identity(monitored['preceding_default_environment'])
        env_changes = json.loads(monitored['preceding_default_environment'].read_text())
        toolbin = ROOT / 'tools/rust-1.99.0-r1/bin'
        env_changes.update(CARGO_TARGET_DIR=str(target), CARGO_BUILD_JOBS='2',
                           RUSTC=str(toolbin / 'rustc'), RUSTDOC=str(toolbin / 'rustdoc'),
                           PATH=str(toolbin) + ':' + env_changes.get('PATH', os.environ.get('PATH', '')))
        environment = dict(os.environ, **env_changes)
        record['environment_overrides'] = env_changes
        for name in ['cargo', 'rustc', 'rustdoc', 'rustfmt', 'cargo-clippy', 'clippy-driver']:
            role = 'native-tool-' + name
            monitored[role] = toolbin / name
            before_files[role] = file_identity(monitored[role])
        cargo = str(toolbin / 'cargo')
        run('rustc-version', [str(toolbin / 'rustc'), '--version'], 15)
        run('cargo-version', [cargo, '--version'], 15)
        rustc_version = (evidence / 'rustc-version.stdout.log').read_text().strip()
        cargo_version = (evidence / 'cargo-version.stdout.log').read_text().strip()
        if not rustc_version.startswith('rustc 1.99.0 ') or not cargo_version.startswith('cargo 1.99.0 '):
            raise ValueError('explicit Rust 1.99.0 compiler and cargo required')
        record['versions'] = {'rustc': rustc_version, 'cargo': cargo_version}
        monitored['stt_source'] = source / STT_SOURCE
        before_files['stt_source'] = file_identity(monitored['stt_source'])
        if before_files['stt_source']['sha256'] != STT_SOURCE_SHA:
            raise ValueError('stt_fixture differs from the reviewed offline interface')
        for role, (path, size, expected_sha) in INPUTS.items():
            if path.lstat().st_size != size:
                raise ValueError('fixed input size differs: ' + role)
            monitored[role] = path
            before_files[role] = file_identity(path)
            if before_files[role]['sha256'] != expected_sha:
                raise ValueError('fixed historical input SHA differs: ' + role)
        config = json.loads(INPUTS['config'][0].read_bytes())
        if config['whisper_model'] != {'path': str(INPUTS['model'][0]), 'sha256': INPUTS['model'][2]} or config['whisper_settings'] != SETTINGS:
            raise ValueError('fixed Whisper subconfiguration differs')
        provenance_raw = INPUTS['provenance'][0].read_bytes()
        provenance = json.loads(provenance_raw)
        if provenance.get('expected') != REFERENCE or provenance.get('wav_sha256') != INPUTS['wav'][2] or provenance.get('revision') != 'be6ad97fdb512589df113042f7ff3a29d392fb38':
            raise ValueError('historical public source reference differs')
        (evidence / 'human-chinese-source-actual.json').write_bytes(provenance_raw)
        reference_bytes = REFERENCE.encode('utf-8')
        if hashlib.sha256(reference_bytes).hexdigest() != REFERENCE_SHA:
            raise ValueError('fixed reference text changed')
        (evidence / 'reference.txt').write_bytes(reference_bytes)
        with wave.open(io.BytesIO(INPUTS['wav'][0].read_bytes()), 'rb') as wav:
            if (wav.getframerate(), wav.getnchannels(), wav.getsampwidth(), wav.getnframes(), wav.getcomptype()) != (16000, 1, 2, 68496, 'NONE'):
                raise ValueError('fixed PCM16 WAV format differs')
        record['input_profile'] = {'whisper_settings': config['whisper_settings'],
                                   'wav_rate_hz': 16000, 'wav_channels': 1, 'wav_frames': 68496,
                                   'wav_duration_seconds': 4.281,
                                   'reference': REFERENCE, 'reference_utf8_sha256': REFERENCE_SHA,
                                   'reference_limit': 'The independently retrieved pinned upstream data.list is in the repository evidence; this desktop run reads the matching original source-actual record.',
                                   'qualification_scope': 'Whisper subconfiguration only; old owner/grant/media-store fields are never admitted.'}
        record['files_before'] = before_files
        snapshot_record()
        run('metadata', [cargo, 'metadata', '--no-deps', '--locked', '--offline', '--format-version', '1'], 30)
        metadata = json.loads((evidence / 'metadata.stdout.log').read_bytes())
        packages = [p for p in metadata['packages'] if p['name'] == 'pipecat-hepta' and p['id'] in metadata['workspace_members']]
        if len(packages) != 1 or pathlib.Path(packages[0]['manifest_path']).resolve() != source / 'rust/crates/pipecat-hepta/Cargo.toml':
            raise ValueError('metadata does not identify the exact owned pipecat-hepta package')
        package_id = packages[0]['id']
        run('build-normal-example', [cargo, 'build', '--locked', '--offline', '-p', 'pipecat-hepta',
                                     '--features', 'local-speech', '--example', 'stt_fixture',
                                     '--message-format=json-render-diagnostics'], 300)
        artifacts = []
        for line in (evidence / 'build-normal-example.stdout.log').read_bytes().splitlines():
            try:
                message = json.loads(line)
            except (ValueError, UnicodeDecodeError):
                continue
            if message.get('reason') == 'compiler-artifact' and message.get('target', {}).get('name') == 'stt_fixture':
                if message.get('package_id') != package_id or message['target']['kind'] != ['example'] or message.get('profile', {}).get('test') is not False or 'local-speech' not in message.get('features', []) or not message.get('executable'):
                    raise ValueError('normal stt_fixture artifact identity/profile/features mismatch')
                artifacts.append(message)
        if len(artifacts) != 1:
            raise ValueError('expected one normal stt_fixture compiler artifact')
        artifact = artifacts[0]
        executable = pathlib.Path(artifact['executable']).resolve()
        if executable != target / 'debug/examples/stt_fixture' or pathlib.Path(artifact['target']['src_path']).resolve() != source / STT_SOURCE:
            raise ValueError('compiled stt_fixture path escaped its owned source/target')
        monitored['compiled_executable'] = executable
        before_files['compiled_executable'] = file_identity(executable)
        save(evidence / 'compiler-artifact.json', artifact)
        record['compiler_artifact'] = artifact
        record['files_before'] = before_files
        snapshot_record()
        run('inference', [str(executable), str(INPUTS['config'][0]), str(INPUTS['wav'][0])], 60)
        # Preserve the exact stdout bytes separately; parsed JSON is only a view.
        inference_raw = (evidence / 'inference.stdout.log').read_bytes()
        answer = json.loads(inference_raw)
        if answer.get('scope') != 'offline_wav_stt_no_device_or_hepta_admission' or answer.get('model_sha256') != INPUTS['model'][2] or answer.get('wav_sha256') != INPUTS['wav'][2] or not same_settings(answer.get('settings')):
            raise ValueError('inference JSON does not bind the fixed scope and inputs')
        if not isinstance(answer.get('transcript'), dict) or not isinstance(answer['transcript'].get('text'), str):
            raise ValueError('inference JSON lacks its verbatim transcript string')
        (evidence / 'inference.json').write_bytes(inference_raw)
        record['inference_json'] = answer
        record['shutdown_evidence'] = {'success_json_observed_after_awaited_shutdown': True,
                                       'source_sha256': STT_SOURCE_SHA, 'process_exit_code': 0,
                                       'limit': 'A successful fixed-source process with its original JSON; no device or production-owner shutdown is involved.'}
        original_status = 0
    except StageFailure as error:
        record['failure'] = str(error)
        original_status = error.code
        (evidence / 'error.log').write_text(traceback.format_exc())
    except BaseException as error:
        record['failure'] = f'{type(error).__name__}: {error}'
        (evidence / 'error.log').write_text(traceback.format_exc())
    finally:
        record['runner_exit_before_integrity_checks'] = original_status
        record['files_before'] = before_files
        after_files = {}
        for role, path in monitored.items():
            try:
                after_files[role] = file_identity(path)
                after_files[role]['unchanged'] = role in before_files and after_files[role]['sha256'] == before_files[role]['sha256'] and after_files[role]['bytes'] == before_files[role]['bytes']
            except Exception as error:
                after_files[role] = {'path': str(path), 'unchanged': False, 'error': repr(error)}
        record['files_after'] = after_files
        record['files_unchanged'] = bool(before_files) and all(x.get('unchanged') for x in after_files.values())
        if helper is not None and before is not None:
            try:
                after = helper.source_manifest(source)
                save(evidence / 'source-after.json', after)
                record['source_after_sha256'] = after['manifest_sha256']
                record['source_unchanged'] = before == after
                record['status_after'] = helper.git_value(source, ['status', '--porcelain=v1'])
            except Exception as error:
                record['source_unchanged'] = False
                record['source_after_error'] = repr(error)
        else:
            record['source_unchanged'] = False
        final_status = original_status
        if original_status == 0 and (not record['files_unchanged'] or not record['source_unchanged'] or record.get('status_after')):
            final_status = 125
        record.update(end_unix=time.time(), elapsed_seconds=time.monotonic() - started,
                      phase='completed', wrapper_exit_code=final_status,
                      execution_and_identity_checks_succeeded=final_status == 0)
        snapshot_record()
        paths = sorted(p for p in evidence.iterdir() if p.is_file() and p.name != 'SHA256SUMS')
        (evidence / 'SHA256SUMS').write_text(''.join(sha(p) + '  ' + p.name + '\n' for p in paths))
        if owner_lock is not None:
            owner_lock.close()
        print(json.dumps({'evidence': str(evidence), 'head': expected, 'tree': tree,
                          'preceding_default': record.get('preceding_default'),
                          'execution_and_identity_checks_succeeded': record['execution_and_identity_checks_succeeded'],
                          'quality_passed': None, 'inference_attempts': record['inference_attempts'],
                          'failure': record['failure'], 'runner_exit_before_integrity_checks': original_status,
                          'wrapper_exit_code': final_status, 'result_sha256': sha(result_path)}, ensure_ascii=False), flush=True)
    return final_status


if __name__ == '__main__':
    raise SystemExit(main())
