#!/usr/bin/env python3
"""One fixed C-API binary comparison after all authorized 0cc native stages.

No installation/import of the wheel, no Cargo, no runtime replacement, no retry.
The caller owns a 210-second job, CPU 200%, memory 4 GiB and nice 10, and must
observe terminal/durable runtime statuses for all preceding native stages.
"""
import base64
import csv
import fcntl
import hashlib
import importlib.util
import io
import json
import math
import os
from pathlib import Path
import signal
import stat
import struct
import subprocess
import time
import traceback
import urllib.request
import zipfile

ROOT = Path('/home/qian-qi/workspace/pipecat-workspace-f9f576cc6c66')
SOURCE = ROOT / 'source-pin'
HEAD = '0cc16e8123cb05aaad480d5ab7860a267d998bac'
TREE = 'aec037b9cf2be53fcf6f85fdc149382942277702'
SOURCE_MANIFEST = '1e07f773ca2827e8db5b06175f96137b5d85bb6dcb68229d29601efe29658535'
REQUEST = ROOT / 'requests/smart-turn-wheel-reference-pin-r3'
EVIDENCE = ROOT / 'evidence/smart-turn-wheel-reference-pin-r3'
C1_REQUEST = ROOT / 'requests/smart-turn-ort-reference-pin-r1'
C1_EVIDENCE = ROOT / 'evidence/smart-turn-ort-reference-pin-r1'
OLD_RUNTIME = Path('/home/qian-qi/workspace/hepta-hmi-20261029/assets/onnxruntime-linux-x64-1.21.0/lib/libonnxruntime.so.1.21.0')
PROBE = C1_REQUEST / 'ort_reference_probe'
MODEL = SOURCE / 'src/pipecat/audio/turn/smart_turn/data/smart-turn-v3.2-cpu.onnx'
FIXTURES = SOURCE / 'rust/crates/pipecat-vad/tests/fixtures'
ENVIRONMENT = ROOT / 'evidence/full-workspace-rust-1.99.0-r4/environment.json'
WHEEL_NAME = 'onnxruntime-1.21.0-cp312-cp312-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl'
WHEEL_URL = 'https://files.pythonhosted.org/packages/8b/08/eead6895ed83b56711ca6c0d31d82f109401b9937558b425509e497d6fb4/' + WHEEL_NAME
WHEEL_BYTES = 16019285
WHEEL_SHA = '9a04aafb802c1e5573ba4552f8babcb5021b041eb4cfa802c9b7644ca3510eca'
MEMBER = 'onnxruntime/capi/libonnxruntime.so.1.21.0'
MEMBER_BYTES = 20571088
MEMBER_SHA = 'a0df84fae0f09d9eca3d6919f685ba435f1ae6cb628e128b69bcf2a2b965504c'
RECORD_NAME = 'onnxruntime-1.21.0.dist-info/RECORD'
RECORD_BYTES = 33985
RECORD_SHA = '737bbc309e6304a5c005b789fb01ef85dd47484c4e489510341fcc8e00d14ea1'
NEEDED = ['libdl.so.2', 'librt.so.1', 'libpthread.so.0', 'libstdc++.so.6',
          'libm.so.6', 'libgcc_s.so.1', 'libc.so.6', 'ld-linux-x86-64.so.2']
CASES = ['speech', 'tone', 'silence']
INPUTS = {
    ROOT / 'run_full_gate.py': (5176, 'c6b639d10e4e0d48910d007a161d7b35e81744bd5e31f878f960bdcd452b47e4'),
    C1_REQUEST / 'ort_reference_probe.c': (11814, 'fed472ea3c7b8deb7039327c2a10bb4cbc49f0af6c34c5c7f38445809fd7d547'),
    C1_REQUEST / 'onnxruntime_c_api.h': (219712, '7783e9664bdb0b1b36145b5c8587dd1bc9a399aa000edf2e3dd03003cafc6882'),
    PROBE: (25576, 'e20adb1f67f6bd5f42ce30b0ad13a0ae568dcb80d4fcd7b2a0237366892fffbc'),
    OLD_RUNTIME: (20558800, '3c8181b339025dd18899916357e74290029722e1d5a5778b4071a733f813420d'),
    MODEL: (8679182, '2bb026316b14a660486a75b1733cd3fbab8c2fd0314dc9af7be49f8cca967e4f'),
    C1_EVIDENCE / 'reference.json': (27385, '7c0720620aaea61615e1a50795ad84118c6881563198e4d42534f9e565c67b4e'),
    C1_EVIDENCE / 'probe.stdout.log': (1814, '09afb06777afba21d8055a6ecb08712ab6a077e2b6829382f12ef5d9837a1780'),
    ENVIRONMENT: (None, '2a85b9407e7990a522063635508efbfeb014e7298dafb82f4460e929acfee026'),
    FIXTURES / 'smart_turn_speech.f32': (256000, '618645fb485f531de515aa83b13627cb3d19a5cb8a0d1faf617c99e76fb8b575'),
    FIXTURES / 'smart_turn_tone.f32': (256000, 'f838341ea22fe1aac684c6eabfc2ccd8f38330b2dbca1220985963d4d90dedc5'),
    FIXTURES / 'smart_turn_silence.f32': (256000, 'c4a1d90bbbdc1c49cf89b8f73360019b1b0fe01ae48a9dfd6fc2c4a3228b8859'),
    FIXTURES / 'smart_turn_speech.probability.txt': (20, '17f53fa2fd6586f8ccca5f8a576e972c8d0631ab0efcf6d84cc5747369940783'),
    FIXTURES / 'smart_turn_tone.probability.txt': (21, '3c2b2ba20fc2d02511c3ab4371e12c03d2e1d6ddb06daa6e618b438305d2f4de'),
    FIXTURES / 'smart_turn_silence.probability.txt': (20, '7ec5e2f9ea54c1b8aaf8701afb68b5742a99dce27ac5546adb9e06646cc24a8c'),
}


class Failed(Exception):
    def __init__(self, message, code=127):
        super().__init__(message)
        self.code = code


def identity(path):
    path = Path(path)
    first = path.lstat()
    if not stat.S_ISREG(first.st_mode) or first.st_size > 512 * 1024 * 1024:
        raise ValueError('expected bounded regular non-symlink file: ' + str(path))
    digest = hashlib.sha256()
    count = 0
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            count += len(block)
            if count > 512 * 1024 * 1024:
                raise ValueError('file grew beyond identity budget')
            digest.update(block)
    last = path.lstat()
    fields = lambda item: (item.st_dev, item.st_ino, item.st_size, item.st_mtime_ns)
    if fields(first) != fields(last) or count != first.st_size:
        raise ValueError('file changed during identity read')
    return {'path': str(path), 'resolved': str(path.resolve()), 'bytes': count, 'sha256': digest.hexdigest()}


def json_save(path, value):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)


def elf_static(raw):
    """Read ELF metadata as data. Do not invoke ldd, load or execute the library."""
    if len(raw) != MEMBER_BYTES:
        raise ValueError('unexpected C API ELF byte length')
    header = struct.unpack_from('<16sHHIQQQIHHHHHH', raw, 0)
    ident, kind, machine, version = header[:4]
    if ident[:7] != b'\x7fELF\x02\x01\x01' or kind != 3 or machine != 62 or version != 1:
        raise ValueError('C API member is not the pinned x86-64 ELF64 little-endian shared object')
    shoff, shentsize, shnum, shstrndx = header[6], header[11], header[12], header[13]
    if shentsize != 64 or not 1 <= shnum <= 4096 or not 0 < shstrndx < shnum:
        raise ValueError('invalid bounded ELF section table')
    if shoff + shnum * shentsize > len(raw):
        raise ValueError('ELF section table exceeds member')
    sections = [struct.unpack_from('<IIQQQQIIQQ', raw, shoff + i * shentsize) for i in range(shnum)]

    def section_bytes(index):
        section = sections[index]
        offset, size = section[4:6]
        if offset + size > len(raw):
            raise ValueError('ELF section exceeds member')
        return raw[offset:offset + size]

    def string_at(data, offset):
        if not 0 <= offset < len(data):
            raise ValueError('ELF string offset outside string table')
        end = data.find(b'\0', offset)
        if end == -1:
            raise ValueError('unterminated ELF metadata string')
        return data[offset:end].decode('utf-8', 'strict')

    section_names = section_bytes(shstrndx)
    names = {}
    for index, section in enumerate(sections):
        name = string_at(section_names, section[0])
        if name in ('.dynamic', '.dynsym', '.dynstr'):
            if name in names:
                raise ValueError('ambiguous ELF metadata section')
            names[name] = index
    if set(names) != {'.dynamic', '.dynsym', '.dynstr'}:
        raise ValueError('required ELF metadata is absent')
    dynamic_section = sections[names['.dynamic']]
    symbols_section = sections[names['.dynsym']]
    if dynamic_section[1] != 6 or dynamic_section[9] != 16 or symbols_section[1] != 11 or symbols_section[9] != 24:
        raise ValueError('ELF dynamic/symbol entry kind differs')
    if dynamic_section[6] != names['.dynstr'] or symbols_section[6] != names['.dynstr']:
        raise ValueError('ELF metadata uses unexpected string table')
    strings = section_bytes(names['.dynstr'])
    dynamic = section_bytes(names['.dynamic'])
    symbols = section_bytes(names['.dynsym'])
    if len(dynamic) % 16 or len(symbols) % 24:
        raise ValueError('truncated ELF metadata entries')
    dependencies, sonames, runpaths, rpaths = [], [], [], []
    terminated = False
    for offset in range(0, len(dynamic), 16):
        tag, value = struct.unpack_from('<qQ', dynamic, offset)
        if tag == 0:
            terminated = True
            break
        destination = {1: dependencies, 14: sonames, 29: runpaths, 15: rpaths}.get(tag)
        if destination is not None:
            destination.append(string_at(strings, value))
    exports = []
    for offset in range(0, len(symbols), 24):
        name_offset, info, other, section_index, value, size = struct.unpack_from('<IBBHQQ', symbols, offset)
        name = string_at(strings, name_offset)
        if name in ('OrtGetApiBase', 'OrtSessionOptionsAppendExecutionProvider_CPU'):
            if section_index == 0 or info >> 4 not in (1, 2) or info & 15 != 2 or other & 3 != 0:
                raise ValueError('required C API entry is not a defined exported function')
            exports.append(name)
    if not terminated or dependencies != NEEDED or sonames != ['libonnxruntime.so.1'] or runpaths != ['$ORIGIN'] or rpaths:
        raise ValueError('C API ELF dynamic requirements differ from static primary inspection')
    if sorted(exports) != ['OrtGetApiBase', 'OrtSessionOptionsAppendExecutionProvider_CPU']:
        raise ValueError('required standalone C API/CPU exports differ')
    return {'elf_class': 64, 'machine': 'x86_64', 'endianness': 'little', 'type': 'ET_DYN',
            'needed': dependencies, 'soname': sonames[0], 'runpath': runpaths,
            'exports': sorted(exports), 'python_library_dependency': False,
            'limit': 'Static metadata verifies this artifact, not runtime ABI success or Python pybind equivalence.'}


def group_probe(pgid):
    try:
        os.killpg(pgid, 0)
        return {'present': True}
    except ProcessLookupError:
        return {'present': False}
    except OSError as error:
        return {'present': None, 'error': repr(error)}


def cleanup_owned(child):
    result = {'pid': child.pid, 'pgid': child.pid, 'requests': [], 'errors': []}
    result['group_before'] = group_probe(child.pid)
    result['leader_exit_before'] = child.poll()
    result['surviving_group_after_normal_exit'] = child.returncode is not None and result['group_before']['present'] is not False
    if child.returncode is None or result['group_before']['present'] is not False:
        for sig, seconds in ((signal.SIGTERM, 2), (signal.SIGKILL, 2)):
            if sig == signal.SIGKILL and child.poll() is not None and group_probe(child.pid)['present'] is False:
                break
            request = {'signal': int(sig), 'pgid': child.pid}
            try:
                os.killpg(child.pid, sig)
                request['result'] = 'requested'
            except ProcessLookupError:
                request['result'] = 'group absent'
            except OSError as error:
                request['error'] = repr(error)
                result['errors'].append(repr(error))
            result['requests'].append(request)
            try:
                child.wait(timeout=seconds)
            except subprocess.TimeoutExpired:
                pass
            except OSError as error:
                result['errors'].append('wait: ' + repr(error))
    try:
        child.wait(timeout=1)
    except subprocess.TimeoutExpired:
        pass
    except OSError as error:
        result['errors'].append('final wait: ' + repr(error))
    result['leader_reaped'] = child.poll() is not None
    result['leader_exit_after'] = child.returncode
    result['group_after'] = group_probe(child.pid)
    result['checks_succeeded'] = result['leader_reaped'] and result['group_after']['present'] is False
    result['scope'] = 'Owned-PGID signal requests, actual leader reap and non-atomic group probes; never a claim that every descendant was individually joined.'
    return result


def main():
    began = time.monotonic()
    deadline = began + 180
    REQUEST.mkdir(mode=0o700, exist_ok=False)
    EVIDENCE.mkdir(mode=0o700, exist_ok=False)
    result_path = EVIDENCE / 'reference.json'
    record = {
        'schema': 'pipecat-smart-turn-wheel-c-api-reference-v1', 'phase': 'preparing',
        'head': HEAD, 'tree': TREE, 'start_unix': time.time(),
        'scope': 'One separate official-wheel C API binary, fixed original C1 ALL session and three frozen golden inputs; not a Python package or historical oracle reconstruction.',
        'required_outer_policy': {'timeout_seconds': 210, 'cpu_percent': 200, 'memory_bytes': 4294967296, 'nice': 10},
        'inner_whole_budget_seconds': 180, 'probe_timeout_seconds': 60, 'cleanup_reserve_seconds': 10,
        'automatic_retry': False, 'cargo_invocations': 0, 'package_installations': 0,
        'python_onnxruntime_imports': 0, 'probe_launch_attempts': 0, 'probe_processes_started': 0, 'declared_native_calls': 3,
        'declared_case_order': CASES, 'runtime_replacement': False, 'production_qualification': False,
        'earlier_failures_cleared': False, 'comparison_exit_code': None,
        'native_exit_code': None, 'execution_and_output_checks_succeeded': False,
        'identity_before': {}, 'identity_after': {}, 'preceding': {},
    }
    lock, helper, source_before, child = None, None, None, None
    tracked = {}
    status = 127
    runtime = REQUEST / 'runtime' / 'libonnxruntime.so.1.21.0'
    wheel = REQUEST / WHEEL_NAME
    partial = REQUEST / (WHEEL_NAME + '.partial')
    stdout_path, stderr_path = EVIDENCE / 'probe.stdout.log', EVIDENCE / 'probe.stderr.log'

    def save():
        json_save(result_path, record)

    def observe(path, expected_size=None, expected_sha=None):
        item = identity(path)
        tracked[str(path)] = Path(path)
        record['identity_before'][str(path)] = item
        if expected_size is not None and item['bytes'] != expected_size:
            raise ValueError('immutable file size differs: ' + str(path))
        if expected_sha is not None and item['sha256'] != expected_sha:
            raise ValueError('immutable file hash differs: ' + str(path))
        return item

    def check_budget(reserve=10):
        if time.monotonic() + reserve >= deadline:
            raise Failed('whole-job budget exhausted before next phase', 124)

    def prior_receipt(name, path, exit_key='exit_code'):
        check_budget()
        before = observe(path)
        raw = path.read_bytes()
        item = json.loads(raw)
        actual_head = item.get('head', item.get('expected_head'))
        actual_tree = item.get('tree', item.get('base_git_tree', item.get('expected_tree')))
        if actual_head != HEAD or actual_tree != TREE or type(item.get(exit_key)) is not int:
            raise ValueError('preceding stage belongs to another source or lacks terminal exit: ' + name)
        if item[exit_key] == 125:
            raise ValueError('preceding stage reported integrity/containment failure: ' + name)
        if item.get('phase') not in ('completed', 'completed_successfully', 'completed_with_failures'):
            raise ValueError('preceding stage has not reached terminal phase: ' + name)
        if name == 'expanded':
            if item.get('integrity_failure') or not item.get('driver', {}).get('unchanged') or not item.get('stages'):
                raise ValueError('preceding expanded driver integrity is unavailable')
            if any(stage.get('source_unchanged') is not True for stage in item['stages']):
                raise ValueError('preceding expanded source was not intact')
            if any(stage.get('phase') not in ('completed', 'retained_prior_record') or stage.get('wrapper_exit_code') == 125 for stage in item['stages']):
                raise ValueError('preceding expanded stage is incomplete or failed integrity')
        elif item.get('source_unchanged') is not True or item.get('status_after'):
            raise ValueError('preceding stage source was not intact: ' + name)
        if name == 'grok' and (not item.get('artifacts') or any(artifact.get('unchanged') is not True for artifact in item['artifacts'].values())):
            raise ValueError('preceding Grok artifacts lack intact postchecks')
        if name == 'models':
            if item.get('all_observed_inputs_unchanged') is not True or item.get('espeak_unchanged') is not True:
                raise ValueError('preceding model inputs lack intact postchecks')
            if item.get('driver_invoked'):
                cleanup = item.get('driver_cleanup', {})
                if not cleanup.get('checks_succeeded', cleanup.get('cleanup_checks_succeeded')) or cleanup.get('unexpected_surviving_group_after_driver_exit'):
                    raise ValueError('preceding native model driver lacks successful containment')
        if name == 'webrtc':
            if item.get('binary') is not None and item['binary'].get('unchanged') is not True:
                raise ValueError('preceding WebRTC binary lacks intact postchecks')
            for process in item.get('processes', []) + item.get('rounds', []):
                if 'pid' in process and (not process.get('leader_reaped') or process.get('process_group_present_at_final_probe') is not False or process.get('cleanup_incomplete') or process.get('cleanup_errors')):
                    raise ValueError('preceding WebRTC process was not contained')
        if name == 'aishell':
            attempts = item.get('inference_attempts')
            if type(attempts) is not int or attempts not in (0, 1) or item.get('files_unchanged') is not True:
                raise ValueError('preceding AISHELL attempt count or intact-input receipt is invalid')
            if attempts == 0 and (item[exit_key] == 0 or not item.get('failure')):
                raise ValueError('zero AISHELL inference attempts require an explicit terminal failure')
            if sum(stage.get('label') == 'inference' and 'pid' in stage for stage in item.get('stages', [])) != attempts:
                raise ValueError('preceding AISHELL admitted-process count differs from its stages')
            for stage in item.get('stages', []):
                cleanup = stage.get('cleanup')
                if cleanup is not None and (cleanup.get('leader_reaped') is not True or cleanup.get('group_absence_observed') is not True or cleanup.get('errors')):
                    raise ValueError('preceding AISHELL process cleanup is incomplete')
                if 'pid' in stage and type(stage.get('exit_code')) is not int:
                    raise ValueError('preceding AISHELL started process lacks a terminal exit')
                if stage.get('timed_out') and cleanup is None:
                    raise ValueError('preceding AISHELL timeout lacks its containment receipt')
        (EVIDENCE / ('preceding-' + name + '.json')).write_bytes(raw)
        record['preceding'][name] = {'path': str(path), 'sha256': before['sha256'],
                                     'exit_code': item[exit_key], 'phase': item['phase'],
                                     'earlier_failure_preserved': item[exit_key] != 0}

    save()
    try:
        lock = (ROOT / 'qualification-owner-pin.lock').open('a')
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        record['lock_acquired'] = True
        for path, (size, digest) in INPUTS.items():
            check_budget()
            observe(path, size, digest)
        observe(Path(__file__).resolve())
        (EVIDENCE / 'executed-runner.py').write_bytes(Path(__file__).read_bytes())
        spec = importlib.util.spec_from_file_location('source_manifest_helper', ROOT / 'run_full_gate.py')
        helper = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helper)
        if helper.git_value(SOURCE, ['rev-parse', 'HEAD']) != HEAD or helper.git_value(SOURCE, ['rev-parse', 'HEAD^{tree}']) != TREE or helper.git_value(SOURCE, ['status', '--porcelain=v1']):
            raise ValueError('the original 0cc native source must remain clean and unchanged')
        source_before = helper.source_manifest(SOURCE)
        if source_before['manifest_sha256'] != SOURCE_MANIFEST:
            raise ValueError('0cc source manifest differs from the original native-stage snapshot')
        json_save(EVIDENCE / 'source-before.json', source_before)
        record['source_before_sha256'] = source_before['manifest_sha256']
        for name, path, exit_key in [
            ('grok', ROOT / 'evidence/grok-lifetime-qualification-pin-r1/repetitions.json', 'exit_code'),
            ('default', ROOT / 'evidence/full-workspace-rust-1.99.0-r5/gate.json', 'exit_code'),
            ('expanded', ROOT / 'evidence/expanded-batch-pin-r2/batch.json', 'exit_code'),
            ('models', ROOT / 'evidence/model-inputs-pin-r2/inputs.json', 'exit_code'),
            ('webrtc', ROOT / 'evidence/webrtc-stress-pin-r1/repetitions.json', 'exit_code'),
            ('aishell', ROOT / 'evidence/aishell-human-pin-r1/result.json', 'wrapper_exit_code'),
        ]:
            prior_receipt(name, path, exit_key)
        prior = json.loads((C1_EVIDENCE / 'reference.json').read_bytes())
        prior_records = [json.loads(line) for line in (C1_EVIDENCE / 'probe.stdout.log').read_text().splitlines()]
        if prior.get('native_exit_code') != 0 or prior.get('exit_code') != 1 or prior_records != prior['native_records'] or not prior.get('source_unchanged'):
            raise ValueError('original C1 execution/comparison receipt differs')
        record['prior_all'] = {'report_sha256': INPUTS[C1_EVIDENCE / 'reference.json'][1],
                               'native_exit_code': 0, 'comparison_exit_code': 1,
                               'executed_again': False, 'comparisons': prior['comparisons']}
        environment_overrides = json.loads(ENVIRONMENT.read_bytes())
        environment = dict(os.environ, **environment_overrides)
        record['native_environment_sha256'] = INPUTS[ENVIRONMENT][1]
        record['environment_scope'] = 'Existing C1 environment file is retained exactly. No CPU/ISA, optimization, inference or provider flags are set or modified.'
        record['current_loader_environment'] = {name: environment.get(name) for name in ('LD_PRELOAD', 'LD_LIBRARY_PATH', 'LD_AUDIT', 'LD_BIND_NOW')}
        record['loader_environment_limit'] = 'These are this run\'s narrowly selected loader settings; unrecorded C1 inherited settings and system dependencies are not retrospectively reconstructed.'
        check_budget(75)
        download_start = time.monotonic()
        record['download'] = {'url': WHEEL_URL, 'expected_bytes': WHEEL_BYTES,
                              'expected_sha256': WHEEL_SHA, 'attempts': 1,
                              'wall_budget_seconds': 45, 'socket_timeout_seconds': 10,
                              'wall_budget_scope': 'Checked between reads and after completion. Socket inactivity timeout is not a universal wall-time interrupt; the caller-owned job is the ultimate containment boundary.',
                              'scope': 'Known public archive bytes only; no installer or package import.'}
        save()
        request = urllib.request.Request(WHEEL_URL, headers={'Accept-Encoding': 'identity'})
        digest, count = hashlib.sha256(), 0
        with urllib.request.urlopen(request, timeout=10) as response, partial.open('xb') as destination:
            record['download'].update(http_status=response.status, final_url=response.url,
                                      content_length=response.headers.get('Content-Length'))
            if response.status != 200 or response.url != WHEEL_URL or response.headers.get('Content-Length') != str(WHEEL_BYTES):
                raise ValueError('download status, redirect or exact content length differs')
            while True:
                if time.monotonic() - download_start > 45:
                    raise Failed('archive retrieval exceeded its declared wall budget', 124)
                check_budget(70)
                block = response.read(1024 * 1024)
                if not block:
                    break
                count += len(block)
                if count > WHEEL_BYTES:
                    raise ValueError('archive exceeds exact declared size')
                destination.write(block)
                digest.update(block)
        record['download'].update(bytes=count, sha256=digest.hexdigest(), elapsed_seconds=time.monotonic() - download_start)
        if time.monotonic() - download_start > 45:
            raise Failed('archive retrieval finished beyond its declared wall budget', 124)
        if count != WHEEL_BYTES or digest.hexdigest() != WHEEL_SHA:
            raise ValueError('complete public wheel bytes differ')
        partial.rename(wheel)
        observe(wheel, WHEEL_BYTES, WHEEL_SHA)
        with zipfile.ZipFile(wheel) as archive:
            names = archive.namelist()
            if len(names) != 337 or len(set(names)) != len(names):
                raise ValueError('pinned archive member identity differs')
            record_info = archive.getinfo(RECORD_NAME)
            member_info = archive.getinfo(MEMBER)
            if record_info.file_size != RECORD_BYTES or member_info.file_size != MEMBER_BYTES or member_info.flag_bits & 1:
                raise ValueError('bounded native member/RECORD metadata differs')
            if stat.S_IFMT(member_info.external_attr >> 16) != stat.S_IFREG:
                raise ValueError('native ZIP member is not an ordinary file')
            record_raw = archive.read(record_info)
            if hashlib.sha256(record_raw).hexdigest() != RECORD_SHA:
                raise ValueError('pinned wheel RECORD differs')
            rows = list(csv.reader(io.StringIO(record_raw.decode('utf-8'))))
            selected = [row for row in rows if row and row[0] == MEMBER]
            encoded_digest = base64.urlsafe_b64encode(bytes.fromhex(MEMBER_SHA)).decode('ascii').rstrip('=')
            if selected != [[MEMBER, 'sha256=' + encoded_digest, str(MEMBER_BYTES)]]:
                raise ValueError('wheel RECORD does not bind this exact C API member')
            runtime_raw = archive.read(member_info)
        if len(runtime_raw) != MEMBER_BYTES or hashlib.sha256(runtime_raw).hexdigest() != MEMBER_SHA:
            raise ValueError('extracted C API member bytes differ')
        record['static_elf'] = elf_static(runtime_raw)
        runtime.parent.mkdir(mode=0o700, exist_ok=False)
        with runtime.open('xb') as destination:
            destination.write(runtime_raw)
        observe(runtime, MEMBER_BYTES, MEMBER_SHA)
        record['extraction'] = {'native_members_extracted': [MEMBER], 'record_bytes': RECORD_BYTES,
                                'record_sha256': RECORD_SHA, 'record_entry': selected[0],
                                'pybind_extracted_or_imported': False,
                                'old_runtime_unchanged_parameter': str(OLD_RUNTIME),
                                'limit': 'This C API library is distinct from the Python pybind binary and is not identified as the historical oracle runtime.'}
        check_budget()
        argv = [str(PROBE), str(runtime), str(MODEL), *[str(FIXTURES / ('smart_turn_' + case + '.f32')) for case in CASES]]
        wait_budget = min(60, deadline - time.monotonic() - 10)
        if wait_budget <= 0:
            raise Failed('no execution budget remains before native admission', 124)
        record.update(phase='launching', argv=argv, cwd=str(SOURCE / 'rust'), effective_probe_timeout_seconds=wait_budget)
        save()
        with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
            record['probe_launch_attempts'] = 1
            save()
            child = subprocess.Popen(argv, cwd=SOURCE / 'rust', env=environment,
                                     stdout=stdout, stderr=stderr, start_new_session=True)
            record.update(phase='running', probe_processes_started=1, pid=child.pid, pgid=child.pid)
            save()
            try:
                remaining_wait = min(wait_budget, deadline - time.monotonic() - 10)
                record['effective_native_wait_seconds'] = max(0, remaining_wait)
                if remaining_wait <= 0:
                    raise Failed('whole-job budget exhausted after native admission', 124)
                record['native_exit_code'] = child.wait(timeout=remaining_wait)
            except subprocess.TimeoutExpired:
                record['timed_out'] = True
                raise Failed('single native probe exceeded its fixed process budget', 124)
        status = record['native_exit_code'] if record['native_exit_code'] >= 0 else 127
        if status != 0:
            raise Failed('the single native probe returned a nonzero original exit', status)
        raw_output = stdout_path.read_bytes()
        if len(raw_output) > 1024 * 1024:
            raise ValueError('native output exceeds the fixed JSON protocol budget')
        native = [json.loads(line) for line in raw_output.splitlines()]
        record['native_records'] = native
        if len(native) != 8 or native[0].get('kind') != 'runtime':
            raise ValueError('native output protocol differs')
        runtime_record = native[0]
        if runtime_record.get('api_requested') != 20 or runtime_record.get('header_api') != 21 or runtime_record.get('version') != '1.21.0' or runtime_record.get('loaded_filename') != str(runtime) or not isinstance(runtime_record.get('build_info'), str):
            raise ValueError('actual runtime/API identity does not match the isolated member')
        if native[1:4] != prior_records[1:4]:
            raise ValueError('C1 session settings or model IO changed')
        if native[-1] != {'kind': 'cleanup', 'release_calls_returned': True, 'completed_cases': 3, 'exit_code': 0}:
            raise ValueError('native release/completed-case receipt differs')
        comparisons = []
        for case, prediction, original in zip(CASES, native[4:7], prior['comparisons']):
            value = prediction.get('value')
            if prediction.get('kind') != 'prediction' or prediction.get('case') != case or original['case'] != case:
                raise ValueError('native case order differs')
            if prediction.get('input_file') != str(FIXTURES / ('smart_turn_' + case + '.f32')) or prediction.get('input_bytes') != 256000 or prediction.get('input_shape') != [1, 80, 800] or prediction.get('dtype') != 1 or prediction.get('shape') != [1, 1]:
                raise ValueError('native input/output shape or type differs')
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or struct.pack('>f', value).hex() != prediction.get('f32_bits'):
                raise ValueError('native float32 value/bits invalid')
            reference_text = (FIXTURES / ('smart_turn_' + case + '.probability.txt')).read_text().strip()
            expected = struct.unpack('<f', struct.pack('<f', float(reference_text)))[0]
            delta = value - expected
            comparisons.append({'case': case, 'actual': value, 'f32_bits': prediction['f32_bits'],
                                'unchanged_reference_text': reference_text, 'expected_f32': expected,
                                'signed_delta': delta, 'absolute_delta': abs(delta),
                                'original_direct_tolerance': 1e-5, 'within_original_direct_tolerance': abs(delta) <= 1e-5,
                                'retained_c1_all_value': original['actual'], 'delta_from_c1_all': value - original['actual'],
                                'same_f32_bits_as_c1_all': prediction['f32_bits'] == original['f32_bits']})
        record['comparisons'] = comparisons
        record['comparison_exit_code'] = 0 if all(item['within_original_direct_tolerance'] for item in comparisons) else 1
        record['completed_native_cases'] = 3
        record['execution_and_output_checks_succeeded'] = True
        status = record['comparison_exit_code']
        record['interpretation_limit'] = 'Results compare two identified standalone C API artifacts at fixed inputs and settings. Equal or different outputs do not identify the historical Python oracle, a CPU cause, production readiness, or a replacement default runtime.'
    except Failed as error:
        status = error.code
        record['failure'] = str(error)
        (EVIDENCE / 'error.log').write_text(traceback.format_exc())
    except Exception as error:
        record['failure'] = repr(error)
        (EVIDENCE / 'error.log').write_text(traceback.format_exc())
        if status == 0:
            status = 127
    finally:
        record['execution_exit_code_before_cleanup'] = status
        if child is not None:
            try:
                record['process_cleanup'] = cleanup_owned(child)
                record['native_exit_code_after_cleanup'] = child.returncode
                if not record['process_cleanup']['checks_succeeded'] or record['process_cleanup']['surviving_group_after_normal_exit']:
                    status = 125
            except Exception as error:
                record['process_cleanup_error'] = repr(error)
                status = 125
        record['execution_exit_code_before_integrity_checks'] = status
        for path, value in tracked.items():
            try:
                after = identity(value)
                before = record['identity_before'][path]
                after['unchanged'] = all(after[key] == before[key] for key in ('resolved', 'bytes', 'sha256'))
                record['identity_after'][path] = after
                if not after['unchanged']:
                    status = 125
            except Exception as error:
                record['identity_after'][path] = {'unchanged': False, 'error': repr(error)}
                status = 125
        record['all_observed_files_unchanged'] = bool(tracked) and len(record['identity_after']) == len(tracked) and all(item.get('unchanged') for item in record['identity_after'].values())
        if helper is not None and source_before is not None:
            try:
                after = helper.source_manifest(SOURCE)
                json_save(EVIDENCE / 'source-after.json', after)
                record['source_after_sha256'] = after['manifest_sha256']
                record['source_unchanged'] = source_before == after
                record['status_after'] = helper.git_value(SOURCE, ['status', '--porcelain=v1'])
                record['head_after'] = helper.git_value(SOURCE, ['rev-parse', 'HEAD'])
                record['tree_after'] = helper.git_value(SOURCE, ['rev-parse', 'HEAD^{tree}'])
                if not record['source_unchanged'] or record['status_after'] or record['head_after'] != HEAD or record['tree_after'] != TREE:
                    status = 125
            except Exception as error:
                record['source_after_error'] = repr(error)
                record['source_unchanged'] = False
                status = 125
        for name, path in [('stdout', stdout_path), ('stderr', stderr_path), ('partial_download', partial)]:
            if path.exists():
                try:
                    record[name] = identity(path)
                except Exception as error:
                    record[name] = {'path': str(path), 'error': repr(error)}
                    status = 125
        record['elapsed_seconds'] = time.monotonic() - began
        if record['elapsed_seconds'] > 180:
            record['whole_budget_exceeded'] = True
            if status != 125:
                status = 124
        record.update(phase='completed', exit_code=status, end_unix=time.time())
        save()
        after_save_elapsed = time.monotonic() - began
        if after_save_elapsed > 180:
            record['elapsed_seconds'] = after_save_elapsed
            record['whole_budget_exceeded'] = True
            record['budget_observation_scope'] = 'Measured again after the final receipt write.'
            if status != 125:
                status = record['exit_code'] = 124
            save()
        if lock is not None:
            lock.close()
        print(json.dumps({key: record.get(key) for key in ('phase', 'exit_code', 'native_exit_code',
              'comparison_exit_code', 'probe_launch_attempts', 'probe_processes_started', 'completed_native_cases',
              'source_unchanged', 'all_observed_files_unchanged', 'failure')}, sort_keys=True), flush=True)
    return status


if __name__ == '__main__':
    raise SystemExit(main())
