import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time
import traceback

ROOT = Path('/home/qian-qi/workspace/pipecat-workspace-f9f576cc6c66')
BUNDLE = ROOT / 'requests/smart-turn-wheel-launch-pin-r3'
SCRIPT = ROOT / 'desktop_smart_turn_wheel_pin_r3.py'
SCRIPT_SHA = '7d23169a11c4790a4cb7294932fb43143d6933c08e1f041ef34daee5b7b22e98'
HELPER_SHA = 'c6b639d10e4e0d48910d007a161d7b35e81744bd5e31f878f960bdcd452b47e4'
BUNDLE.mkdir(mode=0o700, exist_ok=False)
record = {'schema': 'pipecat-reviewed-execv-bootstrap-v1', 'phase': 'preparing',
          'start_unix': time.time(), 'requested_resource_budget': {
              'cpu_quota_percent': 200, 'memory_max_bytes': 4294967296,
              'nice': 10, 'timeout_seconds': 210},
          'postflight_receipt': str(ROOT / 'evidence/smart-turn-wheel-reference-pin-r3/reference.json'),
          'scope': 'Exec replaces this process with the unchanged reviewed C3 runner. Its own identity_before/after covers itself and the source helper. The inner REQUEST and EVIDENCE directories are not created by this bootstrap.'}

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def save():
    (BUNDLE / 'bootstrap.json').write_text(json.dumps(record, indent=2) + '\n')

try:
    payload = json.load(sys.stdin)
    original = sys.orig_argv[2].encode('utf-8')
    if sys.orig_argv[1] != '-c' or digest(original) != payload['bootstrap_sha256']:
        raise ValueError('actual bootstrap identity mismatch')
    (BUNDLE / 'bootstrap.py').write_bytes(original)
    record['bootstrap_sha256'] = digest(original)
    raw = payload['script'].encode('utf-8')
    if len(raw) != 36363 or digest(raw) != SCRIPT_SHA:
        raise ValueError('reviewed C3 runner changed')
    if SCRIPT.exists():
        if not stat.S_ISREG(SCRIPT.lstat().st_mode) or SCRIPT.read_bytes() != raw:
            raise ValueError('C3 runner path already has different bytes or file type')
    else:
        with SCRIPT.open('xb') as handle:
            handle.write(raw)
        SCRIPT.chmod(0o700)
    (BUNDLE / 'executed-runner.py.before').write_bytes(raw)
    record['script'] = {'path': str(SCRIPT), 'bytes': len(raw), 'sha256': digest(raw)}
    helper = (ROOT / 'run_full_gate.py').read_bytes()
    if len(helper) != 5176 or digest(helper) != HELPER_SHA:
        raise ValueError('source-manifest helper changed')
    (BUNDLE / 'run_full_gate.py.before').write_bytes(helper)
    record['helper_sha256_before'] = digest(helper)
    api = payload['preceding_runtime_status_observation']
    if api.get('job_id') != '1a1b1fb70c1-fc05-7bde' or api.get('state') not in ('succeeded', 'failed') or type(api.get('exit_code')) is not int or api.get('output_complete') is not True or api.get('output_durable') is not True or api.get('timed_out') is not False:
        raise ValueError('AISHELL runtime is not authoritatively terminal')
    record['preceding_runtime_status_observation'] = api
    previous_raw = (ROOT / 'evidence/aishell-human-pin-r1/result.json').read_bytes()
    previous = json.loads(previous_raw)
    if previous.get('phase') != 'completed' or previous.get('wrapper_exit_code') != api['exit_code'] or previous.get('source_unchanged') is not True or previous.get('files_unchanged') is not True or previous.get('status_after'):
        raise ValueError('preceding AISHELL result is not terminal and intact')
    outer_raw = (ROOT / 'requests/aishell-human-launch-pin-r1/launcher.json').read_bytes()
    outer = json.loads(outer_raw)
    if outer.get('phase') != 'completed' or outer.get('files_unchanged') is not True or outer.get('exit_code') != api['exit_code']:
        raise ValueError('AISHELL launcher is not terminal and intact')
    (BUNDLE / 'preceding-aishell-result.json').write_bytes(previous_raw)
    (BUNDLE / 'preceding-aishell-launcher.json').write_bytes(outer_raw)
    record['preceding_aishell_result_sha256'] = digest(previous_raw)
    record['preceding_aishell_launcher_sha256'] = digest(outer_raw)
    argv = [sys.executable, str(SCRIPT)]
    record.update(phase='exec_requested', actual_argv=argv, cwd=str(ROOT),
                  same_process_pid=os.getpid(), exec_request_unix=time.time())
    save()
    os.chdir(ROOT)
    os.execv(sys.executable, argv)
except Exception as error:
    record.update(phase='preparation_failed', exit_code=127, exception=repr(error), end_unix=time.time())
    (BUNDLE / 'bootstrap-error.log').write_text(traceback.format_exc())
    save()
    print(json.dumps(record), flush=True)
    raise SystemExit(127)
