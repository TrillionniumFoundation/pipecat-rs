import hashlib
import json
import os
from pathlib import Path
import runpy
import sys
import time
import traceback

ROOT = Path('/home/qian-qi/workspace/pipecat-workspace-f9f576cc6c66')
BUNDLE = ROOT / 'requests/webrtc-stress-launch-pin-r1'
HEAD = '0cc16e8123cb05aaad480d5ab7860a267d998bac'
TREE = 'aec037b9cf2be53fcf6f85fdc149382942277702'
EXPECTED = [(BUNDLE / 'desktop_webrtc_stress_pin_r3.py', 20150,
             'f3e09db38d5f257892fa25cb1840a3cca99adfedfdcac98a24863ff2bb3eb318'),
            (ROOT / 'run_full_gate.py', 5176,
             'c6b639d10e4e0d48910d007a161d7b35e81744bd5e31f878f960bdcd452b47e4')]
BUNDLE.mkdir(mode=0o700, exist_ok=False)
record = {'schema': 'pipecat-reviewed-inprocess-runner-bootstrap-v1', 'phase': 'preparing',
          'head': HEAD, 'tree': TREE, 'start_unix': time.time(),
          'requested_resource_budget': {'cpu_quota_percent': 400, 'memory_max_bytes': 17179869184,
                                        'nice': 10, 'timeout_seconds': 900},
          'files_before': [], 'files_after': [],
          'scope': 'The unchanged reviewed runner is entered with runpy in this same process and its exact argv. It owns all native process groups and deadlines. This wrapper adds no extra unmanaged child and only binds original script/helper bytes before and after.'}

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def save():
    (BUNDLE / 'launcher.json').write_text(json.dumps(record, indent=2) + '\n')

status = 127
try:
    payload = json.load(sys.stdin)
    actual_bootstrap = sys.orig_argv[2].encode('utf-8')
    if sys.orig_argv[1] != '-c' or digest(actual_bootstrap) != payload['bootstrap_sha256']:
        raise ValueError('bootstrap actual argv identity mismatch')
    (BUNDLE / 'bootstrap.py').write_bytes(actual_bootstrap)
    record['bootstrap_sha256'] = digest(actual_bootstrap)
    script = payload['script'].encode('utf-8')
    if len(script) != EXPECTED[0][1] or digest(script) != EXPECTED[0][2]:
        raise ValueError('reviewed WebRTC r3 bytes changed')
    EXPECTED[0][0].write_bytes(script)
    for path, size, checksum in EXPECTED:
        raw = path.read_bytes()
        if len(raw) != size or digest(raw) != checksum:
            raise ValueError('reviewed runner/helper changed: ' + str(path))
        (BUNDLE / (path.name + '.before')).write_bytes(raw)
        record['files_before'].append({'path': str(path), 'bytes': len(raw), 'sha256': digest(raw)})
    api = payload['preceding_runtime_status_observation']
    if api.get('job_id') != '1a1b1e882d4-fc05-7b73' or api.get('state') not in ('succeeded', 'failed') or type(api.get('exit_code')) is not int or api.get('output_complete') is not True or api.get('output_durable') is not True or api.get('timed_out') is not False:
        raise ValueError('native model runtime is not authoritatively terminal')
    record['preceding_runtime_status_observation'] = api
    previous_raw = (ROOT / 'evidence/model-inputs-pin-r2/inputs.json').read_bytes()
    previous = json.loads(previous_raw)
    if digest(previous_raw) != payload['preceding_inputs_sha256'] or previous.get('phase') != 'completed' or previous.get('head') != HEAD or previous.get('tree') != TREE or previous.get('exit_code') != api['exit_code'] or previous.get('exit_code') in (124, 125, 127):
        raise ValueError('native model receipt is not the observed terminal result')
    if not all(previous.get(key) is True for key in ('preflight_complete', 'source_unchanged', 'all_observed_inputs_unchanged', 'espeak_unchanged')):
        raise ValueError('native model inputs/source did not remain intact')
    cleanup = previous.get('driver_cleanup', {})
    if cleanup.get('cleanup_checks_succeeded') is not True or cleanup.get('unexpected_surviving_group_after_driver_exit') is not False:
        raise ValueError('preceding native model containment is incomplete')
    (BUNDLE / 'preceding-model-inputs.json').write_bytes(previous_raw)
    record['preceding_inputs_sha256'] = digest(previous_raw)
    argv = [str(EXPECTED[0][0]), HEAD, TREE, 'full-workspace-rust-1.99.0-r5']
    record.update(phase='running', entrypoint='runpy.run_path(run_name=__main__)',
                  runner_argv=argv, python_process_argv=sys.orig_argv, same_process_pid=os.getpid(), cwd=str(ROOT))
    save()
    os.chdir(ROOT)
    sys.argv = argv
    try:
        runpy.run_path(argv[0], run_name='__main__')
        status = 0
    except SystemExit as error:
        if error.code is None:
            status = 0
        elif type(error.code) is int:
            status = error.code
        else:
            raise ValueError('reviewed runner returned a noninteger SystemExit')
    record['runner_exit_code'] = status
except BaseException as error:
    record['exception'] = repr(error)
    (BUNDLE / 'launcher-error.log').write_text(traceback.format_exc())
    status = 127
finally:
    record['runner_exit_before_integrity_checks'] = status
    for before in record['files_before']:
        try:
            raw = Path(before['path']).read_bytes()
            (BUNDLE / (Path(before['path']).name + '.after')).write_bytes(raw)
            record['files_after'].append({'path': before['path'], 'bytes': len(raw), 'sha256': digest(raw),
                                          'unchanged': len(raw) == before['bytes'] and digest(raw) == before['sha256']})
        except Exception as error:
            record['files_after'].append({'path': before['path'], 'unchanged': False, 'error': repr(error)})
    record['files_unchanged'] = len(record['files_after']) == 2 and all(item['unchanged'] for item in record['files_after'])
    if not record['files_unchanged']:
        status = 125
    record.update(phase='completed', exit_code=status, end_unix=time.time())
    save()
    print(json.dumps({key: record.get(key) for key in ('phase', 'runner_exit_code', 'exit_code', 'files_unchanged', 'exception')}), flush=True)
raise SystemExit(status)
