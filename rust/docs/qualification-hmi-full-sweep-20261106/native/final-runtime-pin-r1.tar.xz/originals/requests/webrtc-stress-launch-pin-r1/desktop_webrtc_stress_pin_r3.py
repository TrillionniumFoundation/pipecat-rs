#!/usr/bin/env python3
"""Bind one fresh exact-pin libtest executable, then run a fixed first-failure window."""
import contextlib
import fcntl
import hashlib
import importlib.util
import json
import os
import pathlib
import re
import signal
import subprocess
import sys
import time

ROOT = pathlib.Path('/home/qian-qi/workspace/pipecat-workspace-f9f576cc6c66')
SOURCE, TARGET = ROOT / 'source-pin', ROOT / 'target-pin'
CASE = 'repeated_peer_shutdown_schedules_release_both_udp_ports'
REPETITIONS = 100


def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def main():
    started = time.time()
    job_started = time.monotonic()
    deadline = job_started + 870
    expected, expected_tree, default_round = sys.argv[1:]
    if not all(re.fullmatch('[0-9a-f]{40}', item) for item in (expected, expected_tree)):
        raise ValueError('exact immutable commit and tree are required')
    if not re.fullmatch('[a-z0-9.-]+', default_round) or '..' in default_round:
        raise ValueError('invalid default evidence name')
    lock = (ROOT / 'qualification-owner-pin.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    spec = importlib.util.spec_from_file_location('source_manifest_helper', ROOT / 'run_full_gate.py')
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    previous = json.loads((ROOT / 'evidence' / default_round / 'gate.json').read_text())
    if previous.get('phase') != 'completed' or not isinstance(previous.get('exit_code'), int) or not previous.get('source_unchanged'):
        raise ValueError('the exact-pin default workspace gate must first reach a recorded terminal state on unchanged source')
    if previous['head'] != expected or previous['base_git_tree'] != expected_tree:
        raise ValueError('default gate and repetition source differ')
    if helper.git_value(SOURCE, ['rev-parse', 'HEAD']) != expected or helper.git_value(SOURCE, ['rev-parse', 'HEAD^{tree}']) != expected_tree:
        raise ValueError('unexpected source revision')
    if helper.git_value(SOURCE, ['status', '--porcelain=v1']):
        raise ValueError('the exclusive source is dirty')
    if json.loads((TARGET / '.pipecat-source-owner.json').read_text()) != {'source': str(SOURCE), 'task': 'workspace-f9f576cc6c66'}:
        raise ValueError('compiled target ownership changed')
    evidence = ROOT / 'evidence/webrtc-stress-pin-r1'
    evidence.mkdir(exist_ok=False)
    before = helper.source_manifest(SOURCE)
    (evidence / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
    environment = json.loads((ROOT / 'evidence' / default_round / 'environment.json').read_text())
    environment['CARGO_TARGET_DIR'] = str(TARGET)
    environment['CARGO_BUILD_JOBS'] = '4'
    env = dict(os.environ, **environment)
    cargo = str(ROOT / 'tools/rust-1.99.0-r1/bin/cargo')
    bind_argv = [cargo, 'test', '--locked', '--offline', '-p', 'pipecat-webrtc', '--test', 'review_lifecycle', '--no-run', '--message-format=json-render-diagnostics']
    record = {'schema': 'pipecat-fixed-first-failure-repetition-window-v1',
              'head': expected, 'tree': expected_tree, 'source': str(SOURCE), 'target': str(TARGET),
              'preceding_default': {'evidence': default_round, 'exit_code': previous['exit_code'], 'source_unchanged': True,
                                    'scope': 'A failed default remains failed; this repetition window is independent.'},
              'toolchain': '1.99.0', 'case': CASE, 'target_name': 'review_lifecycle',
              'requested_repetitions': REPETITIONS, 'unique_coverage_cases': 1,
              'policy': 'Stop at the first nonzero exit, deadline, or mismatched libtest selection; do not replace failed rounds with later passes.',
              'historical_failure_scope': 'This bounded window does not erase the historical data-channel setup timeout or full-workspace UDP failure.',
              'original_internal_deadlines': 'A/B setup 5s each; UDP rebind 2s, unchanged in product/test source.',
              'resource_budget': {'build_jobs': 4, 'cpu_quota_percent': 400, 'memory_max_bytes': 17179869184, 'nice': 10},
              'outer_runtime_timeout_seconds': 900, 'internal_whole_job_budget_seconds': 870,
              'phase_containment': 'Each metadata/binding/selection/test invocation owns a new process group; at most 3s is reserved for TERM/KILL and leader reap after a phase limit.',
              'environment_overrides': environment, 'binding_argv': bind_argv,
              'source_before_sha256': before['manifest_sha256'], 'start_unix': started,
              'phase': 'binding', 'processes': [], 'rounds': []}
    record_path = evidence / 'repetitions.json'

    def save():
        record_path.write_text(json.dumps(record, indent=2) + '\n')

    def group_present(pid, entry):
        try:
            os.killpg(pid, 0)
            return True
        except ProcessLookupError:
            return False
        except OSError as exc:
            entry.setdefault('cleanup_errors', []).append(f'group probe: {type(exc).__name__}: {exc}')
            return None

    def cleanup_owned(child, entry):
        cleanup_started = time.monotonic()
        entry['cleanup_attempted'] = True
        requests = entry.setdefault('process_group_signal_requests', [])
        for sig, wait_seconds in [(signal.SIGTERM, 2), (signal.SIGKILL, 1)]:
            request = {'pgid': child.pid, 'signal': int(sig)}
            try:
                os.killpg(child.pid, sig)
                request['result'] = 'signal requested'
            except ProcessLookupError:
                request['result'] = 'group absent at request'
            except OSError as exc:
                request['error'] = f'{type(exc).__name__}: {exc}'
                entry.setdefault('cleanup_errors', []).append(request['error'])
            requests.append(request)
            if child.returncode is None:
                try:
                    child.wait(timeout=wait_seconds)
                except subprocess.TimeoutExpired:
                    entry.setdefault('cleanup_wait_timeouts', []).append(wait_seconds)
                except OSError as exc:
                    entry.setdefault('cleanup_errors', []).append(f'leader wait: {type(exc).__name__}: {exc}')
        entry['cleanup_elapsed_seconds'] = time.monotonic() - cleanup_started
        entry['cleanup_scope'] = ('Signals were requested only for this newly created process group. '
                                  'Leader reap and final group existence are separate observations; '
                                  'neither a signal request nor group absence proves all descendants joined.')

    def run_owned(argv, entry, stdout_path, stderr_path, limit_seconds):
        """Run one owned process group; preserve its exact exit and bounded cleanup."""
        entry.update(argv=argv, start_unix=time.time(), phase='starting',
                     phase_timeout_limit_seconds=limit_seconds,
                     process_group_signal_requests=[], cleanup_attempted=False)
        begin = time.monotonic()
        child = None
        execution_finished = None
        phase_status = 127
        logs = {'stdout': stdout_path}
        if stderr_path is not None:
            logs['stderr'] = stderr_path
        save()
        try:
            effective = min(limit_seconds, deadline - time.monotonic() - 3)
            entry['effective_timeout_seconds'] = max(0, effective)
            phase_deadline = time.monotonic() + max(0, effective)
            if effective <= 0:
                phase_status = 124
                entry['outer_timeout'] = True
                entry['stop_reason'] = 'whole-job budget exhausted before owned process admission'
            else:
                with contextlib.ExitStack() as stack:
                    stdout = stack.enter_context(stdout_path.open('wb'))
                    stderr = stack.enter_context(stderr_path.open('wb')) if stderr_path is not None else subprocess.STDOUT
                    child = subprocess.Popen(argv, cwd=SOURCE / 'rust', env=env, stdout=stdout,
                                             stderr=stderr, start_new_session=True)
                    entry.update(pid=child.pid, pgid=child.pid, phase='running')
                    if 'round' in entry:
                        entry['harness_pid'] = child.pid
                    # The in-flight round/phase and PID survive an outer interruption.
                    save()
                    try:
                        remaining_wait = max(0, min(phase_deadline, deadline - 3) - time.monotonic())
                        entry['effective_wait_seconds'] = remaining_wait
                        phase_status = child.wait(timeout=remaining_wait)
                    except subprocess.TimeoutExpired:
                        phase_status = 124
                        entry['outer_timeout'] = True
                        entry['timeout_scope'] = 'runner process limit; original Rust deadlines unchanged'
                    finally:
                        execution_finished = time.monotonic()
                    entry['execution_exit_code'] = phase_status
                    present = group_present(child.pid, entry)
                    if child.returncode is None or present is not False:
                        cleanup_owned(child, entry)
                        if phase_status == 0:
                            phase_status = 125
                            entry['stop_reason'] = 'owned process group survived normal leader exit'
        except Exception as exc:
            if execution_finished is None:
                execution_finished = time.monotonic()
            entry['process_error'] = f'{type(exc).__name__}: {exc}'
            if isinstance(exc, subprocess.TimeoutExpired):
                phase_status = 124
            elif phase_status == 0:
                phase_status = 127
        finally:
            if execution_finished is None:
                execution_finished = time.monotonic()
            if child is not None:
                if not entry['cleanup_attempted'] and child.returncode is None:
                    cleanup_owned(child, entry)
                entry['leader_reaped'] = child.returncode is not None
                entry['leader_exit_code'] = child.returncode
                entry['process_group_present_at_final_probe'] = group_present(child.pid, entry)
                if not entry['leader_reaped'] or entry['process_group_present_at_final_probe'] is not False or entry.get('cleanup_errors'):
                    if phase_status == 0:
                        phase_status = 125
                    entry['cleanup_incomplete'] = True
            else:
                entry['leader_reaped'] = False
                entry['leader_exit_code'] = None
                entry['process_group_present_at_final_probe'] = None
            entry.setdefault('execution_exit_code', phase_status)
            entry['exit_code'] = phase_status
            entry['execution_elapsed_seconds'] = execution_finished - begin
            entry['logs'] = {}
            for kind, path in logs.items():
                try:
                    entry['logs'][kind] = {'path': str(path), 'bytes': path.stat().st_size,
                                           'sha256': sha(path)}
                except OSError as exc:
                    entry['logs'][kind] = {'path': str(path), 'error': f'{type(exc).__name__}: {exc}'}
                    if entry['exit_code'] == 0:
                        entry['exit_code'] = 125
            entry['elapsed_seconds'] = time.monotonic() - begin
            entry['end_unix'] = time.time()
            entry['phase'] = 'completed' if entry['leader_reaped'] else 'not_reaped_or_not_started'
            save()
        return entry['exit_code']

    save()
    status = 127
    binary = None
    try:
        metadata_argv = [cargo, 'metadata', '--no-deps', '--format-version', '1', '--locked', '--offline']
        metadata_entry = {'name': 'metadata'}
        record['processes'].append(metadata_entry)
        record['metadata_argv'] = metadata_argv
        status = run_owned(metadata_argv, metadata_entry, evidence / 'metadata.stdout.json',
                           evidence / 'metadata.stderr.log', 60)
        record['metadata_exit_code'] = status
        if status:
            raise ValueError('artifact package identity metadata failed')
        packages = [item for item in json.loads((evidence / 'metadata.stdout.json').read_bytes())['packages'] if item['name'] == 'pipecat-webrtc']
        if len(packages) != 1:
            raise ValueError('expected one exact WebRTC package identity')
        package_id = packages[0]['id']
        binding_entry = {'name': 'binding'}
        record['processes'].append(binding_entry)
        status = run_owned(bind_argv, binding_entry, evidence / 'binding.log', None, 300)
        record['binding_exit_code'] = status
        record['binding_log_sha256'] = sha(evidence / 'binding.log')
        if status:
            raise RuntimeError('fresh executable binding failed')
        artifacts = []
        for line in (evidence / 'binding.log').read_text().splitlines():
            try:
                message = json.loads(line)
            except json.JSONDecodeError:
                continue
            if message.get('reason') == 'compiler-artifact' and message.get('target', {}).get('name') == 'review_lifecycle' and message.get('target', {}).get('kind') == ['test']:
                if not message.get('profile', {}).get('test') or message.get('package_id') != package_id:
                    raise ValueError('libtest artifact belongs to an unexpected package/profile')
                artifacts.append(message)
        if len(artifacts) != 1:
            raise ValueError('expected one compiler-reported review_lifecycle test artifact')
        artifact = artifacts[0]
        binary = pathlib.Path(artifact['executable']).resolve()
        if binary.parent != TARGET / 'debug/deps' or not binary.name.startswith('review_lifecycle-'):
            raise ValueError('executable escaped this exclusive target')
        binary_sha = sha(binary)
        record['binary'] = {'path': str(binary), 'bytes': binary.stat().st_size, 'sha256_before': binary_sha,
                            'compiler_artifact': artifact}
        selection_argv = [str(binary), CASE, '--exact', '--list']
        selection_entry = {'name': 'selection'}
        record['processes'].append(selection_entry)
        status = run_owned(selection_argv, selection_entry, evidence / 'selection.log', None, 10)
        listed = (evidence / 'selection.log').read_text()
        if status or listed.splitlines().count(CASE + ': test') != 1 or '1 test, 0 benchmarks' not in listed:
            raise ValueError('the exact selector did not identify exactly one test')
        record['selection_argv'] = selection_argv
        record['phase'] = 'running'
        save()
        status = 0
        for index in range(1, REPETITIONS + 1):
            remaining = deadline - time.monotonic()
            if remaining <= 3:
                status = 124
                record['stop_reason'] = 'whole-job wall-time budget exhausted before next round'
                break
            argv = [str(binary), CASE, '--exact', '--nocapture', '--test-threads=1']
            log = evidence / f'round-{index:03d}.log'
            entry = {'round': index}
            record['rounds'].append(entry)
            status = run_owned(argv, entry, log, None, 120)
            entry['log_sha256'] = sha(log)
            entry['log_bytes'] = log.stat().st_size
            summaries = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log.read_text(), re.MULTILINE)
            entry['exact_selection_satisfied'] = summaries == [('1', '0', '0')]
            save()
            print(json.dumps(entry, sort_keys=True), flush=True)
            if entry['exit_code'] != 0 or not entry['exact_selection_satisfied']:
                status = entry['exit_code'] or 126
                record['stop_reason'] = 'first unsuccessful round; no follow-up repetitions launched'
                break
        if len(record['rounds']) == REPETITIONS and status == 0:
            record['stop_reason'] = 'predeclared 100-round budget completed'
    except Exception as exc:
        record['exception'] = f'{type(exc).__name__}: {exc}'
        if isinstance(exc, subprocess.TimeoutExpired):
            status = 124
        elif status == 0:
            status = 127
    finally:
        record['execution_exit_code'] = status
        try:
            after = helper.source_manifest(SOURCE)
            (evidence / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
            record.update(source_after_sha256=after['manifest_sha256'], source_unchanged=before == after)
        except Exception as exc:
            record['source_after_error'] = f'{type(exc).__name__}: {exc}'
            record['source_unchanged'] = False
        try:
            record['status_after'] = helper.git_value(SOURCE, ['status', '--porcelain=v1'])
        except Exception as exc:
            record['status_after_error'] = f'{type(exc).__name__}: {exc}'
            record['status_after'] = 'unavailable'
        if record.get('binary') is not None:
            try:
                record['binary']['sha256_after'] = sha(binary)
                record['binary']['unchanged'] = record['binary']['sha256_before'] == record['binary']['sha256_after']
            except Exception as exc:
                record['binary']['after_error'] = f'{type(exc).__name__}: {exc}'
                record['binary']['unchanged'] = False
        if not record['source_unchanged'] or record['status_after'] or (record.get('binary') is not None and not record['binary']['unchanged']):
            status = 125
        for entry in record['processes'] + record['rounds']:
            if entry.get('phase') in ('completed', 'not_reaped_or_not_started'):
                continue
            entry['phase'] = 'interrupted_by_runner_error'
            if 'round' in entry:
                log = evidence / f"round-{entry['round']:03d}.log"
                try:
                    entry['log_sha256'] = sha(log)
                    entry['log_bytes'] = log.stat().st_size
                except OSError as exc:
                    entry['log_error'] = f'{type(exc).__name__}: {exc}'
        record['whole_job_elapsed_seconds'] = time.monotonic() - job_started
        if record['whole_job_elapsed_seconds'] > 870:
            status = 124
            record['budget_exceeded'] = True
            record['stop_reason_before_budget_check'] = record.get('stop_reason')
            record['stop_reason'] = 'measured whole-job execution exceeded the predeclared 870-second cap'
        record.update(phase='completed', end_unix=time.time(), exit_code=status,
                      attempted_repetitions=len(record['rounds']),
                      launched_repetitions=sum('pid' in entry for entry in record['rounds']),
                      completed_repetitions=sum(entry.get('phase') == 'completed' for entry in record['rounds']),
                      successful_repetitions=sum(entry.get('exit_code') == 0 and entry.get('exact_selection_satisfied', False) for entry in record['rounds']))
        save()
        final_elapsed = time.monotonic() - job_started
        if final_elapsed > 870 and status == 0:
            status = record['exit_code'] = 124
            record['whole_job_elapsed_seconds'] = final_elapsed
            record['budget_exceeded'] = True
            record['stop_reason_before_budget_check'] = record.get('stop_reason')
            record['stop_reason'] = 'final evidence write exceeded the predeclared 870-second cap'
            save()
        print(json.dumps({key: record.get(key) for key in ('phase', 'exit_code', 'completed_repetitions', 'stop_reason', 'source_unchanged', 'exception')}, sort_keys=True), flush=True)
    return status


if __name__ == '__main__':
    raise SystemExit(main())
