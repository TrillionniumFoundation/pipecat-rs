import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback

ROOT = Path('/home/qian-qi/workspace/pipecat-workspace-f9f576cc6c66')
BUNDLE = ROOT / 'requests/moq-diagnostic-launch-pin-r1'
HEAD = 'c1c3addb07dde0a143462c10961ff2494eeba90a'
TREE = '4df0d197540551ed9b74d4e11c0936e5bedee5f5'
CONTRACT_SHA = 'c255d772305af493508754d78797cad6a8abb827aa40669b2b392b5c0b3256a3'
SCRIPT = ROOT / 'desktop_moq_diagnostic_pin_r1.py'
FIXED = [(SCRIPT, 33499, 'bfbba41f328657e6db1bc3498a0636d2209e84ae163ff51c0912bc277d94e8af'),
         (ROOT / 'run_full_gate.py', 5176, 'c6b639d10e4e0d48910d007a161d7b35e81744bd5e31f878f960bdcd452b47e4'),
         (ROOT / 'requests/moq-diagnostic-pin-r1.source-contract.json', 11511, CONTRACT_SHA),
         (ROOT / 'requests/moq-diagnostic-pin-r1.case-names.json', 6882, 'e87d053861a5d96597d28371305e85676864b27477334abcf218a843539f2a41')]
BUNDLE.mkdir(mode=0o700, exist_ok=False)
record = {'schema': 'pipecat-reviewed-execv-bootstrap-v1', 'phase': 'preparing',
          'head': HEAD, 'tree': TREE, 'start_unix': time.time(), 'inputs_before': [],
          'requested_resource_budget': {'timeout_seconds': 600, 'cpu_quota_percent': 800,
                                        'memory_max_bytes': 34359738368, 'nice': 10},
          'postflight_receipt': str(ROOT / 'evidence/moq-diagnostic-pin-r1/repetitions.json'),
          'scope': 'The source update is a separate completed preparation job. Exec replaces this process with the unchanged reviewed 570-second runner, which owns the same lock and records each tracked input before and after. This bootstrap creates no native test child.'}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def save():
    (BUNDLE / 'bootstrap.json').write_text(json.dumps(record, indent=2) + '\n')

try:
    payload = json.load(sys.stdin)
    original = sys.orig_argv[2].encode()
    if sha(original) != payload['bootstrap_sha256']:
        raise ValueError('bootstrap source changed')
    (BUNDLE / 'bootstrap.py').write_bytes(original)
    record['bootstrap_sha256'] = sha(original)
    api = payload['preceding_runtime_status_observation']
    if api.get('job_id') != '1a1b20697e6-fc05-7c15' or api.get('state') != 'succeeded' or api.get('exit_code') != 0 or api.get('output_complete') is not True or api.get('output_durable') is not True or api.get('timed_out') is not False:
        raise ValueError('Q preparation runtime is not authoritatively complete')
    record['preceding_runtime_status_observation'] = api
    raw = (ROOT / 'evidence/final-diagnostic-source-preparation-r1/preparation.json').read_bytes()
    prior = json.loads(raw)
    if sha(raw) != payload['preparation_sha256'] or prior.get('phase') != 'completed' or prior.get('exit_code') != 0 or prior.get('head') != HEAD or prior.get('tree') != TREE or not all(prior.get(k) is True for k in ('new_source_contract_verified', 'helper_unchanged', 'staged_inputs_unchanged')) or prior.get('source_after_sha256') != '23a585582dba548ece61948fcb87ec32a0689ff46bef20ace1739edd3986e20d':
        raise ValueError('Q source preparation receipt differs')
    (BUNDLE / 'source-preparation.json').write_bytes(raw)
    record['source_preparation_sha256'] = sha(raw)
    for path, size, checksum in FIXED:
        raw = path.read_bytes()
        if len(raw) != size or sha(raw) != checksum:
            raise ValueError('reviewed MoQ input changed: ' + str(path))
        (BUNDLE / (path.name + '.before')).write_bytes(raw)
        record['inputs_before'].append({'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)})
    argv = [sys.executable, str(SCRIPT), HEAD, TREE, CONTRACT_SHA]
    record.update(phase='exec_requested', actual_argv=argv, cwd=str(ROOT),
                  same_process_pid=os.getpid(), exec_request_unix=time.time())
    save()
    os.chdir(ROOT)
    os.execv(sys.executable, argv)
except Exception as error:
    record.update(phase='preparation_failed', exit_code=127, exception=repr(error), end_unix=time.time())
    (BUNDLE / 'bootstrap-error.log').write_text(traceback.format_exc())
    save()
    print(json.dumps(record), flush=True)
    raise SystemExit(127)
