#!/usr/bin/env python3
"""Serial independently recorded gates; failed gates remain failures."""
import hashlib
import json
import pathlib
import re
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path('/home/qian-qi/workspace/pipecat-workspace-f9f576cc6c66')
WRAPPER = ROOT / 'desktop_additional_gate_pin_v4.py'
WRAPPER_SHA = 'ec7df29d960309ec486ed403636d1151c8ac35a86842bbb692a08ddbd5b2eba6'
RUNNER = ROOT / 'run_qualification_command_pin_v3.py'
RUNNER_SHA = '8654269c9b24b6ee828d71a4827f54e3366de6177f760471644b72fea4749f35'
expected, tree, default_round, mode, attempt = sys.argv[1:]
if not all(re.fullmatch('[0-9a-f]{40}', item) for item in (expected, tree)):
    raise ValueError('exact immutable commit and tree required')
if mode not in ('expanded', 'optins'):
    raise ValueError('only reviewed expanded or native opt-in modes are allowed')
if not all(re.fullmatch('[a-z0-9.-]+', item) and '..' not in item for item in (default_round, attempt)):
    raise ValueError('invalid evidence identifier')
evidence = ROOT / 'evidence' / f'{mode}-batch-{attempt}'
evidence.mkdir(exist_ok=False)
previous = json.loads((ROOT / 'evidence' / default_round / 'gate.json').read_text())
if previous.get('phase') != 'completed' or not isinstance(previous.get('exit_code'), int) or not previous.get('source_unchanged') or previous['head'] != expected or previous['base_git_tree'] != tree:
    raise ValueError('preceding original default must be terminal and bound to this unchanged source')
record = {
    'schema': 'pipecat-serial-independent-gate-batch-v1', 'mode': mode,
    'head': expected, 'tree': tree, 'attempt': attempt,
    'preceding_default': {'evidence':default_round,'exit_code':previous['exit_code'],'source_unchanged':True},
    'scope': 'Each stage has its own original argv/raw/source/exit record. No failures or repeat counts are merged into a green result.',
    'outer_runtime_policy': {'timeout_seconds':3600,'cpu_quota_percent':800,'memory_max_bytes':34359738368,'nice':10},
    'supplement_policy': 'At most one cargo-level no-fail-fast supplement for each original command that stopped after a runtime failure; retain the original failure and do not add coverage counts across runs.',
    'start_unix':time.time(),'phase':'preparing','stages':[],'failure':None,
}
record_path = evidence / 'batch.json'
driver_path = pathlib.Path(__file__).resolve()
driver_raw = driver_path.read_bytes()
driver_sha = hashlib.sha256(driver_raw).hexdigest()
(evidence / 'executed-driver.py').write_bytes(driver_raw)
record['driver'] = {'path': str(driver_path), 'bytes': len(driver_raw), 'sha256_before': driver_sha}


def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def save():
    record_path.write_text(json.dumps(record, indent=2)+'\n')


def runtime_failure(gate_dir):
    log = ROOT / 'evidence' / gate_dir
    if (log / 'cargo-test-workspace.log').exists():
        log = log / 'cargo-test-workspace.log'
    else:
        log = log / 'command.log'
    raw = log.read_bytes()
    summary = bool(re.search(rb'(?m)^test result: (?:ok|FAILED)\.', raw))
    compile_error = bool(re.search(
        rb"(?m)^(?:error(?:\[[^\]]+\])?: (?:could not compile\b|failed to run custom build command\b|failed custom build\b)|error\[E\d+\]:|Couldn't compile the test\.)", raw))
    return summary and not compile_error


def run_stage(stage):
    if sha(driver_path) != driver_sha:
        record['integrity_failure'] = True
        raise ValueError('the executing driver file changed before the next stage')
    for path, digest in [(WRAPPER, WRAPPER_SHA), (RUNNER, RUNNER_SHA)]:
        if sha(path) != digest:
            record['integrity_failure'] = True
            raise ValueError('reviewed stage runner changed')
    free = shutil.disk_usage(ROOT).free
    if free < 2147483648:
        raise ValueError('less than 2GiB free disk remains for the owned stage')
    argv = [sys.executable,str(WRAPPER),expected,tree,default_round,stage,attempt]
    entry = {'stage':stage,'argv':argv,'start_unix':time.time(),'phase':'running',
             'free_disk_before_bytes':free,'wrapper_sha256_before':WRAPPER_SHA,'runner_sha256_before':RUNNER_SHA}
    record['stages'].append(entry)
    record['phase'] = 'running'
    save()
    driver_log = evidence / (stage+'.driver.log')
    with driver_log.open('wb') as handle:
        result = subprocess.run(argv, cwd=ROOT, stdout=handle, stderr=subprocess.STDOUT)
    entry['wrapper_exit_code'] = result.returncode
    entry['driver_log_sha256'] = sha(driver_log)
    entry['driver_log_bytes'] = driver_log.stat().st_size
    entry['end_unix'] = time.time()
    gate_path = ROOT / 'evidence' / f'{stage}-{attempt}' / 'gate.json'
    if not gate_path.exists():
        entry['phase'] = 'preparation_failed'
        save()
        raise ValueError('stage did not produce a terminal command receipt')
    gate = json.loads(gate_path.read_text())
    entry['command_exit_code'] = gate.get('exit_code')
    entry['source_unchanged'] = gate.get('source_unchanged')
    entry['gate_sha256'] = sha(gate_path)
    entry['evidence'] = str(gate_path.parent)
    entry['wrapper_sha256_after'] = sha(WRAPPER)
    entry['runner_sha256_after'] = sha(RUNNER)
    if gate.get('phase') != 'completed' or gate.get('head') != expected or gate.get('base_git_tree') != tree or not gate.get('source_unchanged') or gate.get('status_after') or entry['wrapper_sha256_after'] != WRAPPER_SHA or entry['runner_sha256_after'] != RUNNER_SHA or result.returncode == 125:
        entry['phase'] = 'integrity_or_terminal_state_failed'
        save()
        raise ValueError('stage source, artifact, scripts or terminal state failed verification')
    entry['phase'] = 'completed'
    test_stage = stage in ('default-no-fail-fast', 'all-features-all-targets',
                          'all-features-all-targets-no-fail-fast', 'local-sfu', 'chinese-synthetic') or stage.startswith(('piper-', 'whisper-owner-'))
    if result.returncode and test_stage:
        entry['runtime_failure_without_compiler_error'] = runtime_failure(f'{stage}-{attempt}')
    save()
    print(json.dumps({key:entry.get(key) for key in ('stage','wrapper_exit_code','command_exit_code','source_unchanged','evidence')}),flush=True)
    if result.returncode and test_stage and not entry['runtime_failure_without_compiler_error']:
        raise RuntimeError('failed test stage has compiler-error evidence or no runtime summary; resolve that failure before later stages')
    return result.returncode


def retain_existing_default_supplement():
    stage = 'default-no-fail-fast'
    prior_dir = ROOT / 'evidence' / f'{stage}-{attempt}'
    if not prior_dir.exists():
        return False
    gate_path = prior_dir / 'gate.json'
    execution_path = ROOT / 'requests' / f'{stage}-{attempt}' / 'runner-execution.json'
    gate = json.loads(gate_path.read_text())
    execution = json.loads(execution_path.read_text())
    expected_argv = [str(ROOT / 'tools/rust-1.99.0-r1/bin/cargo'), 'test', '--workspace', '--locked', '--no-fail-fast']
    if gate.get('phase') != 'completed' or gate.get('head') != expected or gate.get('base_git_tree') != tree or not gate.get('source_unchanged') or gate.get('status_after') or gate.get('argv') != expected_argv:
        raise ValueError('existing default supplement is not an immutable terminal receipt for this source and argv')
    if execution.get('phase') != 'completed' or not execution.get('scripts_unchanged') or execution.get('qualification_argv') != expected_argv or not isinstance(execution.get('wrapper_exit_code'), int):
        raise ValueError('existing default supplement lacks its complete wrapper/script receipt')
    if type(gate.get('exit_code')) is not int or (gate['exit_code'] != 0 and execution['wrapper_exit_code'] == 0):
        raise ValueError('existing default supplement command and wrapper exit states are inconsistent')
    identities = {item['role']: item['sha256'] for item in execution['scripts_before']}
    if identities != {'wrapper': WRAPPER_SHA, 'runner': RUNNER_SHA}:
        raise ValueError('existing default supplement used another runner generation')
    entry = {'stage': stage, 'phase': 'retained_prior_record', 'executed_by_this_batch': False,
             'wrapper_exit_code': execution['wrapper_exit_code'], 'command_exit_code': gate['exit_code'],
             'source_unchanged': True, 'evidence': str(prior_dir), 'gate_sha256': sha(gate_path),
             'runner_execution_sha256': sha(execution_path),
             'command_log_sha256': sha(prior_dir / 'command.log'),
             'command_log_bytes': (prior_dir / 'command.log').stat().st_size,
             'scope': 'The one already executed supplemental command is retained; it is never replayed by this batch.'}
    record['stages'].append(entry)
    save()
    if entry['wrapper_exit_code'] == 125:
        record['integrity_failure'] = True
        raise ValueError('existing default supplement failed integrity verification')
    if entry['wrapper_exit_code'] and not runtime_failure(f'{stage}-{attempt}'):
        raise RuntimeError('existing default supplement has compiler-error evidence or no runtime summary')
    return True


overall = 127
save()
try:
    mem = next(int(line.split()[1])*1024 for line in pathlib.Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
    record['mem_available_before_bytes'] = mem
    if mem < 64424509440:
        raise ValueError('8-job batch requires at least 60GiB available memory at start')
    if mode == 'expanded':
        if previous['exit_code'] != 0:
            if not runtime_failure(default_round):
                raise RuntimeError('preceding default has compiler-error evidence or no runtime summary; no repeated build is started')
            if not retain_existing_default_supplement():
                run_stage('default-no-fail-fast')
        build_status = run_stage('build-normal-examples')
        if build_status:
            raise RuntimeError('normal all-features example artifacts did not bind; later expanded stages are not started')
        expanded_status = run_stage('all-features-all-targets')
        if expanded_status:
            if not runtime_failure(f'all-features-all-targets-{attempt}'):
                raise RuntimeError('expanded command failed before runtime; stop to resolve the concrete build failure')
            run_stage('all-features-all-targets-no-fail-fast')
        run_stage('strict-clippy')
        run_stage('format')
        run_stage('owned-format')
    else:
        stages = ['local-sfu','chinese-synthetic','piper-genuine-owner','piper-invalid-bounds',
                  'piper-cancel-reload','piper-long-pipeline'] + [f'whisper-owner-{i:02d}' for i in range(1,14)]
        record['declared_stages'] = stages
        save()
        for stage in stages:
            run_stage(stage)
    overall = 0 if all(entry.get('wrapper_exit_code') == 0 for entry in record['stages']) else 1
except Exception as exc:
    record['failure'] = f'{type(exc).__name__}: {exc}'
    overall = 125 if record.get('integrity_failure') or any(entry.get('phase') == 'integrity_or_terminal_state_failed' for entry in record['stages']) else 1
finally:
    record['execution_exit_code_before_driver_integrity_check'] = overall
    try:
        record['driver']['sha256_after'] = sha(driver_path)
        record['driver']['unchanged'] = record['driver']['sha256_after'] == driver_sha
    except OSError as exc:
        record['driver'].update(after_error=f'{type(exc).__name__}: {exc}', unchanged=False)
    if not record['driver']['unchanged']:
        overall = 125
    record.update(end_unix=time.time(),exit_code=overall,
                  phase='completed_successfully' if overall == 0 else 'completed_with_failures',
                  completed_stage_count=sum(entry.get('phase') == 'completed' for entry in record['stages']),
                  retained_prior_stage_count=sum(entry.get('phase') == 'retained_prior_record' for entry in record['stages']),
                  failed_stages=[entry['stage'] for entry in record['stages'] if entry.get('wrapper_exit_code') != 0])
    save()
    print(json.dumps({key:record.get(key) for key in ('mode','phase','exit_code','completed_stage_count','failed_stages','failure')}),flush=True)
raise SystemExit(overall)
