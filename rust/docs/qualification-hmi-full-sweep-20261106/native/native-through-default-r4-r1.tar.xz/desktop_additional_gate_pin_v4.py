#!/usr/bin/env python3
"""Run one independently recorded final gate on the pinned exclusive checkout."""
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys

root = pathlib.Path('/home/qian-qi/workspace/pipecat-workspace-f9f576cc6c66')
source, target = root / 'source-pin', root / 'target-pin'
expected, tree, default_round, stage, attempt = sys.argv[1:]
if not all(re.fullmatch('[0-9a-f]{40}', value) for value in (expected, tree)):
    raise ValueError('exact frozen commit and tree required')
if not all(re.fullmatch('[a-z0-9.-]+', value) and '..' not in value for value in (default_round, stage, attempt)):
    raise ValueError('invalid evidence identifier')
default = root / 'evidence' / default_round
previous = json.loads((default / 'gate.json').read_text())
if previous.get('phase') != 'completed' or not isinstance(previous.get('exit_code'), int) or not previous.get('source_unchanged'):
    raise ValueError('default full workspace gate must reach a recorded terminal state on unchanged source first')
if previous.get('head') != expected or previous.get('base_git_tree') != tree:
    raise ValueError('additional gate source differs from its default gate')
env = json.loads((default / 'environment.json').read_text())
env['CARGO_TARGET_DIR'] = str(target)
cargo = str(root / 'tools/rust-1.99.0-r1/bin/cargo')
requests = root / 'requests' / f'{stage}-{attempt}'
requests.mkdir(parents=True, exist_ok=False)
evidence = root / 'evidence' / f'{stage}-{attempt}'
preceding_default = {'evidence': str(default), 'head': previous['head'], 'tree': previous['base_git_tree'],
                     'exit_code': previous['exit_code'], 'source_unchanged': previous['source_unchanged'],
                     'scope': 'This is an independently recorded additional command; a failed default gate remains failed.'}
(requests / 'preceding-default.json').write_text(json.dumps(preceding_default, indent=2) + '\n')
commands = {
    'build-normal-examples': [cargo, 'build', '--workspace', '--all-features', '--examples', '--locked', '--message-format=json-render-diagnostics'],
    'all-features-all-targets': [cargo, 'test', '--workspace', '--all-features', '--all-targets', '--locked'],
    'default-no-fail-fast': [cargo, 'test', '--workspace', '--locked', '--no-fail-fast'],
    'all-features-all-targets-no-fail-fast': [cargo, 'test', '--workspace', '--all-features', '--all-targets', '--locked', '--no-fail-fast'],
    'strict-clippy': [cargo, 'clippy', '--workspace', '--all-targets', '--all-features', '--locked', '--', '-D', 'warnings'],
    'format': [cargo, 'fmt', '--all', '--', '--check'],
    'local-sfu': [cargo, 'test', '--locked', '-p', 'pipecat-livekit', '--test', 'local_sfu', '--', '--ignored', '--nocapture', '--test-threads=1'],
    'chinese-synthetic': [cargo, 'test', '--locked', '-p', 'pipecat-hepta', '--features', 'local-speech', '--lib', 'local_speech::native_tests::chinese_tts_to_stt_records_clean_and_noisy_model_results', '--', '--exact', '--ignored', '--nocapture', '--test-threads=1'],
}
provider_examples = {
    'aws_nova_sonic_pcm_session': 'pipecat-aws-nova-sonic',
    'azure_realtime_pcm_session': 'pipecat-azure-realtime',
    'azure_voice_live_pcm_session': 'pipecat-azure-voice-live',
    'inworld_realtime_pcm_session': 'pipecat-inworld-realtime',
}
metadata = None
if stage in ('owned-format', 'build-normal-examples'):
    metadata_argv = [cargo, 'metadata', '--no-deps', '--format-version', '1', '--locked', '--offline', '--all-features']
    result = subprocess.run(metadata_argv, cwd=source / 'rust', env=dict(os.environ, **env), capture_output=True, text=True)
    (requests / 'metadata.stdout.json').write_text(result.stdout)
    (requests / 'metadata.stderr.log').write_text(result.stderr)
    if result.returncode:
        raise ValueError('workspace metadata failed')
    metadata = json.loads(result.stdout)
    members = set(metadata['workspace_members'])
    packages = [package for package in metadata['packages'] if package['id'] in members]
    if stage == 'owned-format':
        names = sorted(package['name'] for package in packages)
        commands[stage] = [cargo, 'fmt', *[arg for name in names for arg in ['-p', name]], '--', '--check']
expected_passed = None
if stage == 'local-sfu':
    server = root / 'servers/livekit-1.13.9/livekit-server'
    if hashlib.file_digest(server.open('rb'), 'sha256').hexdigest() != '0fbb1246f555fc3d27ae92530273f53d9463bbccd93c7edb398e0c6ccfe1536b':
        raise ValueError('pinned SFU executable checksum changed')
    env['PIPECAT_LIVEKIT_SERVER'] = str(server)
    env['PIPECAT_LIVEKIT_KEEP_EVIDENCE'] = '1'
    expected_passed = 3
if stage == 'chinese-synthetic':
    env['PIPECAT_LOCAL_SPEECH_CONFIG'] = str(root / 'fixtures/chinese-synthetic-pin-r1/config.json')
    expected_passed = 1
if stage.startswith('piper-'):
    cases = {
        'piper-genuine-owner': ('native_inference', 'genuine_cpu_inference_cancellation_resampling_and_global_owner'),
        'piper-invalid-bounds': ('native_inference', 'malformed_model_config_and_output_bounds_fail_explicitly'),
        'piper-cancel-reload': ('adversarial_review', 'native::native_cancel_drop_then_reload_preserves_global_owner'),
        'piper-long-pipeline': ('native_pipeline', 'genuine_native_long_utterance_crosses_default_capacity_slow_output_exactly'),
    }
    test_target, name = cases[stage]
    commands[stage] = [cargo, 'test', '--locked', '--offline', '--all-features', '-p', 'pipecat-piper', '--test', test_target, name, '--', '--exact', '--ignored', '--nocapture', '--test-threads=1']
    env['PIPECAT_PIPER_MANIFEST'] = str(root / 'fixtures/chinese-synthetic-pin-r1/piper-config.json')
    expected_passed = 1
if stage.startswith('whisper-owner-'):
    selection = json.loads((root / 'recovered-model-test-selection.json').read_text())
    index = int(stage.removeprefix('whisper-owner-'))
    if not 1 <= index <= len(selection['recommended_whisper_cases']):
        raise ValueError('unreviewed native owner case')
    case = selection['recommended_whisper_cases'][index - 1]
    source_file = source / case['source_file']
    if hashlib.file_digest(source_file.open('rb'), 'sha256').hexdigest() != selection['source_sha256'][case['source_file']]:
        raise ValueError('selected native case changed since its input-eligibility review')
    model = selection['whisper_model']
    if hashlib.file_digest(pathlib.Path(model['path']).open('rb'), 'sha256').hexdigest() != model['sha256']:
        raise ValueError('recovered multilingual base-model checksum changed')
    env[model['env']] = model['path']
    commands[stage] = [cargo, *case['argv'][1:]]
    expected_passed = 1
artifact_manifest = None
if stage in ('all-features-all-targets', 'all-features-all-targets-no-fail-fast'):
    artifact_path = root / 'evidence' / f'build-normal-examples-{attempt}' / 'provider-example-artifacts.json'
    artifact_manifest = json.loads(artifact_path.read_text())
    if artifact_manifest['head'] != expected or artifact_manifest['tree'] != tree or len(artifact_manifest['artifacts']) != 4:
        raise ValueError('all-features normal example artifacts are not bound to this frozen source')
    for artifact in artifact_manifest['artifacts']:
        if hashlib.file_digest(pathlib.Path(artifact['executable']).open('rb'), 'sha256').hexdigest() != artifact['sha256']:
            raise ValueError('normal example changed before the expanded test gate')
    (requests / 'normal-example-artifacts-before.json').write_text(json.dumps(artifact_manifest, indent=2) + '\n')
argv = commands[stage]
(requests / 'environment.json').write_text(json.dumps(env, indent=2) + '\n')
(requests / 'argv.json').write_text(json.dumps(argv, indent=2) + '\n')
command = [sys.executable, str(root / 'run_qualification_command_pin_v3.py'),
           '--expected-commit', expected, '--expected-tree', tree,
           '--evidence', str(evidence), '--env-json', str(requests / 'environment.json'),
           '--argv-json', str(requests / 'argv.json'), '--purpose', stage]
if expected_passed is not None:
    command += ['--expected-passed', str(expected_passed)]
runner = root / 'run_qualification_command_pin_v3.py'
expected_runner_sha256 = '8654269c9b24b6ee828d71a4827f54e3366de6177f760471644b72fea4749f35'
scripts_before = []
for role, path in [('runner', runner), ('wrapper', pathlib.Path(__file__).resolve())]:
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if role == 'runner' and digest != expected_runner_sha256:
        raise ValueError('the byte-preserving qualification runner differs from its reviewed digest')
    (requests / f'executed-{role}.py').write_bytes(raw)
    scripts_before.append({'role': role, 'path': str(path), 'bytes': len(raw), 'sha256': digest})
execution = {'argv': command, 'qualification_argv': argv, 'scripts_before': scripts_before,
             'expected_runner_sha256': expected_runner_sha256, 'preceding_default': preceding_default,
             'phase': 'running'}
(requests / 'runner-execution.json').write_text(json.dumps(execution, indent=2) + '\n')
status = subprocess.run(command).returncode
execution['runner_exit_code'] = status
execution['scripts_after'] = []
for item in scripts_before:
    after = {'role': item['role'], 'path': item['path']}
    try:
        after['sha256'] = hashlib.sha256(pathlib.Path(item['path']).read_bytes()).hexdigest()
        after['unchanged'] = after['sha256'] == item['sha256']
    except OSError as exc:
        after['error'] = f'{type(exc).__name__}: {exc}'
        after['unchanged'] = False
    execution['scripts_after'].append(after)
execution['scripts_unchanged'] = all(item['unchanged'] for item in execution['scripts_after'])
execution['phase'] = 'completed'
(requests / 'runner-execution.json').write_text(json.dumps(execution, indent=2) + '\n')
if not execution['scripts_unchanged']:
    status = 125
if stage == 'build-normal-examples' and status == 0:
    ids = {package['name']: package['id'] for package in packages}
    selected = {}
    for line in (evidence / 'command.log').read_text().splitlines():
        try:
            message = json.loads(line)
        except json.JSONDecodeError:
            continue
        if message.get('reason') != 'compiler-artifact':
            continue
        name = message.get('target', {}).get('name')
        if name not in provider_examples or message.get('profile', {}).get('test') is not False:
            continue
        if message['package_id'] != ids[provider_examples[name]] or message['target']['kind'] != ['example']:
            raise ValueError('normal example artifact has a different package or target kind')
        executable = pathlib.Path(message['executable']).resolve()
        if executable != target / 'debug/examples' / name:
            raise ValueError('normal example artifact escaped its unique target path')
        selected[name] = {'name': name, 'package_id': message['package_id'], 'target': message['target'],
                          'profile': message['profile'], 'features': message.get('features'),
                          'fresh': message.get('fresh'), 'executable': str(executable),
                          'bytes': executable.stat().st_size,
                          'sha256': hashlib.file_digest(executable.open('rb'), 'sha256').hexdigest()}
    if set(selected) != set(provider_examples):
        raise ValueError('the all-features build did not report all four normal example executables')
    (evidence / 'provider-example-artifacts.json').write_text(json.dumps(
        {'head': expected, 'tree': tree, 'argv': argv, 'artifact_profile_test': False,
         'artifacts': [selected[name] for name in sorted(selected)]}, indent=2) + '\n')
if artifact_manifest is not None:
    after = []
    for artifact in artifact_manifest['artifacts']:
        item = {'name': artifact['name'], 'expected_sha256': artifact['sha256']}
        try:
            actual = hashlib.file_digest(pathlib.Path(artifact['executable']).open('rb'), 'sha256').hexdigest()
            item.update(actual_sha256=actual, unchanged=actual == artifact['sha256'])
        except OSError as exc:
            item.update(error=f'{type(exc).__name__}: {exc}', unchanged=False)
        after.append(item)
    unchanged = all(item['unchanged'] for item in after)
    (evidence / 'normal-example-artifacts-after.json').write_text(json.dumps(
        {'head': expected, 'tree': tree, 'all_unchanged': unchanged, 'artifacts': after}, indent=2) + '\n')
    if not unchanged:
        status = 125
execution['wrapper_exit_code'] = status
(requests / 'runner-execution.json').write_text(json.dumps(execution, indent=2) + '\n')
raise SystemExit(status)
