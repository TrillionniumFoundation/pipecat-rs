#!/usr/bin/env python3
"""One bounded syscall-observation window; no product or test-source changes."""
import fcntl
import hashlib
import importlib.util
import json
import os
import pathlib
import re
import selectors
import shutil
import signal
import subprocess
import sys
import time
import traceback

ROOT = pathlib.Path('/home/qian-qi/workspace/pipecat-workspace-f9f576cc6c66')
SOURCE, TARGET = ROOT / 'source-pin', ROOT / 'target-pin'
HEAD = '272671b95297313d24db921eceda8e95f3a8d545'
TREE = '94424ffa2a8fbcda0f81321ee68e7461663e191c'
TEST = 'rust/crates/pipecat-grok-realtime/tests/app_cli.rs'
TEST_SHA = '5f5d2cba7774aa4644cd7dd6dc67d86daf256223c78e65761705f59b67bf953f'
STRACE = pathlib.Path('/usr/bin/strace')
STRACE_SHA = '28f957c227012de0b18d1bd7fff2d396cb693ea60ed8013be68de071e84b5001'
PROBE_SHA = 'f42a84e151d6eb794789a03a4fc287d70734149c79d739507d5ef8929a5d16d8'
LIFECYCLE = 'socket,socketpair,setsockopt,getsockopt,bind,listen,connect,accept,accept4,getsockname,getpeername,shutdown,close,close_range,dup,dup2,dup3,fcntl,%process'
TRACE_CAP = 32 * 1024 * 1024
ROUNDS, WINDOW = 10, 90


def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def main():
    evidence = ROOT / 'evidence/grok-strace-pin-r1'
    evidence.mkdir(exist_ok=False)
    report = {
        'schema': 'pipecat-grok-strace-window-v1', 'head': HEAD, 'tree': TREE,
        'source': str(SOURCE), 'target': str(TARGET), 'source_file_sha256': TEST_SHA,
        'scope': 'Diagnostic only. Original r3 and diagnostic-r2 failures remain retained and unattributed by this run.',
        'limits': {'rounds': ROUNDS, 'window_seconds_including_cleanup': WINDOW,
                   'binding_seconds': 120, 'internal_job_seconds': 240, 'outer_job_seconds': 270,
                   'trace_bytes_total': TRACE_CAP, 'round_stdout_bytes': 1048576,
                   'round_stderr_bytes': 262144},
        'resource_budget': {'cpu_quota_percent': 800, 'memory_max_bytes': 34359738368,
                            'cargo_build_jobs': 8, 'nice': 10},
        'parallelism': 'Original complete 12-case harness, no selector or test-threads override.',
        'capture_scope': 'Lifecycle syscalls only, no send/recv payloads. -f follows owned children; -yy decodes available FD information.',
        'limitations': [
            'Tracing and FIFO capture perturb scheduling; a traced success does not clear an untraced failure.',
            'Implicit client local ports may be absent unless a later call or FD annotation exposes them.',
            'Unrelated processes are outside the trace. Missing decoded endpoints or later absence are not proof of historical absence.',
            'Signal requests and reaping the tracer leader do not prove every descendant was joined.',
        ],
        'phase': 'preparing', 'start_unix': time.time(), 'commands': [], 'rounds': [],
        'trace_bytes_retained_total': 0,
    }
    record_path = evidence / 'trace-window.json'
    before = helper = None
    artifacts = {}
    status = 127
    job_deadline = time.monotonic() + 240

    def save():
        temporary = evidence / 'trace-window.json.tmp'
        temporary.write_text(json.dumps(report, indent=2) + '\n')
        temporary.replace(record_path)

    def copy_receipt(path, name):
        if not path.is_file() or path.is_symlink() or path.stat().st_size > 4 * 1024 * 1024:
            raise ValueError('unexpected receipt type or size: ' + str(path))
        data = path.read_bytes()
        (evidence / name).write_bytes(data)
        return json.loads(data)

    def run_capture(name, argv, env, seconds, *, trace=False, round_number=None):
        """Drain pipes continuously, retain strict prefixes, and stop on any cap/error."""
        row = {'name': name, 'argv': argv, 'start_unix': time.time(),
               'timeout_seconds': seconds, 'phase': 'launching', 'signal_requests': []}
        destination = report['rounds'] if trace else report['commands']
        if trace:
            row['round'] = round_number
        destination.append(row)
        save()
        started = time.monotonic()
        deadline = started + seconds
        soft_deadline = deadline - 5
        child = None
        anchor = None
        fifo = evidence / (name + '.fifo') if trace else None
        selector = selectors.DefaultSelector()
        files = {}
        streams = {}
        stopped_at = None
        leader_exit_at = None
        kill_requested = False
        capture_error = None
        caps = {'stdout': 1048576 if trace else 16 * 1048576, 'stderr': 262144 if trace else 1048576,
                'trace': TRACE_CAP - report['trace_bytes_retained_total']}

        def group_present():
            try:
                os.killpg(child.pid, 0)
                return True
            except ProcessLookupError:
                return False

        def request(sig):
            item = {'pgid': child.pid, 'signal': int(sig), 'unix': time.time()}
            try:
                os.killpg(child.pid, sig)
                item['result'] = 'requested'
            except ProcessLookupError:
                item['result'] = 'group absent at request'
            except OSError as error:
                item['error'] = repr(error)
            row['signal_requests'].append(item)

        def stop(reason):
            nonlocal stopped_at
            if stopped_at is None:
                stopped_at = time.monotonic()
                row['stop_reason'] = reason
                request(signal.SIGTERM)
                save()

        def register(fd, label):
            os.set_blocking(fd, False)
            selector.register(fd, selectors.EVENT_READ, label)
            streams[fd] = label
            files[label] = (evidence / (name + '.' + label + ('.trace' if label == 'trace' else '.log'))).open('wb', buffering=0)
            row.setdefault('outputs', {})[label] = {'bytes_read': 0, 'bytes_retained': 0, 'bytes_discarded': 0,
                                                    'eof': False, 'file': files[label].name}

        try:
            if trace:
                os.mkfifo(fifo, 0o600)
                trace_fd = os.open(fifo, os.O_RDONLY | os.O_NONBLOCK)
                anchor = os.open(fifo, os.O_WRONLY | os.O_NONBLOCK)
                register(trace_fd, 'trace')
            child = subprocess.Popen(argv, cwd=SOURCE / 'rust', env=env,
                                     stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     start_new_session=True)
            row.update(leader_pid=child.pid, phase='running')
            register(child.stdout.fileno(), 'stdout')
            register(child.stderr.fileno(), 'stderr')
            save()
            while streams or child.poll() is None:
                now = time.monotonic()
                exit_code = child.poll()
                if exit_code is not None and leader_exit_at is None:
                    leader_exit_at = now
                    if anchor is not None:
                        os.close(anchor)
                        anchor = None
                if now >= soft_deadline and exit_code is None:
                    stop('bounded command/window deadline reached')
                if leader_exit_at is not None and now - leader_exit_at > 1 and streams:
                    stop('output stream remained open after tracer/command leader exit')
                if stopped_at is not None and now - stopped_at >= 1 and not kill_requested:
                    request(signal.SIGKILL)
                    kill_requested = True
                if now >= deadline or (stopped_at is not None and now - stopped_at >= 3):
                    row['capture_drain_cutoff'] = True
                    break
                for key, _ in selector.select(timeout=min(0.05, max(0, deadline - now))):
                    fd, label = key.fd, key.data
                    try:
                        data = os.read(fd, 65536)
                    except BlockingIOError:
                        continue
                    if not data:
                        selector.unregister(fd)
                        streams.pop(fd)
                        row['outputs'][label]['eof'] = True
                        continue
                    output = row['outputs'][label]
                    output['bytes_read'] += len(data)
                    room = max(0, caps[label] - output['bytes_retained'])
                    kept = min(room, len(data))
                    files[label].write(data[:kept])
                    output['bytes_retained'] += kept
                    output['bytes_discarded'] += len(data) - kept
                    if label == 'trace':
                        report['trace_bytes_retained_total'] += kept
                    if kept < len(data):
                        row['capture_truncated'] = True
                        stop(label + ' retained-byte cap reached')
                if child.poll() is not None and not streams:
                    break
        except Exception as error:
            capture_error = repr(error)
            row['capture_exception'] = capture_error
        finally:
            if child is not None:
                try:
                    if child.poll() is None or group_present():
                        request(signal.SIGTERM)
                        try:
                            child.wait(timeout=min(1, max(0.01, deadline - time.monotonic())))
                        except subprocess.TimeoutExpired:
                            pass
                        request(signal.SIGKILL)
                    try:
                        child.wait(timeout=min(1, max(0.01, deadline - time.monotonic())))
                    except subprocess.TimeoutExpired:
                        pass
                    row['leader_reaped'] = child.poll() is not None
                    row['leader_exit_code'] = child.returncode
                    row['process_group_present_at_final_probe'] = group_present()
                except Exception as error:
                    row['cleanup_exception'] = repr(error)
            if anchor is not None:
                os.close(anchor)
            for key in list(selector.get_map().values()):
                selector.unregister(key.fd)
            selector.close()
            if trace and 'trace_fd' in locals():
                os.close(trace_fd)
            if child is not None:
                child.stdout.close()
                child.stderr.close()
            for label, handle in files.items():
                handle.close()
                output = row['outputs'][label]
                path = pathlib.Path(output['file'])
                output['sha256'] = sha(path)
                output['bytes'] = path.stat().st_size
            if fifo is not None and fifo.exists():
                fifo.unlink()
            row['elapsed_seconds'] = time.monotonic() - started
            row['cleanup_scope'] = 'Only owned process-group signal requests, tracer/command leader reaping, and a bounded final group-existence probe are reported; no claim of joining every descendant.'
            row['exit_code'] = row.get('leader_exit_code', 127)
            if row['exit_code'] is None:
                row['exit_code'] = 124
            if (capture_error or row.get('stop_reason') or row.get('cleanup_exception') or
                    row.get('capture_drain_cutoff') or not row.get('leader_reaped') or
                    row.get('process_group_present_at_final_probe')):
                row['exit_code'] = 124 if row.get('stop_reason') else 127
            row['phase'] = 'completed'
            save()
        return row

    save()
    try:
        lock = (ROOT / 'qualification-owner-pin.lock').open('a')
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        spec = importlib.util.spec_from_file_location('source_manifest_helper', ROOT / 'run_full_gate.py')
        helper = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helper)
        full_dir = ROOT / 'evidence/full-workspace-rust-1.99.0-r4'
        full = copy_receipt(full_dir / 'gate.json', 'preceding-full-gate.json')
        if (full.get('phase') != 'completed' or not full.get('source_unchanged') or
                full.get('head') != HEAD or full.get('base_git_tree') != TREE or full.get('status_after')):
            raise ValueError('r4 must first be terminal on the unchanged exact source')
        supplement = copy_receipt(ROOT / 'evidence/default-no-fail-fast-pin-r1/gate.json',
                                  'preceding-default-no-fail-fast-gate.json')
        expected_cargo = str(ROOT / 'tools/rust-1.99.0-r1/bin/cargo')
        if (supplement.get('phase') != 'completed' or not supplement.get('source_unchanged') or
                supplement.get('head') != HEAD or supplement.get('base_git_tree') != TREE or
                supplement.get('status_after') or supplement.get('argv') !=
                [expected_cargo, 'test', '--workspace', '--locked', '--no-fail-fast']):
            raise ValueError('the subsequent default no-fail-fast matrix must also be terminal and source-bound')
        if (helper.git_value(SOURCE, ['rev-parse', 'HEAD']) != HEAD or
                helper.git_value(SOURCE, ['rev-parse', 'HEAD^{tree}']) != TREE or
                helper.git_value(SOURCE, ['status', '--porcelain=v1'])):
            raise ValueError('trace requires the exact clean native source checkpoint')
        if sha(SOURCE / TEST) != TEST_SHA:
            raise ValueError('reviewed test-source digest changed')
        if json.loads((TARGET / '.pipecat-source-owner.json').read_text()) != {'source': str(SOURCE), 'task': 'workspace-f9f576cc6c66'}:
            raise ValueError('target owner differs')
        before = helper.source_manifest(SOURCE)
        (evidence / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
        report['source_before_sha256'] = before['manifest_sha256']
        probe_path = ROOT / 'evidence/grok-strace-availability-r1/probe.json'
        if sha(probe_path) != PROBE_SHA or sha(STRACE) != STRACE_SHA:
            raise ValueError('existing strace capability receipt or executable changed')
        probe = copy_receipt(probe_path, 'capability-probe.json')
        if not probe.get('eligible') or not probe.get('supports_kill_on_exit'):
            raise ValueError('same-user lifecycle tracing was not qualified')
        report['strace'] = {'path': str(STRACE), 'sha256_before': sha(STRACE), 'version': probe['version_output']}
        pin = copy_receipt(ROOT / 'evidence/rust-1.99.0-restore-r1/ready.json', 'toolchain-ready.json')
        for item in pin['executables'].values():
            if sha(pathlib.Path(item['path'])) != item['sha256']:
                raise ValueError('pinned toolchain executable changed')
        environment = copy_receipt(full_dir / 'environment.json', 'environment.json')
        environment.update(CARGO_BUILD_JOBS='8', CARGO_TARGET_DIR=str(TARGET))
        env = dict(os.environ, **environment)
        if 'RUST_TEST_THREADS' in env:
            raise ValueError('trace rejects any inherited RUST_TEST_THREADS override')
        report['environment_overrides'] = environment
        safe_keys = ['CARGO_HOME', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL',
                     'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG', 'RUSTC', 'RUSTDOC',
                     'RUSTUP_TOOLCHAIN', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'CC', 'CXX',
                     'CXXFLAGS', 'CFLAGS', 'LDFLAGS', 'LIBCLANG_PATH', 'LD_LIBRARY_PATH',
                     'PKG_CONFIG_PATH', 'PKG_CONFIG_SYSROOT_DIR', 'LK_CUSTOM_WEBRTC',
                     'PIPECAT_ONNX_RUNTIME', 'ORT_DYLIB_PATH', 'PIPECAT_SILERO_MODEL',
                     'PIPECAT_SMART_TURN_MODEL', 'RUST_TEST_THREADS']
        report['effective_build_environment'] = {key: env[key] for key in safe_keys if key in env}
        if report['effective_build_environment'] != full.get('effective_build_environment'):
            raise ValueError('observed build environment differs from r4')
        report['resources_before'] = {'disk_free_bytes': shutil.disk_usage(ROOT).free}
        if report['resources_before']['disk_free_bytes'] < 1024 * 1024 * 1024:
            raise ValueError('at least 1GiB free disk required')
        prior_dir = ROOT / 'evidence/grok-rebind-diagnostic-pin-r2'
        if sha(prior_dir / 'repetitions.json') != '5b7daa7e9e9b814ebd5073220ce33a7e102a69fbf0c1bb30896a6f70b12ea5e5':
            raise ValueError('preserved diagnostic-r2 receipt digest changed')
        prior = copy_receipt(prior_dir / 'repetitions.json', 'preceding-diagnostic.json')
        if prior.get('expected_head') != HEAD or prior.get('expected_tree') != TREE or not prior.get('source_unchanged'):
            raise ValueError('previous compiler receipt belongs to another source')
        candidate = prior['artifacts']
        raw_full_log = full_dir / 'cargo-test-workspace.log'
        # Exact old harness must appear in r4's actual Running line, not just still exist on disk.
        running_lines = []
        with raw_full_log.open('r', errors='replace') as log:
            for line in log:
                if 'Running tests/app_cli.rs (' in line:
                    running_lines.append(line.rstrip())
        report['r4_app_cli_running_lines'] = running_lines
        report['r4_log_sha256'] = sha(raw_full_log)
        unchanged = all(pathlib.Path(item['path']).is_file() and sha(pathlib.Path(item['path'])) == item['sha256_after'] for item in candidate.values())
        actual_old_harness = any('(' + candidate['harness']['path'] + ')' in line for line in running_lines)
        report['old_pair_matches_after_r4'] = unchanged
        report['r4_ran_old_harness_path'] = actual_old_harness
        cargo = str(ROOT / 'tools/rust-1.99.0-r1/bin/cargo')
        if full.get('argv') != [cargo, 'test', '--workspace', '--locked']:
            raise ValueError('r4 was not the expected default-workspace Cargo command')
        package_id = 'path+file://' + str(SOURCE / 'rust/crates/pipecat-grok-realtime') + '#0.1.0'
        if unchanged and actual_old_harness:
            binding_log = prior_dir / 'binding.log'
            if sha(binding_log) != prior['binding_log_sha256']:
                raise ValueError('prior compiler-artifact raw log changed')
            shutil.copyfile(binding_log, evidence / 'binding-reused.log')
            selected = {kind: item['compiler_artifact'] for kind, item in candidate.items()}
            report['binding_mode'] = 'Prior exact compiler records reused only after both byte hashes and r4 actual harness Running path matched.'
        else:
            argv = [cargo, 'test', '--workspace', '--locked', '--offline', '--no-run', '--message-format=json-render-diagnostics']
            row = run_capture('binding', argv, env, min(120, job_deadline - time.monotonic() - 100))
            if row['exit_code'] != 0:
                raise RuntimeError('same-workspace default compiler-artifact binding failed')
            selected = {}
            for line in pathlib.Path(row['outputs']['stdout']['file']).read_bytes().splitlines():
                try:
                    item = json.loads(line)
                except (ValueError, UnicodeDecodeError):
                    continue
                if item.get('reason') != 'compiler-artifact' or item.get('package_id') != package_id:
                    continue
                target, profile = item.get('target', {}), item.get('profile', {})
                kind = None
                if target.get('name') == 'app_cli' and target.get('kind') == ['test'] and profile.get('test') is True:
                    kind = 'harness'
                if target.get('name') == 'grok_pcm' and target.get('kind') == ['bin'] and profile.get('test') is False:
                    kind = 'normal'
                if kind:
                    if kind in selected:
                        raise ValueError('duplicate compiler artifact for ' + kind)
                    selected[kind] = item
            report['binding_mode'] = 'Fresh same-workspace/default no-run Cargo JSON; no package-only feature de-unification.'
        if set(selected) != {'harness', 'normal'}:
            raise ValueError('missing exact Grok harness/normal compiler records')
        for kind, item in selected.items():
            if item.get('package_id') != package_id:
                raise ValueError('wrong compiler package identity')
            expected_kind = ['test'] if kind == 'harness' else ['bin']
            expected_name = 'app_cli' if kind == 'harness' else 'grok_pcm'
            if (item.get('target', {}).get('kind') != expected_kind or
                    item.get('target', {}).get('name') != expected_name or
                    item.get('profile', {}).get('test') is not (kind == 'harness')):
                raise ValueError('compiler target/profile identity differs')
            path = pathlib.Path(item['executable']).resolve()
            if (kind == 'normal' and path != TARGET / 'debug/grok_pcm') or (kind == 'harness' and (path.parent != TARGET / 'debug/deps' or not path.name.startswith('app_cli-'))):
                raise ValueError('artifact path escaped expected exclusive target')
            artifacts[kind] = {'path': str(path), 'sha256_before': sha(path), 'bytes': path.stat().st_size, 'compiler_artifact': item}
        report['artifacts'] = artifacts
        harness, normal = (pathlib.Path(artifacts[kind]['path']) for kind in ('harness', 'normal'))
        if str(normal).encode() not in harness.read_bytes():
            raise ValueError('harness does not embed exact normal grok_pcm path')
        report['normal_path_embedded_in_harness'] = True
        row = run_capture('selection', [str(harness), '--list'], env, 10)
        output = pathlib.Path(row['outputs']['stdout']['file']).read_bytes()
        declared = sorted(re.findall(r'#\[tokio::test\]\s*async fn ([A-Za-z0-9_]+)\(', (SOURCE / TEST).read_text()))
        listed = sorted(re.findall(rb'^([A-Za-z0-9_]+): test$', output, re.MULTILINE))
        if row['exit_code'] != 0 or len(declared) != 12 or listed != [name.encode() for name in declared] or b'12 tests, 0 benchmarks' not in output:
            raise ValueError('unfiltered harness selection is not the exact original 12 tests')
        report['case_names'] = declared
        if job_deadline - time.monotonic() < WINDOW + 10:
            raise RuntimeError('insufficient whole-job budget for the predeclared window')
        status = 0
        report['phase'] = 'tracing'
        window_started = time.monotonic()
        deadline = window_started + WINDOW
        report['window_start_unix'] = time.time()
        save()
        for number in range(1, ROUNDS + 1):
            remaining = deadline - time.monotonic()
            if remaining < 7:
                status = 124
                report['stop_reason'] = '90-second window lacks cleanup reserve for another attempt'
                break
            name = f'round-{number:02d}'
            argv = [str(STRACE), '-f', '-yy', '-ttt', '-T', '-s', '96', '-I', '1',
                    '-e', 'trace=' + LIFECYCLE, '-o', str(evidence / (name + '.fifo')),
                    '--kill-on-exit', '--', str(harness), '--nocapture']
            row = run_capture(name, argv, env, remaining, trace=True, round_number=number)
            output = pathlib.Path(row['outputs']['stdout']['file']).read_bytes()
            summaries = re.findall(rb'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', output, re.MULTILINE)
            row['complete_unfiltered_success'] = summaries == [(b'12', b'0', b'0', b'0', b'0')]
            row['trace_nonempty'] = row.get('outputs', {}).get('trace', {}).get('bytes', 0) > 0
            save()
            print(json.dumps({'round': number, 'exit_code': row['exit_code'], 'complete_unfiltered_success': row['complete_unfiltered_success'], 'trace_bytes': row.get('outputs', {}).get('trace', {}).get('bytes'), 'elapsed_seconds': row['elapsed_seconds']}), flush=True)
            if row['exit_code'] != 0 or not row['complete_unfiltered_success'] or not row['trace_nonempty']:
                status = row['exit_code'] or 126
                report['stop_reason'] = 'first test, tracer, capture or cleanup failure; no replacement attempt'
                break
        report['window_elapsed_seconds'] = time.monotonic() - window_started
        if report['window_elapsed_seconds'] > WINDOW:
            status = 124
            report['stop_reason'] = 'measured window exceeded the declared 90 seconds'
        if status == 0 and len(report['rounds']) == ROUNDS:
            report['stop_reason'] = 'predeclared 10-attempt observation window completed'
    except Exception as error:
        report['exception'] = repr(error)
        (evidence / 'runner-error.log').write_text(traceback.format_exc())
        if status == 0:
            status = 127
    finally:
        report['execution_exit_code'] = status
        if before is not None:
            try:
                after = helper.source_manifest(SOURCE)
                (evidence / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
                report['source_after_sha256'] = after['manifest_sha256']
                report['source_unchanged'] = before == after
                report['status_after'] = helper.git_value(SOURCE, ['status', '--porcelain=v1'])
                if not report['source_unchanged'] or report['status_after']:
                    status = 125
            except Exception as error:
                report['source_after_error'] = repr(error)
                status = 125
        for item in artifacts.values():
            try:
                item['sha256_after'] = sha(pathlib.Path(item['path']))
                item['unchanged'] = item['sha256_after'] == item['sha256_before']
                if not item['unchanged']:
                    status = 125
            except Exception as error:
                item['after_error'] = repr(error)
                status = 125
        try:
            report['strace_sha256_after'] = sha(STRACE)
            if report['strace_sha256_after'] != STRACE_SHA:
                status = 125
        except Exception as error:
            report['strace_after_error'] = repr(error)
            status = 125
        report.update(phase='completed', exit_code=status, end_unix=time.time(),
                      attempted_rounds=len(report['rounds']),
                      completed_rounds=sum(row.get('phase') == 'completed' for row in report['rounds']))
        save()
        files = sorted(path for path in evidence.iterdir() if path.is_file() and path.name != 'SHA256SUMS')
        (evidence / 'SHA256SUMS').write_text(''.join(sha(path) + '  ' + path.name + '\n' for path in files))
        print(json.dumps({key: report.get(key) for key in ('phase', 'exit_code', 'attempted_rounds', 'completed_rounds', 'stop_reason', 'exception', 'source_unchanged', 'window_elapsed_seconds', 'trace_bytes_retained_total')}), flush=True)
    return status


if __name__ == '__main__':
    raise SystemExit(main())
