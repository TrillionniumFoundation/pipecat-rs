#!/usr/bin/env python3
"""Run one explicit qualification command on an unchanged exclusive checkout."""
import argparse
import fcntl
import importlib.util
import json
import os
import pathlib
import re
import subprocess
import sys
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-commit', required=True)
    parser.add_argument('--expected-tree', required=True)
    parser.add_argument('--evidence', type=pathlib.Path, required=True)
    parser.add_argument('--env-json', type=pathlib.Path, required=True)
    parser.add_argument('--argv-json', type=pathlib.Path, required=True)
    parser.add_argument('--purpose', required=True)
    parser.add_argument('--expected-passed', type=int)
    options = parser.parse_args()
    root = pathlib.Path('/home/qian-qi/workspace/pipecat-workspace-f9f576cc6c66')
    source, target = root / 'source-pin', root / 'target-pin'
    owner_lock = (root / 'qualification-owner-pin.lock').open('a')
    fcntl.flock(owner_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    spec = importlib.util.spec_from_file_location('source_manifest_helper', root / 'run_full_gate.py')
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    ownership = {'source': str(source), 'task': 'workspace-f9f576cc6c66'}
    if json.loads((target / '.pipecat-source-owner.json').read_text()) != ownership:
        raise ValueError('target is not exclusive to this checkout')
    head = helper.git_value(source, ['rev-parse', 'HEAD'])
    tree = helper.git_value(source, ['rev-parse', 'HEAD^{tree}'])
    status = helper.git_value(source, ['status', '--porcelain=v1'])
    if head != options.expected_commit or tree != options.expected_tree or status:
        raise ValueError('qualification requires the exact clean frozen source')
    evidence = options.evidence.resolve()
    evidence.mkdir(parents=True, exist_ok=False)
    env_changes = json.loads(options.env_json.read_text())
    env_changes['CARGO_TARGET_DIR'] = str(target)
    env = dict(os.environ, **env_changes)
    argv = json.loads(options.argv_json.read_text())
    if not isinstance(argv, list) or not argv or not all(isinstance(x, str) for x in argv):
        raise ValueError('argv must be an explicit nonempty string array')
    before = helper.source_manifest(source)
    (evidence / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
    record = {'schema': 'pipecat-qualification-command-v1', 'purpose': options.purpose,
              'head': head, 'base_git_tree': tree, 'source': str(source),
              'target': str(target), 'cwd': str(source / 'rust'), 'argv': argv,
              'environment_overrides': env_changes, 'start_unix': time.time(),
              'source_before_sha256': before['manifest_sha256'],
              'status_before': status, 'phase': 'running'}
    record_path = evidence / 'gate.json'
    record_path.write_text(json.dumps(record, indent=2) + '\n')
    try:
        with (evidence / 'command.log').open('wb') as log:
            child = subprocess.Popen(argv, cwd=source / 'rust', env=env,
                                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            for line in child.stdout:
                log.write(line)
                log.flush()
                sys.stdout.buffer.write(line)
                sys.stdout.buffer.flush()
            record['exit_code'] = child.wait()
    except Exception as exc:
        record['launch_exception'] = f'{type(exc).__name__}: {exc}'
    if options.expected_passed is not None and record.get('exit_code') == 0:
        summaries = re.findall(rb'(?m)^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (evidence / 'command.log').read_bytes())
        record['expected_passed'] = options.expected_passed
        record['exact_selection_satisfied'] = len(summaries) == 1 and tuple(map(int, summaries[0])) == (options.expected_passed, 0, 0)
    after = helper.source_manifest(source)
    (evidence / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
    record.update(end_unix=time.time(), phase='completed',
                  source_after_sha256=after['manifest_sha256'], source_unchanged=before == after,
                  status_after=helper.git_value(source, ['status', '--porcelain=v1']))
    record_path.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record, sort_keys=True), flush=True)
    if not record['source_unchanged']:
        return 125
    if record.get('exact_selection_satisfied') is False:
        return 126
    return record.get('exit_code', 127)


if __name__ == '__main__':
    raise SystemExit(main())
